// UnstructuredTrianglesOrder2.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include "pch.h"
#include <iostream>
#include<complex>
#include <stdio.h>
#include <vector>
#include <unistd.h>
#include <ios>
#include <ctime>
#include <cmath>
#include <mpi.h>
#include <math.h>
#include <algorithm>
#include <fstream>
#include<numeric>
#include <stdlib.h>
#include <omp.h>
#include <iomanip>
#include <mkl_pardiso.h>
#include <mkl_types.h>
#include <mkl.h>
#define M_PI  3.14159265358979323846
using namespace std;

typedef struct {
	vector<int>elemID;
	int elemNum;
	int ID;
	vector<vector<int> >nodosID;
	vector<vector<int> >ladosID;
}
sup;
typedef struct {
	double re;
	double i;
}
doublecomplex;

struct IncGenerator {
	int current_;
	IncGenerator(int start) : current_(start) {}
	int operator() () { return current_++; }
};
vector<int>vecID, vecID3;
bool myfunction(int i, int j) { return (vecID[i] < vecID[j]); };
#define M_PI  3.14159265358979323846
double n[3], v1x, v1y, v1z, v2x, v2y, v2z, v3x, v3y, v3z;
int checkcross(int ck,double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3, double xR, double yR, double zR)
{
	int res = 1;
	v1x = x1 - x2;
	v1y = y1 - y2;
	v1z = z1 - z2;
	v2x = x3 - x2;
	v2y = y3 - y2;
	v2z = z3 - z2;
	v3x = xR - x2;
	v3y = yR - y2;
	v3z = zR - z2;
	n[0] = (v1y*v2z - v1z * v2y);
	n[1] = (v1z*v2x - v2z * v1x);
	n[2] = (v1x*v2y - v1y * v2x);
	double tol = -pow(10.0, -14.0);
	if ((n[0] * v3x + n[1] * v3y + n[2] * v3z) >= tol)
	{
		res = 1;
	}
	else
	{
		res = 0;
	}
	return res;
}
bool checkS(int l1, int l2, int limitS)
{
	return true;//if((l1<limitS)
}
void process_mem_usage(double& vm_usage, double& resident_set)
{
   using std::ios_base;
   using std::ifstream;
   using std::string;

   vm_usage     = 0.0;
   resident_set = 0.0;

   // 'file' stat seems to give the most reliable results
   //
   ifstream stat_stream("/proc/self/stat",ios_base::in);

   // dummy vars for leading entries in stat that we don't care about
   //
   string pid, comm, state, ppid, pgrp, session, tty_nr;
   string tpgid, flags, minflt, cminflt, majflt, cmajflt;
   string utime, stime, cutime, cstime, priority, nice;
   string O, itrealvalue, starttime;

   // the two fields we want
   //
   unsigned long vsize;
   long rss;

   stat_stream >> pid >> comm >> state >> ppid >> pgrp >> session >> tty_nr
               >> tpgid >> flags >> minflt >> cminflt >> majflt >> cmajflt
               >> utime >> stime >> cutime >> cstime >> priority >> nice
               >> O >> itrealvalue >> starttime >> vsize >> rss; // don't care about the rest

   stat_stream.close();

   long page_size_kb = sysconf(_SC_PAGE_SIZE) / 1024; // in case x86-64 is configured to use 2MB pages
   vm_usage     = vsize / 1024.0;
   resident_set = rss * page_size_kb;
}

double* crossP(double a[3], double b[3])
{
	//static double n[3];
	double *n = new double [3];
	n[0] = a[1] * b[2] - a[2] * b[1];
	n[1] = a[2] * b[0] - a[0] * b[2];
	n[2] = a[0] * b[1] - a[1] * b[0];
	return n;
}
double *x, *y, *z;
double**getcof(int l1,int l2,int l3,int l4)
{
	double **cof = new double *[4];
	for (int i = 0; i < 4; i++)
	{
		cof[i] = new double[4];
	}
	double yz34, yz24, yz23, yz14, yz13, yz12, Ve;
	double xz34, xz24, xz23, xz14, xz13, xz12;
	double xy34, xy24, xy23, xy14, xy13, xy12;
	yz34 = y[l3] * z[l4] - y[l4] * z[l3];
	yz24 = y[l2] * z[l4] - y[l4] * z[l2];
	yz23 = y[l2] * z[l3] - y[l3] * z[l2];
	yz14 = y[l1] * z[l4] - y[l4] * z[l1];
	yz13 = y[l1] * z[l3] - y[l3] * z[l1];
	yz12 = y[l1] * z[l2] - y[l2] * z[l1];

	xz34 = x[l3] * z[l4] - x[l4] * z[l3];
	xz24 = x[l2] * z[l4] - x[l4] * z[l2];
	xz23 = x[l2] * z[l3] - x[l3] * z[l2];
	xz14 = x[l1] * z[l4] - x[l4] * z[l1];
	xz13 = x[l1] * z[l3] - x[l3] * z[l1];
	xz12 = x[l1] * z[l2] - x[l2] * z[l1];

	xy34 = x[l3] * y[l4] - x[l4] * y[l3];
	xy24 = x[l2] * y[l4] - x[l4] * y[l2];
	xy23 = x[l2] * y[l3] - x[l3] * y[l2];
	xy14 = x[l1] * y[l4] - x[l4] * y[l1];
	xy13 = x[l1] * y[l3] - x[l3] * y[l1];
	xy12 = x[l1] * y[l2] - x[l2] * y[l1];
	cof[0][0] = x[l2] * yz34 - x[l3] * yz24 + x[l4] * yz23;
	cof[1][0] = -(x[l1] * yz34 - x[l3] * yz14 + x[l4] * yz13);
	cof[2][0] = x[l1] * yz24 - x[l2] * yz14 + x[l4] * yz12;
	cof[3][0] = -(x[l1] * yz23 - x[l2] * yz13 + x[l3] * yz12);
	//Ve = 1.0 / 6.0*(a[0] + a[1] + a[2] + a[3]);
	cof[0][1] = -yz34 + yz24 - yz23;
	cof[1][1] = yz34 - yz14 + yz13;
	cof[2][1] = -yz24 + yz14 - yz12;
	cof[3][1] = yz23 - yz13 + yz12;

	cof[0][2] = xz34 - xz24 + xz23;
	cof[1][2] = -xz34 + xz14 - xz13;
	cof[2][2] = xz24 - xz14 + xz12;
	cof[3][2] = -xz23 + xz13 - xz12;

	cof[0][3] = -xy34 + xy24 - xy23;
	cof[1][3] = xy34 - xy14 + xy13;
	cof[2][3] = -xy24 + xy14 - xy12;
	cof[3][3] = xy23 - xy13 + xy12;
	return cof;
}
double**inv3(double mat[3][3])
{
	double **K = new double *[3];
	for (int i = 0; i < 3; i++)
	{
		K[i] = new double[3];
	}
	K[0][0] = mat[1][1] * mat[2][2] - mat[1][2] * mat[2][1];
	K[0][1] = -(mat[0][1]*mat[2][2]-mat[0][2]*mat[2][1]);
	K[0][2] = mat[0][1] * mat[1][2] - mat[0][2] * mat[1][1];
	K[1][0] = -(mat[1][0] * mat[2][2] - mat[1][2] * mat[2][0]);
	K[1][1] = mat[0][0] * mat[2][2] - mat[0][2] * mat[2][0];
	K[1][2] = -(mat[0][0]*mat[1][2]-mat[0][2]*mat[1][0]);
	K[2][0] = mat[1][0] * mat[2][1] - mat[1][1] * mat[2][0];
	K[2][1] = -(mat[0][0] * mat[2][1] - mat[0][1] * mat[2][0]);
	K[2][2] = mat[0][0] * mat[1][1] - mat[0][1] * mat[1][0];
	double det = 0.0;
	det = mat[0][0] * (mat[1][1] * mat[2][2] - mat[1][2] * mat[2][1]) + mat[0][1] * (mat[1][2] * mat[2][0] - mat[2][2] * mat[1][0]) + mat[0][2] * (mat[1][0] * mat[2][1] - mat[1][1] * mat[2][0]);
	//det = 1.0 / det;
	for (int j = 0; j < 3; j++)
	{
		for (int i = 0; i < 3; i++)
		{
			K[j][i] = K[j][i]/det;
		}
	}
	if (det == 0.0)
	{
		return false;
	}
	return K;
}
double **result5(double K[4][4])
{
	
	double **GR = new double *[4];
	for (int i = 0; i < 4; i++)
	{
		GR[i] = new double[4];
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			//cout << K[i][j] << endl;
			GR[i][j] = K[i][j];
		}
	}
	GR[2][2] = 7.0;

	return GR;

}
double** inv4(double G[4][4])
{
	double **GR = new double *[4];
	for (int i = 0; i < 4; i++)
	{
		GR[i] = new double[4];
	}
	//static double GR[4][4];
	double inv[16], det;
	int i, p=0;
	double m[16];
	for (int q2 = 0; q2 < 4; q2++)
	{
		for (int q1 = 0; q1 < 4; q1++)
		{
			m[p] = G[q2][q1];
			p = p + 1;
		}
	}

	inv[0] = m[5] * m[10] * m[15] -
		m[5] * m[11] * m[14] -
		m[9] * m[6] * m[15] +
		m[9] * m[7] * m[14] +
		m[13] * m[6] * m[11] -
		m[13] * m[7] * m[10];

	inv[4] = -m[4] * m[10] * m[15] +
		m[4] * m[11] * m[14] +
		m[8] * m[6] * m[15] -
		m[8] * m[7] * m[14] -
		m[12] * m[6] * m[11] +
		m[12] * m[7] * m[10];

	inv[8] = m[4] * m[9] * m[15] -
		m[4] * m[11] * m[13] -
		m[8] * m[5] * m[15] +
		m[8] * m[7] * m[13] +
		m[12] * m[5] * m[11] -
		m[12] * m[7] * m[9];

	inv[12] = -m[4] * m[9] * m[14] +
		m[4] * m[10] * m[13] +
		m[8] * m[5] * m[14] -
		m[8] * m[6] * m[13] -
		m[12] * m[5] * m[10] +
		m[12] * m[6] * m[9];

	inv[1] = -m[1] * m[10] * m[15] +
		m[1] * m[11] * m[14] +
		m[9] * m[2] * m[15] -
		m[9] * m[3] * m[14] -
		m[13] * m[2] * m[11] +
		m[13] * m[3] * m[10];

	inv[5] = m[0] * m[10] * m[15] -
		m[0] * m[11] * m[14] -
		m[8] * m[2] * m[15] +
		m[8] * m[3] * m[14] +
		m[12] * m[2] * m[11] -
		m[12] * m[3] * m[10];

	inv[9] = -m[0] * m[9] * m[15] +
		m[0] * m[11] * m[13] +
		m[8] * m[1] * m[15] -
		m[8] * m[3] * m[13] -
		m[12] * m[1] * m[11] +
		m[12] * m[3] * m[9];

	inv[13] = m[0] * m[9] * m[14] -
		m[0] * m[10] * m[13] -
		m[8] * m[1] * m[14] +
		m[8] * m[2] * m[13] +
		m[12] * m[1] * m[10] -
		m[12] * m[2] * m[9];

	inv[2] = m[1] * m[6] * m[15] -
		m[1] * m[7] * m[14] -
		m[5] * m[2] * m[15] +
		m[5] * m[3] * m[14] +
		m[13] * m[2] * m[7] -
		m[13] * m[3] * m[6];

	inv[6] = -m[0] * m[6] * m[15] +
		m[0] * m[7] * m[14] +
		m[4] * m[2] * m[15] -
		m[4] * m[3] * m[14] -
		m[12] * m[2] * m[7] +
		m[12] * m[3] * m[6];

	inv[10] = m[0] * m[5] * m[15] -
		m[0] * m[7] * m[13] -
		m[4] * m[1] * m[15] +
		m[4] * m[3] * m[13] +
		m[12] * m[1] * m[7] -
		m[12] * m[3] * m[5];

	inv[14] = -m[0] * m[5] * m[14] +
		m[0] * m[6] * m[13] +
		m[4] * m[1] * m[14] -
		m[4] * m[2] * m[13] -
		m[12] * m[1] * m[6] +
		m[12] * m[2] * m[5];

	inv[3] = -m[1] * m[6] * m[11] +
		m[1] * m[7] * m[10] +
		m[5] * m[2] * m[11] -
		m[5] * m[3] * m[10] -
		m[9] * m[2] * m[7] +
		m[9] * m[3] * m[6];

	inv[7] = m[0] * m[6] * m[11] -
		m[0] * m[7] * m[10] -
		m[4] * m[2] * m[11] +
		m[4] * m[3] * m[10] +
		m[8] * m[2] * m[7] -
		m[8] * m[3] * m[6];

	inv[11] = -m[0] * m[5] * m[11] +
		m[0] * m[7] * m[9] +
		m[4] * m[1] * m[11] -
		m[4] * m[3] * m[9] -
		m[8] * m[1] * m[7] +
		m[8] * m[3] * m[5];

	inv[15] = m[0] * m[5] * m[10] -
		m[0] * m[6] * m[9] -
		m[4] * m[1] * m[10] +
		m[4] * m[2] * m[9] +
		m[8] * m[1] * m[6] -
		m[8] * m[2] * m[5];

	det = m[0] * inv[0] + m[1] * inv[4] + m[2] * inv[8] + m[3] * inv[12];

	if (det == 0)
	{
		return false;
	}
		//return false;

	det = 1.0 /(double)det;
	p = 0;
	for (int q2 = 0; q2 < 4; q2++)
	{
		for (int q1 = 0; q1 < 4; q1++)
		{
			/*if (q1 == q2)
			{
				GR[q2][q1] = 0.5;
			}*/
			GR[q2][q1]=inv[p]*det;
			p = p + 1;
		}
	}
	return GR;
}
int* order(int val1, int val2, int val3)
{
	//static int l[3];
	int *l = new int [3];
	if (val2 > val1)
	{
		if (val3 > val2)
		{
			l[0] = val1;
			l[1] = val2;
			l[2] = val3;
		}
		else
		{
			if (val1 > val3)
			{
				l[0] = val3;
				l[1] = val1;
				l[2] = val2;
			}
			else
			{
				l[0] = val1;
				l[1] = val3;
				l[2] = val2;
			}
		}
	}
	else
	{
		if (val3 > val1)
		{
			l[0] = val2;
			l[1] = val1;
			l[2] = val3;
		}
		else
		{
			if (val2 > val3)
			{
				l[0] = val3;
				l[1] = val2;
				l[2] = val1;
			}
			else
			{
				l[0] = val2;
				l[1] = val3;
				l[2] = val1;
			}
		}
	}
	for (int i = 0; i < 3; i++)
	{
		l[i] = l[i] - 1;
	}
	return l;
}
int main(int argc,char** argv)
{
	int process_num, size_of_cluster;
    	double message_Item;
    	double *zap;
    	MPI_Init(&argc, &argv);
    	MPI_Comm_size(MPI_COMM_WORLD, &size_of_cluster);
    	MPI_Comm_rank(MPI_COMM_WORLD, &process_num);

	double Lx = 100.0, Ly =100.0, Lz = 100.0;//300	
	int ar[3][2] = { {0,1},{1,2},{2,0} };
	int ar3[3][3] = { {2,0,1},{0,1,2},{1,2,0} };
	double zslice = 15.0, xslice = -15.0;
	ifstream inFile, inPesos,evalCoords;
	int nodostot = 0;
	int elemtot1, elemtot2, elemtot;
	int x1, ordenN;
	double *Pesos, *ux, *uy, *uz;
	int ladosSup = 0;
	int sizeF, valF, min, max;
	int Sum;
	int condL[20];
	double ResA;
	int x3;
	time_t start, finish,start2,finish2,finish3;

	time(&start);
	
	complex <double> CE2[3][2], CM2[3][2], scax, scay, scaz, scax2, scay2, scaz2;
	inPesos.open("Pesos.txt");
	inPesos >> ordenN;
	//vector<int>vecID, vecID3;
	Pesos = (double*)malloc(sizeof(double)*ordenN);
	ux = (double*)malloc(sizeof(double)*ordenN);
	uy = (double*)malloc(sizeof(double)*ordenN);
	uz = (double*)malloc(sizeof(double)*ordenN);
	//cout << "ORDER: " << ordenN << endl;
	for (int i = 0; i < ordenN; i++)
	{
		inPesos >> ux[i];
		inPesos >> uy[i];
		inPesos >> uz[i];
		inPesos >> Pesos[i];
	}
	inPesos.close();
	evalCoords.open("EvInfo.txt");
	int numCoords;
	evalCoords>>numCoords;
	double *evx,*evy,*evz;
	evx = (double*)malloc(sizeof(double)*numCoords);
	evy = (double*)malloc(sizeof(double)*numCoords);
	evz = (double*)malloc(sizeof(double)*numCoords);
	cout<<numCoords<<endl;
	for (int i = 0; i <numCoords; i++)
	{
		evalCoords >> evx[i];
		evalCoords >> evy[i];
		evalCoords >> evz[i];
	}
	//evalCoords.close();



	//EsferaPB
	inFile.open("modeloPB4HomM.txt");//CuboP7CuboO2FinalModeloHomogeneoO2//CuboO2Res2D2c
	int numS[11];
	int elemS[11];
	int numL[32];//32
	int dirichNum = 0;
	inFile >> nodostot;
	/*for (int i = 0; i < 11; i++)
	{
		inFile >> numS[i];
		dirichNum = dirichNum + numS[i];

	}
	for (int i = 0; i < 32; i++)
	{
		inFile >> numL[i];
		dirichNum = dirichNum + numL[i];
	}
	dirichNum = dirichNum + 20;//19;*/
	//cout << "Nodos totales: " << nodostot << endl;
	
	
	vector<vector<int > >elemN(nodostot);
	//vector<vector<int > >elemI(nodostot);
	//vector<vector<int> >elemIF(nodostot);
	vector<vector<int> >elemIDF(nodostot);
	//vector<vector<int> >elemNF(nodostot);
    //    vector<complex<double > >dirichC;
	int cont = 1;
	int startN = 12;

	int arr7[6][2] = { {0,1},{1,2},{0,2},{0,3},{2,3},{3,1} };
	int arr8[6] = { 4,5,6,7,8,9};
	int arr1[3][2] = { {0,1},{1,2},{2,0} };
	double condT[3][3]={{1.0,0.1,0.0},{0.1,1.0,0.0},{0.0,0.0,1.0}};
	//int arr5[12][3] = { {0,0,1},{1,0,1},{1,1,2},{2,1,2},{2,0,2},{0,0,2},{0,0,3},{3,0,3},{2,2,3},{3,2,3},{1,3,1},{3,3,1} };
	//int arr[12][2] = { {0,4},{4,1},{1,5},{5,2},{2,6},{6,0},{0,7},{7,3},{2,8},{8,3},{1,9},{9,3} };
	int arr[6][2] = { {0,1},{1,2},{2,0},{0,3},{3,2},{3,1} };

	int arr2[4][3] = { {0,1,2},{1,2,3},{0,2,3},{0,1,3}};
	int arr6[4][3] = { {1,2,3},{1,3,4},{1,4,2},{4,3,2}};

	int arr4[6][2] = { {0,3},{3,1},{1,4},{4,2},{2,5},{5,0} };
	//int arr3b[4][12] = { {0,1,0,1,1,2,1,2,0,2,0,2},{1,2,1,2,2,3,2,3,3,1,3,1},{0,2,0,2,2,3,2,3,3,0,3,0},{0,1,0,1,1,3,1,3,3,0,3,0} };
	//int arr3[4][12] = { {0,4,4,1,1,5,5,2,2,6,6,0},{1,5,5,2,2,8,8,3,3,9,9,1},{0,6,6,2,2,8,8,3,3,7,7,0},{0,4,4,1,1,9,9,3,3,7,7,0} };
	int arrN[4][3] = { {4,5,6},{5,8,9},{6,8,7},{4,9,7} };
	double valE[4][3] = {{0.0,sqrt(3.0) / 4.0,3.0/8.0},{1.0/8.0,sqrt(3.0) / 4.0,3.0/8.0},{-1.0/8.0,sqrt(3.0) / 4.0,3.0/8.0},{0.0,sqrt(3.0) / 4.0,0.0}};
	double CE[4][3] = { {0.0, 0.0, 0.0},{1.0, 0.0, 0.0},{0.0,0.0,1.0},{0.0,1.0, 0.0} };
	double CF[4][3] = { {0.0,0.0,0.0},{1.0,0.0,0.0},{0.0,0.0,1.0},{0.0,1.0,0.0} };
	double G3[4][4] = { {1.0,1.0,0.0,0.0},{1.0,0.0,1.0,0.0},{1.0,0.0,0.0,1.0},{1.0,0.0,0.0,0.0} };
	double **G3inv;
	G3inv = inv4(G3);
	complex <double> val4 = 0.0;
	int mintemp = 0;
	int ladostot;
	ResA = (double)3.3*pow(10.0, 8.0);
	complex<float>k0, k1, val1;
	complex <double>im;
	complex<double>valC(1000.0, 0.0);
	complex<float> H0(1.0, 0.0), A, B, C;
	im.imag(1);
	

	complex<float>val2(1000.0, 0.0);
	double valY;
	int elemtot3;
	vector<int >indexes;
	int elemP, elemP1, elemP2,volumeNumb;
	vector<int>volE;
	int elemtemp;
	inFile >> volumeNumb;
	elemtot = 0;
	for (int i = 0; i < volumeNumb;i++)
	{
		inFile >> elemtemp;
		volE.push_back(elemtemp);
		elemtot = elemtot + elemtemp;		
	}
	/*inFile >> elemtot1;
	inFile >> elemtot2;
	inFile >> elemtot3;
	elemtot = elemtot1 + elemtot2+elemtot3;*/
	int elemSnum = 0;
	int elembot1=0;
	int elemtop1=0;
	int elembot2=0;
	int elemtop2=0;

	for (int i = 0; i < 11; i++)
	{
		inFile >> elemS[i];
		elemSnum = elemSnum + elemS[i];
	}
	//complex <double> **Ex,**Ey,**Ez, **Hx,**Hy,**Hz;//,Ex[1][2], Ey[1][2], Ez[1][2], Hx[1][2], Hy[1][2], Hz[1][2];
	vector<vector<complex <double> > > Ex( numCoords);// , vector<complex <double > > (2, 0)); 
	vector<vector<complex <double> > > Ey( numCoords);// , vector<complex <double > > (2, 0));
	vector<vector<complex <double> > > Ez( numCoords);// , vector<complex <double > > (2, 0));
	vector<vector<complex <double> > > Hx( numCoords);// , vector<complex <double> > (2, 0)); 
	vector<vector<complex <double> > > Hy( numCoords);// vector<complex <double> > (2, 0));
	vector<vector<complex <double> > > Hz( numCoords);// , vector<complex <double> > (2, 0));
	for(int i=0;i<numCoords;i++)
	{
	complex<double> vecK=0.0;	
	for(int j=0;j<2;j++)
	{
	Ex[i].push_back(vecK);	
	Ey[i].push_back(vecK);
	Ez[i].push_back(vecK);
	Hx[i].push_back(vecK);
	Hy[i].push_back(vecK);
	Hz[i].push_back(vecK);
	}
	}
	//vector<complex<doublecomplex>>dirichVN(edgenumber, 0);
	

	int **numb, **numbS, **numbR;
	numb = (int**)malloc(elemtot * sizeof(int *));
	numbS = (int**)malloc(elemSnum * sizeof(int *));
	numbR = (int**)malloc(elemtot * sizeof(int *));
	
	x = (double*)malloc(nodostot * sizeof(double));
	y = (double*)malloc(nodostot * sizeof(double));
	z = (double*)malloc(nodostot * sizeof(double));
	int q2;
	for (int i = 0; i < elemSnum; i++) {
		numbS[i] = (int*)malloc(6 * sizeof(int));
	}
	for (int i = 0; i < (elemtot); i++)
	{
		numb[i] = (int*)malloc(10 * sizeof(int));
	}
	for (int i = 0; i < (elemtot); i++)
	{
		numbR[i] = (int*)malloc(10 * sizeof(int));
	}
	double x2;
	for (int i = 0; i < nodostot; i++)
	{
		inFile >> x2;
		x[i] = (2.0-x2)*Lx/2.0-Lx/2.0;//(2.0 - x2) * Lx / 2.0 - Lx / 2.0;
		inFile >> x2;
		z[i] = x2* Lz/2.0 - Lz / 2.0;
		inFile >> x2;
		y[i] = (x2)*Ly / 2.0 - Ly / 2.0;
	}
	
	int value1, value2, value3;
	int cont2 = 0;
	
	for (int i = 0; i < elemSnum; i++)
	{
		inFile >> numbS[i][0];
		inFile >> numbS[i][1];
		inFile >> numbS[i][2];
		//inFile >> numbS[i][3];
		//inFile >> numbS[i][4];
		//inFile >> numbS[i][5];

		value1 = numbS[i][0];
		value2 = numbS[i][1];
		value3 = numbS[i][2];

		int *values;		
		for (int h = 0; h <3; h++)
		{
			min = numbS[i][arr1[h][0]] - 1;
			max = numbS[i][arr1[h][1]] - 1;
			mintemp = min;
			if (max < min)
			{
				min = max;
				max = mintemp;
			}
			sizeF = elemN[min].size();
			bool actualizar = false;
			if (sizeF != 0)
			{
				int l = 0;
				bool salir = false;
				while (salir == false)
				{
					if (elemN[min][l] == (max))
					{
						actualizar = false;
						salir = true;
					}
					else
					{
						actualizar = true;
					}
					l = l + 2;
					if (l >= sizeF)
					{
						salir = true;
					}
				}
			}
			else
			{
				actualizar = true;
			}
			if (actualizar == true)
			{
				elemN[min].push_back(max);
				elemN[min].push_back(cont);
				/*enumFa[j].contO.push_back(cont);
				if (j != 5)
				{
					ladosSup = ladosSup + 2;
				}*/
				cont = cont + 2;
			}
		}
		values = order(value1, value2, value3);
		sizeF = elemIDF[values[0]].size();
		bool actualizar = false;
		if (sizeF != 0)
		{
			int l = 0;
			bool salir = false;
			while(salir==false)
			{
				if ((elemIDF[values[0]][l] == (values[1])) && (elemIDF[values[0]][l + 1] == (values[2])))
				{
					actualizar = false;		
					salir = true;
				}
				else
				{
					actualizar = true;
				}
				l = l + 4;
				if (l >= sizeF)
				{
					salir = true;
				}
			}		
		}
		else
		{
			actualizar = true;
		}
		if (actualizar == true)
		{
			elemIDF[values[0]].push_back(values[1]);
			elemIDF[values[0]].push_back(values[2]);
			elemIDF[values[0]].push_back(cont);		
			if((z[values[0]] == 0.0) && (z[values[1]] ==0.0) && (z[values[2]] == 0.0))
			{
				//elemIDF[values[0]].push_back(1);
				//elemIDF[values[0]].push_back(2);
				elemIDF[values[0]].push_back(0);
			}
			else
			{								
				//elemIDF[values[0]].push_back(1);
				//elemIDF[values[0]].push_back(2);
				elemIDF[values[0]].push_back(1);				
			}
			cont = cont + 2;
		}		
	}
	vector<vector<int > >info;	
	int edgenumber = 0;
	edgenumber = cont - 1;
	//cout <<"EDGENUMBER: "<< edgenumber << endl;
	
	//vector<vector<int> >edges(nodostot);
	double  G[4][4];
	double Ginv[4][4];
	int cof[4];
	double a[4], b[4], c[4], d[4];
	double yz34, yz24, yz23, yz14, yz13, yz12, Ve;
	double xz34, xz24, xz23, xz14, xz13, xz12;
	double xy34, xy24, xy23, xy14, xy13, xy12;
	double valI[6][6], valR, facR, facI;
	double*nk1, *nk2, rit[3];	
	//int arr[6][2] = { {0,1},{0,2},{0,3},{1,2},{3,1},{2,3} };
	complex <double> K[20][20];
	int ar1, ar2;
	double f[6][6], L[6];
	1, yz13, yz12;
	int l1, l2, l3, l4;
	facI = pow(10.0, 13.0);
	int i1, i2, j1, j2;
	int LN[10];
	double ResC=1.0;
	double Resis = 0.0;
	int EN[20], imin, imax;
	int **numbST, **indST, **numbT, **indnumb;
	numbST = (int**)malloc(elemS[8] * sizeof(int *));
	numbT = (int**)malloc(elemS[8] * sizeof(int *));
	indST = (int**)malloc(elemS[8] * sizeof(int *));
	indnumb = (int**)malloc(elemS[8] * sizeof(int *));
	vector<int>numSE;
	vector<int> vec1(3), vec2(3), vec3(3), vec4(3);
	
	int acu[4], acu2[4], acu3;
	int acS[6];
	bool ver[4];
	
	double maxV3 = 0.0, maxL;
	int IDV3;
	for (int j = 0; j < (elemtot); j++)
	{
		inFile >> numb[j][0];
		inFile >> numb[j][1];
		inFile >> numb[j][2];
		inFile >> numb[j][3];
		numbR[j][0]= numb[j][0];
		numbR[j][1] = numb[j][1];
		numbR[j][2] = numb[j][2];
		numbR[j][3] = numb[j][3];
		for (int i = 0; i < 6; i++)
		{
			imin = arr[i][0];
			imax = arr[i][1];

			min = numbR[j][imin] - 1;
			max = numbR[j][imax] - 1;			
			mintemp = min;
			if (max < min)
			{
				min = max;
				max = mintemp;
			}
			sizeF = elemN[min].size();
			bool actualizar = false;
			if (sizeF != 0)
			{
				int l = 0;
				bool salir = false;
				//cout << sizeF << endl;
				while (salir == false)
				{
					if (elemN[min][l] == (max))
					{
						actualizar = false;
						salir = true;
						//salir = true;
					}
					else
					{
						actualizar = true;
					}
					l = l + 2;
					if (l >= sizeF)
					{
						salir = true;
					}
				}
			}
			else
			{
				actualizar = true;
			}
			if (actualizar == true)
			{
				elemN[min].push_back(max);
				elemN[min].push_back(cont);
				//cout << cont<< endl;			
				cont = cont + 2;
			}
			
		}
		
		for (int i = 0; i < 4; i++)
		{
			bool chk = false;
			value1 = numbR[j][arr2[i][0]];
			value2 = numbR[j][arr2[i][1]];
			value3 = numbR[j][arr2[i][2]];
			int *values;
			values = order(value1, value2, value3);
			sizeF = elemIDF[values[0]].size();
			vector <int>vec2;
			bool actualizar = false;
			if (sizeF != 0)
			{
				int l = 0;
				bool salir = false;
				//cout << sizeF << endl;
				while (salir == false)
				{
					if ((elemIDF[values[0]][l] == (values[1])) && (elemIDF[values[0]][l + 1] == (values[2])))
					{
						if (elemIDF[values[0]][l + 3] == 1)
						{		
							vec2.push_back(j);
							vec2.push_back(i);
							info.push_back(vec2);
							actualizar = false;
						}
						actualizar = false;						
						salir = true;
					}
					else
					{
						actualizar = true;
					}
					l = l + 4;
					if (l >= sizeF)
					{
						salir = true;
					}
				}
			}
			else
			{
				actualizar = true;
			}
			if (actualizar == true)
			{
				elemIDF[values[0]].push_back(values[1]);
				elemIDF[values[0]].push_back(values[2]);
				elemIDF[values[0]].push_back(cont);
				elemIDF[values[0]].push_back(0);
				
				cont = cont + 2;
			}
		}
		int con2 = 0, con3 = 0, con4 = 0, con5 = 0;
	}
	int indx1, indx2, indxf, indxl;	
	int elemNumb;
	ladostot = cont - 1;
	//cout << "ladostot:" << ladostot << endl;	
	double minX = 16.0, minY = 16.0, maxY = -16.0, maxX = -16.0;
	int minXID, minYID, maxYID, maxXID, nodN, maxXi, minXi, maxYi, minYi, ytemp, xtemp;
	double SumX, SumY, SumA;
	int contS, med;
	
	double uc[3], PosR[10][3], N[4];
	double GM[4][4];
	double cofT[3][4];
	double dN[4][3];
	double PosT[3], rotU[20][3], W[20][3];
	double roto[27][3];
	double Vol;
	double maxT = -1000.0, minT = 1000.0;
	double maxi = 0.0, mini = 0.0, maxi2 = 0.0;
	int maxiID1 = 0, maxiID2 = 0;
	int elemNumi = 1000;
	complex<double>K1 = 0.0, K2 = 0.0;
	double yf1, yf2, xf1, xf2, medX, medY, xpos1, xpos2, xpos3, ypos1, ypos2, ypos3, resist;
	//cout << info.size() << endl;	
	double *Fq;
	int numFreq;
	double freqVal;
	evalCoords >> numFreq;
	Fq = (double*)malloc(numFreq * sizeof(double));
	for (int i = 0; i < numFreq; i++)
	{
		evalCoords >> freqVal;
		Fq[i] = freqVal;
	}
	double ResH = 100.0;
	//if(int i=0;i<volumeNumb;i++)
	//evalCoords >> numC;
	evalCoords.close();
	/*double Fq[8];
	double fa, fb, df;
	fb = log10(1000.0);
	fa = log10(1.0);
	df = (fb - fa) / (16.0);
	for (int i = 0; i <16; i++)
	{
		Fq[i] = pow(10.0, fa+(double)(df*i));
	}*/
	//int numFreq=8;
	
	double wr,mu0;
	//int *tams
	int **fqL;
	fqL = (int**)malloc(size_of_cluster * sizeof(int *));
	
		for (int i = 0; i < size_of_cluster; i++) {
		fqL[i] = (int*)malloc(2 * sizeof(int));
		}

	//tams = (int*)malloc(size_of_cluster* sizeof(int));
	double div=(double)numFreq/(double)(size_of_cluster);
	for(int i=0;i<size_of_cluster;i++)
	{
	fqL[i][0]=(int)(i*div);
	fqL[i][1]=(int)((i+1)*div);
	}
	int fq1,fq2;
	fq1=fqL[process_num][0];
	fq2=fqL[process_num][1];
	double *transfer;
	transfer = (double*)malloc((int)((fq2-fq1)*21*numCoords)*sizeof(double));
	double *pedazoFinal;
	pedazoFinal = (double*)malloc((int)((numFreq)*21*numCoords)*sizeof(double));

	int acut=0;
	
	cout<<"fq1: "<<fq1<<"fq2: "<<fq2<<endl;
	mu0 = 4.0 * M_PI*pow(10.0, -7.0);
	double Freq;
	time(&start2);
	for (int fq = fq1; fq < fq2; fq++)
	{ 
		Freq =(double)Fq[fq];
		//cout << "Frecuencia: " << Freq << endl;
		
		vector<vector <complex<double > > >KM2;
		vector<vector <complex<double > > >KM(ladostot);
		vector<vector<int > >ID(ladostot);
		vector<vector<int > >ID3(ladostot);
		vector<vector<int > >ID2(ladostot);
		vector<vector<int > >DIR(ladostot);

		wr = 2.0 * M_PI*Freq;
		complex<double>vecR1(0.0, mu0 / ResA * wr), vecR2(0.0, mu0 / ResH * wr);
		k0 = sqrt(vecR1);
		k1 = sqrt(vecR2);
		C = H0;
		A.real((double)(H0.real() / 2.0 + H0.real()*pow(10.0, 4.0)*sqrt(3.3 / ResH) / 2.0));	A.imag(0.0);
		B.real(C.real() - A.real());
		B.imag(C.imag() - A.imag());
		for(int pol=0;pol<2;pol++)
		{ 
			vector<complex<double > >DV(ladostot, 0.0);
			int*varc;
			varc = (int*)malloc(ladostot * sizeof(int));
			if(pol==1)
			{
			vector<int>vecID, vecID3;
			}
			vector<int>cond(edgenumber, 0);	
			ladosSup = 0;
			//vector<vector <complex <double> > >dirichV(dirichNum);
			vector<complex<double > >dirichVN(edgenumber, 0);
			vector<int >dirichI(edgenumber, 0);
			vector<complex<double > >vecM;
			vector<doublecomplex>AR;
			vector<int>ja2;
			for (int i = 0; i < info.size(); i++)
			{
				elemNumb = info[i][0];
				int numL, medX;
				for (int p = 0; p < 4; p++)
				{
					LN[p] = numbR[elemNumb][p] - 1;
				}
				int p3 = 0;
				int i3, i4,min2,max2,LN3,vals[2];
				for (int h = 0; h < 3; h++)
				{
					min = LN[arr2[info[i][1]][arr1[h][0]]];
					max = LN[arr2[info[i][1]][arr1[h][1]]];
					mintemp = min;
					if (max < min)
					{
						min = max;
						max = mintemp;
					}
					sizeF = elemN[min].size();
					//bool actualizar = false;
					int contN4;
					if (sizeF != 0)
					{
						int l = 0;
						bool salir = false;
						contN4 = -1;
						while (salir == false)
						{
							if (elemN[min][l] == (max))
							{
								contN4 = (int)elemN[min][l + 1] - 1;
								salir = true;
							}
							l = l + 2;
							if (l >= sizeF)
							{
								salir = true;
							}
						}
						if (contN4 == -1)
						{
							//cout << "error" << endl;
						}
					}
					else
					{
						//cout << "wrong!" << endl;
					}
					if (dirichI[contN4] == 0)
					{
						double lx, zvalor = 15.0, xn, yn, zn, xnv, ynv;
						complex<double>result,E0;
						lx = (double)sqrt(pow(x[max] - x[min], 2.0) + pow(y[max] - y[min], 2.0) + pow(z[max] - z[min], 2.0));

						for (int r = 0; r < 2; r++)
						{
							if (r == 0)
							{
								zn = (double)z[min] + (double)(z[max] - z[min]) / 3.0;
							}
							else
							{
								zn = (double)z[min] + 2.0*(z[max] - z[min]) / 3.0;
							}
							if ((z[max] >= 0.0) && (z[min] >= 0.0))
							{
								E0 = (complex<double>)A * (complex<double>)exp((complex<double>)k0 * (complex<double>)zn * valC) + (complex<double>)B * (complex<double>) exp(-(complex<double>)k0 * (complex<double>)zn * valC);
							}
							else
							{
								E0 = (complex<double>)C * (complex<double>)exp((complex<double>)k1 * (complex<double>)zn * valC);
							}
							if ((z[max] == -Lz / 2.0) && (z[min] == -Lz / 2.0))
							{
								E0 = 0.0;
							}
							double control3 = 0.0;
							if (pol == 1)
							{
								control3 = (y[max] - y[min]);
							}
							else
							{
								control3 = (x[max] - x[min]);
							}
							result = E0 * (complex<double>) control3 / (complex<double>) lx;
							dirichI[contN4 + r] = 1;
							ladosSup++;
							dirichVN[contN4+r] = result;
							cond[contN4 + r] = 1;
						}

					}
				}		
				//bool chk = false;
				value1 = numbR[elemNumb][arr2[info[i][1]][0]];
				value2 = numbR[elemNumb][arr2[info[i][1]][1]];
				value3 = numbR[elemNumb][arr2[info[i][1]][2]];
				int *values;
				values = order(value1, value2, value3);
				sizeF = elemIDF[values[0]].size();
				vector <int>vec2;
				int ind1[3], contN;
				bool actualizar = false;
				//cout << "Donee1" << endl;
				if (sizeF != 0)
				{
					int l = 0;
					bool salir = false;

					while (salir == false)
					{
						if ((elemIDF[values[0]][l] == (values[1])) && (elemIDF[values[0]][l + 1] == (values[2])))
						{
							if (elemIDF[values[0]][l + 3] == 1)
							{
								contN = elemIDF[values[0]][l + 2];
								ind1[0] = 1;// elemIDF[values[0]][l + 3];
								ind1[1] = 2;// elemIDF[values[0]][l + 4];
								ind1[2] = 3;
								actualizar = true;
							}
							else
							{
								actualizar = false;
							}
							salir = true;
						}
						else
						{
							actualizar = false;
						}
						l = l + 4;
						if (l >= sizeF)
						{
							salir = true;
						}
					}
				}
				int LN1, LN2;
			
				if (actualizar == true)
				{
					double zn,lx;
					complex <double>E0, result;
					complex<double>E1;
					int q = 0,LN3,LN4,q1=0,LN5[3],i3;
					LN3 = values[0];
					LN4 = values[2];
					LN5[0] = values[2];
					LN5[1] = values[0];
					LN5[2] = values[1];
					for (int p = 0; p < 2; p++)
					{	
						LN1 = values[arr1[p][0]];
						LN2 = values[arr1[p][1]];
						lx = sqrt(pow(x[LN2] - x[LN1], 2.0) + pow(y[LN2] - y[LN1], 2.0) + pow(z[LN1] - z[LN2], 2.0));
						double zmed1, zmed2, znb;
						complex<double>E1;
						zmed1 = (z[LN1] + z[LN2]) / 2.0;
						zmed2 = (z[LN3] + z[LN4]) / 2.0;
						zn = zmed1 + (z[LN5[2]] - zmed1) / 3.0;
						znb = zmed2 + (z[LN5[p]] - zmed2) / 3.0;
						if ((zn >= 0.0) && (znb >= 0.0))
						{
							E0 = (complex<double>)A * (complex<double>)exp((complex<double>)k0 * (complex<double>)zn * valC) + (complex<double>)B * (complex<double>) exp(-(complex<double>)k0 * (complex<double>)zn * valC);
							E1 = (complex<double>)A * (complex<double>)exp((complex<double>)k0 * (complex<double>)znb * valC) + (complex<double>)B * (complex<double>) exp(-(complex<double>)k0 * (complex<double>)znb * valC);
						}
						else
						{
							E0 = (complex<double>)C * (complex<double>)exp((complex<double>)k1 * (complex<double>)zn * valC);
							E1 = (complex<double>)C * (complex<double>)exp((complex<double>)k1 * (complex<double>)znb * valC);
						}
						if ((zn == -Lz / 2.0) && (zn == -Lz / 2.0))
						{
							E0 = 0.0;
							E1 = 0.0;
						}
						double control1 = 0.0, control2 = 0.0;
						if (pol == 1)
						{
							control1 = (y[LN2] - y[LN1]);
							control2 = (y[LN4] - y[LN3]);
						}
						else
						{
							control1 = (x[LN2] - x[LN1]);
							control2 = (x[LN4] - x[LN3]);

						}
						result = (complex<double>)(E0 * (complex<double>)control1 / (complex<double>)lx - E1 * (complex<double>)control2 / (complex<double>)lx);
						ladosSup++;
						dirichVN[contN - 1 + p] = result;
						cond[contN - 1 + p] = 1;
					}
				}		
				//cout << "Done" << endl;
			}
			doublecomplex*xR, *bv;
			int*ia;
			int    numV;
			numV = (int)(ladostot - ladosSup);
			//cout << numV << endl;
			int p3 = 0;
				
			double toli=0.0;
			int indix,indiy;
			xR = (doublecomplex*)malloc(numV * sizeof(doublecomplex));
			bv = (doublecomplex*)malloc(numV * sizeof(doublecomplex));
			ia = (int*)malloc((numV + 1) * sizeof(int));
			int numbP[8][3],q = 0,q3=0,ind1[3], contN,l=0;
			bool actualizar=false,salir;
			int LN1, LN2,LN3,i3,s,s2;
			int fr[2], frtemp,fm,pw;
			int q2 = 12;
			double sumt[3], sumt2[3], sumt3[3], sumt4[3], SumT,result1,result2,resultN;
			complex <double>Rresult;
			double sum = 0.0,GE[3][3];
			double cofA[4][4];
			double detT;
			double lx;
			bool chk3=false;
			s=0;
			int p5 = 2;
			int idx = 0;
			int f1, f2, f3;
			if(pol==0)
			{
			for (int i = 0; i < elemtot; i++)
			{		
				for (int j = 0; j < 4; j++)
				{
					LN[j] = numbR[i][j] - 1;
					PosR[j][0] = x[LN[j]];
					PosR[j][1] = y[LN[j]];
					PosR[j][2] = z[LN[j]];
				}
				for (int m = 0; m < 20; m++)
				{
					for (int n = 0; n < 20; n++)
					{
						K[m][n]=0.0;
					}
				}
		
				if (i < volE[0])
				{
					Resis = ResA;
				}
				else
				{
					Resis = ResH;
				}
				if (elemNumb > 2)
				{
					if (i >= (volE[0] + volE[1]))
					{
						Resis = ResC;///(1.0/100.0-0.00000001);//0.0001
					}
				}
				q = 0;
				q3=0;
				s=0;
				int contN3;
				for (int j = 0; j < 6; j++)
				{
					imin = arr[j][0];
					imax = arr[j][1];

					min = LN[imin];
					max = LN[imax];
					mintemp = min;
					if (max < min)
					{
						min = max;
						max = mintemp;
					}
					sizeF = elemN[min].size();
					bool actualizar = false;
					if (sizeF != 0)
					{
						int l = 0;
						bool salir = false;
						//cout << sizeF << endl;
						while (salir == false)
						{
							if (elemN[min][l] == (max))
							{
								contN3 = elemN[min][l + 1];
								EN[q3] = contN3 - 1;
								EN[q3 + 1] = contN3;
								if ((contN3) < edgenumber)
								{
									condL[q3] = cond[contN3 - 1];
									condL[q3 + 1] = cond[contN3];
								}
								else
								{
									condL[q3] = 0;
									condL[q3 + 1] = 0;
								}
								q3 = q3 + 2;
								//actualizar = false;
								salir = true;
								//salir = true;
							}
							l = l + 2;
							if (l >= sizeF)
							{
								salir = true;
								//cout << "sosos" << endl;
							}
							/*else
							{
								cout << "sasasa" << endl;
							}*/
						}
					}
					else
					{
						//cout << "que2!" << endl;
					}
				}
				for (int j = 0; j < 4; j++)
				{
					//chk3 = false;
					value1 = numbR[i][arr2[j][0]];
					value2 = numbR[i][arr2[j][1]];
					value3 = numbR[i][arr2[j][2]];
					int *values;
					values = order(value1, value2, value3);			
					sizeF = elemIDF[values[0]].size();					
					actualizar = false;
					if (sizeF != 0)
					{
						l = 0;
						salir = false;
						while (salir == false)
						{
							if ((elemIDF[values[0]][l] == (values[1])) && (elemIDF[values[0]][l + 1] == (values[2])))
							{						
									contN=elemIDF[values[0]][l + 2];
									EN[q3] = contN - 1;
									EN[q3+1] = contN;							
									ind1[0] = 1;//elemIDF[values[0]][l + 3];
									ind1[1] = 2;// elemIDF[values[0]][l + 4];
									ind1[2] = 3;
									if (elemIDF[values[0]][l + 3] == 1)
									{
										condL[q3] = 1;
										condL[q3+1] = 1;
									}
									else
									{
										condL[q3] = 0;
										condL[q3 + 1] = 0;
									}
								
									actualizar = true;
								salir = true;
							}
							l = l + 4;
							if (l >= sizeF)
							{
								salir = true;
							}
						}
					}
					else
					{
						//cout << "que?" << endl;
					}					
					for (int p = 0; p < 2; p++)
					{
						i1 = ar3[ind1[p]-1][0];
						i2 = ar3[ind1[p]-1][1];
						i3 = ar3[ind1[p]-1][2];			
						LN1 = values[i1]+1;
						LN2 = values[i2]+1;
						LN3 = values[i3]+1;
						for (int m = 0; m < 4; m++)
						{
							if (LN2 == (numbR[i][m]))
							{
								numbP[q][1] = m;
						
							}
							if (LN3 == numbR[i][m])
							{
								numbP[q][2] = m;
							}
							if (LN1 == numbR[i][m])
							{
								numbP[q][0] = m;
							}
						}
						q = q + 1;
						q3 = q3 + 1;			
					}
					free(values);	
				}
				pw=0;
				for (int m = 0; m < 4; m++)
				{
					for (int n = 0; n < 4; n++)
					{
						if (n == 0)
						{
							GM[m][n] = 1.0;
						}
						else
						{
							GM[m][n] = (double)CF[m][n - 1];
						}
					}
				}
				
				double **invT;
				invT = inv4(GM);
				for (int m = 0; m < 4; m++)
				{
					for (int n = 0; n < 4; n++)
					{				
							cofA[m][n] = invT[n][m];
					}
				}
				free(invT);
				
				double **GEinv;
				sum = 0.0;
				for (int t = 0; t < 3; t++)
				{
					for (int m = 0; m < 3; m++)
					{
						sum = 0.0;
						for (int n = 0; n < 4; n++)
						{
							sum = sum + G3inv[t + 1][n] * PosR[n][m];
						}
						GE[t][m] = sum;
					}
				}
				GEinv = inv3(GE);		
				
				detT = GE[0][0] * (GE[1][1] * GE[2][2] - GE[1][2] * GE[2][1]) + GE[0][1] * (GE[1][2] * GE[2][0] - GE[2][2] * GE[1][0]) + GE[0][2] * (GE[1][0] * GE[2][1] - GE[1][1] * GE[2][0]);
				
				for (int k = 0; k < ordenN; k++)
				{			
					
					for (int p = 0; p < 4; p++)
					{
						N[p] = (cofA[p][0] + cofA[p][1] * ux[k] + cofA[p][2] * uy[k] + cofA[p][3] * uz[k]);				
						for (int m = 0; m < 3; m++)
						{
							if (p < 3)
							{
								dN[p][m] = GEinv[m][p]; 
						
							}
							else
							{
								dN[p][m] = -(dN[0][m] + dN[1][m] + dN[2][m]);
							}
						}
					}
					pw = 0;
					for (int p = 0; p < 6; p++)
					{
						fr[0] = arr7[p][0];
						fr[1] = arr7[p][1];
						frtemp = fr[0];
						if (LN[fr[1]] < LN[fr[0]])
						{
							fr[0] = fr[1];
							fr[1] = frtemp;
						}				
						for (int r = 0; r < 2; r++)
						{
							double *n1, *n2,*n3;
							//f1 = arr5[p][0];
							//f2 = arr5[p][1];
							//f3 = arr5[p][2];
							lx = sqrt(pow(x[LN[fr[1]]] - x[LN[fr[0]]], 2.0) + pow(y[LN[fr[1]]] - y[LN[fr[0]]], 2.0) + pow(z[LN[fr[1]]] - z[LN[fr[0]]], 2.0));
							for (int m = 0; m < 3; m++)
							{
								W[pw][m] = (3.0*N[fr[r]] - 1.0)*lx*(N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);								

							}
							n1 = crossP(dN[fr[0]], dN[fr[1]]);
							n2 = crossP(dN[fr[r]], dN[fr[0]]);
							n3 = crossP(dN[fr[r]], dN[fr[1]]);
							for (int m = 0; m < 3; m++)
							{
								rotU[pw][m] = (double)lx*((2.0*n1[m] *(3.0*N[fr[r]] - 1.0)) + (double)3.0*(N[fr[0]]*n3[m]-N[fr[1]]*n2[m]));
							}
							pw++;
							free(n1);
							free(n2);
							free(n3);
						}
					}
					q2 = 12;
					//double sumt[3], sumt2[3], sumt3[3], sumt4[3], SumT,result1,result2;
					//complex <double>Rresult;
					//int p5 = 2;
					idx = 0;
					//int f1, f2, f3;
					for (int u = 0; u < 4; u++)
					{
						int ck = 0;
						for (int p = 0; p < 2; p++)
						{					
							double *n1, *n2,*n3;
							
							f1 = numbP[idx][0];
							f2 = numbP[idx][1];
							f3 = numbP[idx][2];
							idx++;
							//double ad=0.0,temp[3],temp2[3];					
							lx = sqrt(pow(x[LN[f3]] - x[LN[f2]], 2.0) + pow(y[LN[f3]] - y[LN[f2]], 2.0) + pow(z[LN[f3]] - z[LN[f2]], 2.0));
							//lx2 = sqrt(pow(x[LN[f6]] - x[LN[f5]], 2.0) + pow(y[LN[f6]] - y[LN[f5]], 2.0) + pow(z[LN[f6]] - z[LN[f5]], 2.0));
							for (int m = 0; m < 3; m++)
							{
								W[q2][m] = (3.0*N[f1])*lx*(N[f2] * dN[f3][m] - N[f3] * dN[f2][m]);// / Vol;	
							}
							n1 = crossP(dN[f2], dN[f3]);
							n2 = crossP(dN[f1],dN[f2]);
							n3 = crossP(dN[f1], dN[f3]);
							for (int m = 0; m < 3; m++)
							{
								rotU[q2][m] =  lx * ((2.0*n1[m] * (3.0*N[f1])) + (double)3.0*(N[f2] * n3[m] - N[f3] * n2[m]));
							}
							free(n1);
							free(n2);
							free(n3);
							q2++;
						}
					}
					//p5 = 2;
			
					for (int m = 0; m < 20; m++)
					{
						for (int n = 0; n < 20; n++)
						{
							if (m >= n)
							{
								result1 = 0.0; result2 = 0.0;
								for (int o = 0; o < 3; o++)
								{							
									result1 = result1 + W[m][o] * W[n][o];
									result2 = result2 + rotU[m][o] * rotU[n][o];
								}
								Rresult =(complex<double>)Pesos[k] * (result2*pow(10.0,2.0) + (complex<double>)im * wr*mu0*pow(10.0, 8.0) * (complex<double>)result1/(complex<double>)Resis)*detT;
								K[m][n] = K[m][n] + Rresult;
								K[n][m] = K[m][n];						
							}
						}
					}
				}				
				free(GEinv);
		
				//p5 = 2;
				for (int m = 0; m < 20; m++)
				{
					if (condL[m] == 0)
					{
						for (int n = 0; n < 20; n++)
						{
							sizeF = ID[EN[m]].size();
							valF = distance(ID[EN[m]].begin(), find(ID[EN[m]].begin(), ID[EN[m]].end(), EN[n] + 1));
							if ((sizeF == 0) || (valF == sizeF))
							{						
								KM[EN[m]].push_back(K[m][n]);
								ID[EN[m]].push_back(EN[n] + 1);
								ID3[EN[m]].push_back(ID[EN[m]].size() - 1);
								if (condL[n] != 0)
								{							
									DIR[EN[m]].push_back(EN[n] + 1);
									ID2[EN[m]].push_back(ID[EN[m]].size());
								}
							}
							else
							{						
								KM[EN[m]][valF] = KM[EN[m]][valF] + K[m][n];
							}
						}
					}
				}
			}
			}
			//cout << "Ensamblaje terminado" << endl;
			complex<double>Sd;
			int id = 0, id2 = 0, ac = 0;
			max = 0;	
			int chk;
			int acuN=0;	
			for (int p = 0; p < ladostot; p++)
			{
				DV[p] = 0.0;
				chk = 0;
				if (p < edgenumber)
				{
					chk = cond[p];
				}
				if (chk == 0)
				{
					Sd = 0.0;
					vector <complex<double > >newV;
					for (int i = 0; i < DIR[p].size(); i++)
					{
						id = DIR[p][i] - 1;
						id2 = ID2[p][i] - 1;
						if(pol==0)
						{
						newV.push_back(KM[p][id2]);
						}
						else
						{
						KM[p][id2]=KM2[acuN][i];
						}
						Sd = Sd + (complex<double>) KM[p][id2] * (complex<double>)dirichVN[id];
						KM[p][id2].real(0.0);
						KM[p][id2].imag(0.0);
					}
					acuN++;
					if(pol==0)
					{
					KM2.push_back(newV);
					}
					newV.erase(newV.begin(), newV.end());
					DV[p] = DV[p] - Sd;
					varc[p] = ac;
				}
				else
				{
					ac = ac + 1;			
					varc[p] = ac;
				}
			}			
			doublecomplex refV;
			int numS2 = 0;
			q = 0;
			int p2 = -1;
			int rt;
			for (int p = 0; p < ladostot; p++)
			{
				chk = 0;
				if (p < edgenumber)
				{
					chk = cond[p];
				}
				if (chk == 0)
				{
			
					p2 = p2 + 1;
					vecID = ID[p];
					vecID3 = ID3[p];
					std::vector<int> vec(vecID3.size());
					IncGenerator g(0);
					std::generate(vec.begin(), vec.end(), g);
					sort(vec.begin(), vec.end(), myfunction);
					//iota(vecID3.begin(), vecID3.end(), 0);
					//sort(vecID3.begin(), vecID3.end(),
					//[&vecID](size_t i1, size_t i2) {return vecID[i1] < vecID[i2]; });
			
					rt = 0;
					for (int i = 0; i < ID[p].size(); i++)
					{				
						id = vec[i];
						id2 = ID[p][id] - 1;				
						if (id2 >= p)
						{
							if (abs(KM[p][id]) > pow(10.0, -10.0))
							{			
								refV.re =KM[p][id].real();
								refV.i = KM[p][id].imag();
								AR.push_back(refV);						
								ja2.push_back(id2 - varc[id2]);
								numS2 = numS2 + 1;
								q = q + 1;
							}
						}
						if ((id2) == p)
						{
							rt = rt + 1;
							ia[p2] = (numS2 - 1);
						}				
					}
					if (rt == 0)
					{
						//cout << "Que?" << endl;
					}
					bv[p2].re =  DV[p].real();
					bv[p2].i = DV[p].imag();
				}
			}
			ia[numV] = (numS2);
			//cout << "numT " << q << endl;
			//cout << "BV" << bv[255].re << endl;
			int numT;
			numT = q;
			doublecomplex*aR;
			int*ja;
			aR = (doublecomplex*)malloc(numT * sizeof(doublecomplex));
			ja = (int*)malloc(numT * sizeof(int));
			for (int i = 0; i < numT; i++)
			{
				aR[i].re = AR[i].re;
				aR[i].i = AR[i].i;
				ja[i] = ja2[i];
			}
			vecID.erase(vecID.begin(), vecID.end());
			vecID3.erase(vecID3.begin(), vecID3.end());
			AR.erase(AR.begin(), AR.end());
			vecM.erase(vecM.begin(), vecM.end());
			
			if(pol==1)
			{
			DIR.erase(DIR.begin(), DIR.end());
			ID2.erase(ID2.begin(), ID2.end());
			ID3.erase(ID3.begin(), ID3.end());
			ID.erase(ID.begin(), ID.end());
			KM.erase(KM.begin(), KM.end());
			KM2.erase(KM2.begin(), KM2.end());
			}
			//cout << "El tam de la matriz es de long: " << p2 + 1 << endl;
			
			int      nnz = ia[numV];
			int      mtype = 6;
			int      nrhs = 1;
			void    *pt[64];
			int      iparm[64];
			int      maxfct, mnum, phase, error, msglvl, solver;
			double   dparm[64];
			int      num_procs;
			doublecomplex   ddum;
			int	      idum;
			char *pValue;
			size_t len;
			char*var;
			int      i;
			for (i = 0; i < 64; i++) {
				pt[i] = 0;
			}
			for (i = 0; i < 64; i++) {
				iparm[i] = 0;
			}
			mkl_set_num_threads(15);
			iparm[0] = 1;
			iparm[1] = 2;
			iparm[2] = 15;//(int)pValue;// num_procs;
			maxfct = 1;
			mnum = 1;
			msglvl = 1;
			error = 0;
			for (i = 0; i < numV + 1; i++) {
				ia[i] += 1;
			}
			for (i = 0; i < nnz; i++) {
				ja[i] += 1;
			}
			error = 0;
			solver = 0;
			//pardisoinit(pt, &mtype, &solver, iparm, dparm, &error);
			//pardiso_chkmatrix_z(&mtype, &numV, aR, ia, ja, &error);
			//pardiso_chkvec_z(&numV, &nrhs, bv, &error);
			//pardiso_printstats_z(&mtype, &numV, aR, ia, ja, &nrhs, bv, &error);
			phase = 11;
			pardiso(pt, &maxfct, &mnum, &mtype, &phase,
				&numV, aR, ia, ja, &idum, &nrhs,
				iparm, &msglvl, &ddum, &ddum, &error);
			if (error != 0) {
				cout << ("\nERROR during symbolic factorization: %d", error) << endl;
				exit(1);
			}
			phase = 22;
			//cout << ("\nReordering completed ... ") << endl;
			pardiso(pt, &maxfct, &mnum, &mtype, &phase,
				&numV, aR, ia, ja, &idum, &nrhs,
				iparm, &msglvl, &ddum, &ddum, &error);
			if (error != 0) {
				cout << ("\nERROR during numerical factorization: %d", error) << endl;
				exit(2);
			}
			//cout << ("\nFactorization completed ...\n ") << endl;
			phase = 33;
			iparm[7] = 2;
			pardiso(pt, &maxfct, &mnum, &mtype, &phase,
				&numV, aR, ia, ja, &idum, &nrhs,
				iparm, &msglvl, bv, xR, &error);
			if (error != 0) {
				cout << ("\nERROR during solution: %d", error) << endl;
				exit(3);
			}
			//cout << ("\nSolve completed ... ") << endl;
			//if(pol==0)
			//{
				
				//time(&finish);
				//cout << "Time required = " << difftime(finish, start) << " seconds"<<endl;

			double vm2, rss2;
			process_mem_usage(vm2, rss2);
   			//cout << "VM: " << vm2 << "; RSS: " << rss2 << endl;
			//}
			for (i = 0; i < numV + 1; i++) {
				ia[i] -= 1;
			}
			for (i = 0; i < nnz; i++) {
				ja[i] -= 1;
			}

			phase = -1;

			pardiso(pt, &maxfct, &mnum, &mtype, &phase,
				&numV, &ddum, ia, ja, &idum, &nrhs,
				iparm, &msglvl, &ddum, &ddum, &error);
			
			
			mkl_free_buffers();
			
			
			
			vector <complex <double > >result;
			complex <double> valP;
			double l6;
			int n1 = 0;
			for (int p = 0; p < ladostot; p++)
			{
				chk = 0;
				if (p < edgenumber)
				{
					chk = cond[p];
				}
				if (chk == 0)
				{
					valP.imag((double)xR[n1].i);
					valP.real((double)xR[n1].re);
					result.push_back(valP);
					n1++;
				}
				else
				{
					result.push_back(dirichVN[p]);
				}
			}
			cond.erase(cond.begin(), cond.end());
			double yslice = 0.0;
			double minN = 16.0, maxN = -16.0;
			
			int IDMIN = 0;
			int valueI;
			//evx[i]
			double vecA[3], vecB[3], vecC[3], sumV;
			int numbC[4];
			for(int k=0;k<numCoords;k++)
			{
			vector <int> orden1;
			for (int p = 0; p < (elemtot); p++)
			{
				minN = 100.0;
				maxN = -100.0;
				for (int i = 0; i < 4; i++)
				{
					valueI = numbR[p][i] - 1;
					if (z[valueI] < minN)
					{
						minN = z[valueI];
					}
					if (z[valueI] > maxN)
					{
						maxN = z[valueI];
					}
				}
				if ((maxN >= evz[k]) && (minN <= evz[k]))
				{
					orden1.push_back(p + 1);
				}
			}
			vector<int>orden2;
			for (int p = 0; p < orden1.size(); p++)
			{
				p2 = orden1[p] - 1;
				minN = 100.0;
				maxN = -100.0;
				for (int i = 0; i < 4; i++)
				{
					valueI = numbR[p2][i] - 1;
					if (y[valueI] < minN)
					{
						minN = y[valueI];
					}
					if (y[valueI] > maxN)
					{
						maxN = y[valueI];
					}
				}
				if ((maxN >= evy[k]) && (minN < evy[k]))
				{
					orden2.push_back(p2 + 1);
				}
			}
			for (int k1 = 0; k1 < 1; k1++)
			{
				//cout << "Punto: " << k + 1 << endl;
				int p2;
				double minV = 1000.0;
				double maxtemp;
				int numL2, inP;
				int p3 = 0, pN[4], ac, acL;
				bool salir2 = false;
				bool salir = false;
				int p = 0, IDP;
				int indx1, indx2, indx3, in1, in2, in3;
				while (!salir)
				{
					p2 = orden2[p] - 1;
					for (int k3 = 0; k3 < 4; k3++)
					{
						LN[k3] = numb[p2][k3] - 1;
						PosR[k3][0] = x[LN[k3]];
						PosR[k3][1] = y[LN[k3]];
						PosR[k3][2] = z[LN[k3]];
					}
					for (int ib = 0; ib < 3; ib++)
					{
						vecA[ib] = PosR[2][ib] - PosR[0][ib];
						vecB[ib] = PosR[1][ib] - PosR[0][ib];
						vecC[ib] = PosR[3][ib] - PosR[0][ib];
					}
					double* nn;
					nn = crossP(vecA, vecB);
					sumV = 0.0;
					for (int ib = 0; ib < 3; ib++)
					{
						sumV = sumV + nn[ib] * vecC[ib];
					}
					free(nn);
					if (sumV > 0.0)
					{
						numbC[0] = numbR[p2][0];
						numbC[1] = numbR[p2][1];
						numbC[2] = numbR[p2][2];
						numbC[3] = numbR[p2][3];
						//so1++;
					}
					else
					{
						numbC[0] = numbR[p2][0];
						numbC[1] = numbR[p2][2];
						numbC[2] = numbR[p2][1];
						numbC[3] = numbR[p2][3];
					}
					int j = 0;
					bool chk2 = true;
					salir2 = false;
					bool chk3 = false;
					while (!salir2)
					{

						indx1 = arr6[j][0] - 1;
						indx2 = arr6[j][1] - 1;
						indx3 = arr6[j][2] - 1;
						in1 = numbC[indx1] - 1;
						in2 = numbC[indx2] - 1;
						in3 = numbC[indx3] - 1;

						ac = checkcross(p2, x[in1], y[in1], z[in1], x[in2], y[in2], z[in2], x[in3], y[in3], z[in3], evx[k], evy[k], evz[k]);
						if (ac == 0)
						{
							chk2 = false;
							salir2 = true;
						}
						if ((j == 3))
						{
							salir2 = true;
						}
						j++;
					}
					if (p == (orden2.size() - 1) && (chk2 == false))
					{
						//cout << "Punto (" << evPosx[k] << "," << evPosy << "," << evPosz << ") no encontrado" << endl;
						salir = true;
					}
					if ((chk2 == true) || ((p == (orden2.size() - 1)) && (chk2 == true)))
					{
						IDP = p2 + 1;
						int contN3;
						elemNumb = p2;
						double PosR2[4][3];
						for (int i = 0; i < 4; i++)
						{
							LN[i] = numbR[elemNumb][i] - 1;
						}
						PosT[0] = evx[k];
						PosT[1] = evy[k];
						PosT[2] = evz[k];
						for (int i = 0; i < 4; i++)
						{
							PosR2[i][0] = x[LN[i]];
							PosR2[i][1] = y[LN[i]];
							PosR2[i][2] = z[LN[i]];
						}
						int numbP[8][3];
						int q = 0, q3 = 0;
						for (int j = 0; j < 6; j++)
						{
							imin = arr[j][0];
							imax = arr[j][1];

							min = numbR[elemNumb][imin] - 1;
							max = numbR[elemNumb][imax] - 1;
							mintemp = min;
							if (max < min)
							{
								min = max;
								max = mintemp;
							}
							sizeF = elemN[min].size();
							bool actualizar = false;
							if (sizeF != 0)
							{
								int l = 0;
								bool salir = false;
								//cout << sizeF << endl;
								while (salir == false)
								{
									if (elemN[min][l] == (max))
									{
										contN3 = elemN[min][l + 1];
										EN[q3] = contN3 - 1;
										EN[q3 + 1] = contN3;
										q3 = q3 + 2;
										actualizar = false;
										salir = true;
										//salir = true;
									}
									else
									{
										actualizar = true;
									}
									l = l + 2;
									if (l >= sizeF)
									{
										salir = true;
									}
								}
								if (actualizar == true)
								{
									//cout << "ssss" << endl;
								}
							}
							else
							{
								//cout << "que!" << endl;
							}
						}
						q = 0; q3 = 0;
						for (int s = 0; s < 4; s++)
						{
							bool chk = false;
							value1 = numbR[elemNumb][arr2[s][0]];
							value2 = numbR[elemNumb][arr2[s][1]];
							value3 = numbR[elemNumb][arr2[s][2]];
							int *values;
							values = order(value1, value2, value3);
							sizeF = elemIDF[values[0]].size();
							vector <int>vec2;
							int ind1[3], contN;
							bool actualizar = false;
							if (sizeF != 0)
							{
								int o = 0;
								bool salir3 = false;

								while (salir3 == false)
								{
									if ((elemIDF[values[0]][o] == (values[1])) && (elemIDF[values[0]][o + 1] == (values[2])))
									{
										//cout << l << endl;
										contN = elemIDF[values[0]][o + 2];
										EN[12 + q3] = contN - 1;
										EN[12 + q3 + 1] = contN;
										ind1[0] = 1;// elemIDF[values[0]][o + 3];
										ind1[1] = 2;// elemIDF[values[0]][o + 4];
										ind1[2] = 3;
										actualizar = true;
										salir3 = true;
									}

									o = o + 4;
									if (o >= sizeF)
									{
										if (salir3 != true)
										{
											//cout << "que" << endl;
										}
										salir3 = true;
									}
								}
							}
							else
							{
								//cout << "que?" << endl;
							}
							int LN1, LN2, LN3, i3;
							for (int r = 0; r < 2; r++)
							{
								i1 = ar3[ind1[r] - 1][0];
								i2 = ar3[ind1[r] - 1][1];
								i3 = ar3[ind1[r] - 1][2];
								LN1 = values[i1] + 1;
								LN2 = values[i2] + 1;
								LN3 = values[i3] + 1;
								for (int m = 0; m < 4; m++)
								{
									if (LN2 == (numbR[elemNumb][m]))
									{
										numbP[q][1] = m;
										//cout << "m: " << m << endl;
									}
									if (LN3 == numbR[elemNumb][m])
									{
										numbP[q][2] = m;
									}
									if (LN1 == numbR[elemNumb][m])
									{
										numbP[q][0] = m;
									}
								}
								q = q + 1;
								q3 = q3 + 1;
							}
						}
						for (int m = 0; m < 4; m++)
						{
							for (int n = 0; n < 4; n++)
							{
								if (n == 0)
								{
									GM[m][n] = 1.0;
								}
								else
								{
									GM[m][n] = PosR2[m][n - 1];
								}
							}
						}
						double cofA[4][4];
						double **invT;
						invT = inv4(GM);
						for (int m = 0; m < 4; m++)
						{
							for (int n = 0; n < 4; n++)
							{
								cofA[m][n] = invT[n][m];
							}
						}
						double sum = 0.0, GE[3][3], **GEinv;
						for (int t = 0; t < 3; t++)
						{
							for (int m = 0; m < 3; m++)
							{
								sum = 0.0;
								for (int n = 0; n < 4; n++)
								{
									sum = sum + G3inv[t + 1][n] * PosR2[n][m];
								}
								GE[t][m] = sum;
							}
						}
						GEinv = inv3(GE);				
						double lx;				
						for (int i = 0; i < 4; i++)
						{
							N[i] = (cofA[i][0] + cofA[i][1] * PosT[0] + cofA[i][2] * PosT[1] + cofA[i][3] * PosT[2]);
							for (int m = 0; m < 3; m++)
							{
								if (i < 3)
								{
									dN[i][m] = GEinv[m][i]; //cofA[p][m + 1] / Vol;
								}
								else
								{
									dN[i][m] = -(dN[0][m] + dN[1][m] + dN[2][m]);
								}
							}
						}
						int f1, f2, f3;				
						int fr[2], frtemp, fm;
						fr[0] = 0;
						fr[1] = 0;
						int pw = 0;
						for (int s2 = 0; s2 < 6; s2++)
						{
							fr[0] = arr7[s2][0];
							fr[1] = arr7[s2][1];
							frtemp = fr[0];
							if (LN[fr[1]] < LN[fr[0]])
							{
								fr[0] = fr[1];
								fr[1] = frtemp;
							}
							fm = arr8[s2];
							for (int r = 0; r < 2; r++)
							{
								double* n1, * n2, * n3;

								lx = sqrt(pow(x[LN[fr[1]]] - x[LN[fr[0]]], 2.0) + pow(y[LN[fr[1]]] - y[LN[fr[0]]], 2.0) + pow(z[LN[fr[1]]] - z[LN[fr[0]]], 2.0));
								for (int m = 0; m < 3; m++)
								{
									/*if (r == 0)
									{
										W[pw][m] = lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
									}
									else
									{
										W[pw][m] = (double)sqrt(3.0) * (N[fr[0]] - N[fr[1]]) * lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
									}*/

									W[pw][m] = (3.0 * N[fr[r]] - 1.0) * lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
								}
								n1 = crossP(dN[fr[0]], dN[fr[1]]);
								//n2 = crossP(dN[fr[r]], W[pw]);
								n2 = crossP(dN[fr[r]], dN[fr[0]]);
								n3 = crossP(dN[fr[r]], dN[fr[1]]);
								for (int m = 0; m < 3; m++)
								{
									/*if (r == 0)
									{
										rotU[pw][m] = (double)lx * 2.0 * n1[m];
									}
									else
									{
										rotU[pw][m] = (double)lx * (3.0 * sqrt(3.0) * n1[m] * (N[fr[0]] - N[fr[1]]));
									}*/
									rotU[pw][m] = (double)lx * ((2.0 * n1[m] * (3.0 * N[fr[r]] - 1.0)) + (double)3.0 * (N[fr[0]] * n3[m] - N[fr[1]] * n2[m]));
								}
								free(n1);
								free(n2);
								free(n3);
								pw++;
							}
						}
						double lx2 = 0.0;
						int q2 = 12;
						int idx = 0;
						for (int u = 0; u < 4; u++)
						{
							int ck = 0;
							for (int i = 0; i < 2; i++)
							{
								double *n1, *n2,*n3;
								//idx = (int)(u * 2.0 + i);
								//idx2 = (int)(u * 2 + 2);
								f1 = numbP[idx][0];
								f2 = numbP[idx][1];
								f3 = numbP[idx][2];
								idx++;
								lx = sqrt(pow(x[LN[f3]] - x[LN[f2]], 2.0) + pow(y[LN[f3]] - y[LN[f2]], 2.0) + pow(z[LN[f3]] - z[LN[f2]], 2.0));
								for (int m = 0; m < 3; m++)
								{
									W[q2][m] = (3.0*N[f1])*lx*(N[f2] * dN[f3][m] - N[f3] * dN[f2][m]);
								}
								n1 = crossP(dN[f2], dN[f3]);
								n2 = crossP(dN[f1], dN[f2]);
								n3 = crossP(dN[f1], dN[f3]);
								for (int m = 0; m < 3; m++)
								{
									rotU[q2][m] = lx * ((2.0*n1[m] * (3.0*N[f1])) + (double)3.0*(N[f2] * n3[m] - N[f3] * n2[m]));
								}
								free(n1);
								free(n2);
								free(n3);
								q2++;			
							}
						}
						//cout << "ID de punto (" << xval[k] << "," << yslice << "," << zval[l] << "): " << IDP << endl;

						complex <double>resul;
						int numL;
						double Lx, cons1, cons2;
						complex <double> NR[3];
						//int numL;
						NR[0] = 0.0;
						NR[1] = 0.0;
						NR[2] = 0.0;
						int maxtemp;
				
						//double sumt[3], sumt2[3], sumt3[3], sumt4[3], SumT;
						complex <double>Rresult;
						//complex <double>resul;
					
						for (int s = 0; s < 3; s++)
						{
							CE2[s][pol] = 0.0;
							CM2[s][pol] = 0.0;
						}
						for (int m = 0; m < 20; m++)
						{
							for (int n = 0; n < 3; n++)
							{
								NR[n] = NR[n] + W[m][n] * result[EN[m]];
							}
						}
						for (int m = 0; m < 20; m++)
						{	
							for (int n = 0; n < 3; n++)
							{
								CE2[n][pol] = CE2[n][pol]+ (complex<double>)W[m][n] * result[EN[m]];
								CM2[n][pol] = CM2[n][pol] + (complex<double>)rotU[m][n] *im* result[EN[m]]/ (complex<double>)(wr*mu0)/1000.0;
							}					
							Ex[k][pol] = CE2[0][pol];
							Ey[k][pol] = CE2[1][pol];
							Ez[k][pol] = CE2[2][pol];
							Hx[k][pol] = CM2[0][pol];
							Hy[k][pol] = CM2[1][pol];
							Hz[k][pol] = CM2[2][pol];
						}
						//cout << "(" << NR[0] <<  "," << NR[1] <<"," << NR[2] <<")"<<endl;
						salir = true;
					}
					p++;
				}
				//orden2.erase(orden2.begin(), orden2.end());
				if (pol == 1)
				{
				complex<double>detZ, Zxx, Zxy, Zyx, Zyy,Tzx,Tzy,detZT;
				double RhoXX, RhoXY, RhoYY, RhoYX, FaseXX, FaseYY, FaseXY, FaseYX;
				double Zxxr, Zxyr, Zyxr, Zyyr,Zxxi, Zxyi, Zyxi, Zyyi,Tzxr,Tzxi,Tzyr,Tzyi;

					detZ = Hx[k][0] * Hy[k][1] - Hx[k][1] * Hy[k][0];	
					Zxx = (Ex[k][0] * Hy[k][1] - Ex[k][1] * Hy[k][0]) / detZ;
					Zxy = (-Ex[k][0] * Hx[k][1] + Ex[k][1] * Hx[k][0]) / detZ;
					Zyx = (Ey[k][0] * Hy[k][1] - Ey[k][1] * Hy[k][0]) / detZ;
					Zyy = (-Ey[k][0] * Hx[k][1] + Ey[k][1] * Hx[k][0]) / detZ;
					Tzx=(Hy[k][1]*Hz[k][0]-Hy[k][0]*Hz[k][1])/detZ;
					Tzy=(-Hx[k][1]*Hz[k][0]+Hx[k][0]*Hz[k][1])/detZ;
					//Zxx = (Ex[k][0] * Hx[k][0] - Ex[k][1] * Hx[k][1]) / detZ;
					//Zxy = (-Ex[k][0] * Hy[k][0] + Ex[k][1] * Hy[k][1]) / detZ;
					//Zyx = (Ey[k][0] * Hx[k][0] - Ey[k][1] * Hx[k][1]) / detZ;
					//Zyy = (-Ey[k][0] * Hy[k][0] + Ey[k][1] * Hy[k][1]) / detZ;
					Zxxr=Zxx.real();
					Zxxi=Zxx.imag();
					Zyyr=Zyy.real();
					Zyyi=Zyy.imag();
					Zxyr=Zxy.real();
					Zxyi=Zxy.imag();
					Zyxr=Zyx.real();
					Zyxi=Zyx.imag();
					Tzxr=Tzx.real();
					Tzxi=Tzx.imag();
					Tzyr=Tzy.real();
					Tzyi=Tzy.imag();


					RhoXY = (double)pow(abs(Zxy), 2.0) / (wr*mu0);
					RhoYX = (double)pow(abs(Zyx), 2.0) / (wr*mu0);
					RhoYY = (double)pow(abs(Zyy), 2.0) / (wr*mu0);
					RhoXX = (double)pow(abs(Zxx), 2.0) / (wr*mu0);
					FaseXY = atan(imag(Zxy) / real(Zxy))*180.0 / M_PI;
					FaseYX = atan(imag(Zyx) / real(Zyx))*180.0 / M_PI;
					FaseYY = atan(imag(Zyy) / real(Zyy))*180.0 / M_PI;
					FaseXX = atan(imag(Zxx) / real(Zxx))*180.0 / M_PI;
					
						transfer[acut]=Freq;
						transfer[acut+1]=RhoXX;
						transfer[acut+2]=RhoYY;
						transfer[acut+3]=RhoXY;
						transfer[acut+4]=RhoYX;
						transfer[acut+5]=FaseXX;
						transfer[acut+6]=FaseYY;
						transfer[acut+7]=FaseXY;
						transfer[acut+8]=FaseYX;
						transfer[acut+9]=Zxxr;
						transfer[acut+10]=Zxxi;
						transfer[acut+11]=Zyyr;
						transfer[acut+12]=Zyyi;
						transfer[acut+13]=Zxyr;
						transfer[acut+14]=Zxyi;
						transfer[acut+15]=Zyxr;
						transfer[acut+16]=Zyxi;
						transfer[acut+17]=Tzxr;
						transfer[acut+18]=Tzxi;
						transfer[acut+19]=Tzyr;
						transfer[acut+20]=Tzyi;




						acut=acut+21;
						//cout<<Ey[k][0] <<" "<<Ey[k][1]<<" "<<RhoXY<<" "<<k<<endl;						
										
				
				}

			}
			orden1.erase(orden1.begin(),orden1.end());
			orden2.erase(orden2.begin(),orden2.end());
			}
						
			//myfile4.open("ModeloHomogeneoResistividadesPP21b1000.txt");
			free(xR);
			free(bv);
			free(aR);
			free(ja);
			free(ia);
			free(varc);
			//free(pt);
			//free(iparm);
			//free(dparm);
			//free(pValue);
			//free(var);
			//char *pValue;
			//size_t len;
			//char*var;			
			
			//orden2.erase(orden2.begin(), orden2.end());
			//result.erase(result.begin(), result.end());
			ja2.erase(ja2.begin(), ja2.end());
			DV.erase(DV.begin(), DV.end());
			
			dirichI.erase(dirichI.begin(), dirichI.end());
			//dirichV.erase(dirichV.begin(), dirichV.end());
			dirichVN.erase(dirichVN.begin(), dirichVN.end());
		}
	}
	ofstream myfile5;
	if(process_num==0)
	{
	int acuf=0;
	time(&finish3);
	

	for(int i=0;i<(int)((fq2-fq1)*21*numCoords);i++)
	{
		pedazoFinal[acuf]=transfer[i];
		acuf++;
	}
	for(int i=1;i<size_of_cluster;i++)
	{
		double *zap;				 
		zap=(double*)malloc(sizeof(double)*(int)((fqL[i][1]-fqL[i][0])*21*numCoords));
		MPI_Recv(zap,(int)((fqL[i][1]-fqL[i][0])*21*numCoords), MPI_DOUBLE, i, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		for(int j=0;j<(int)((fqL[i][1]-fqL[i][0])*21*numCoords);j++)
		{
		pedazoFinal[acuf]=zap[j];
		acuf++;
		}		
		
		free(zap);

	}
	acuf=0;
	myfile5.open("Results.txt");//CalculadosAPrueba7.txt");//DatosObservadosCuboP7DatosPruebaC2dT8.txt
	for(int j=0;j<numFreq;j++)
	{

	for(int k=0;k<numCoords;k++)
	{
							myfile5 << setprecision(15) << pedazoFinal[acuf];
						myfile5 << " ";
						myfile5 << setprecision(15) <<  pedazoFinal[acuf+1];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+2];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+3];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+4];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+5];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+6];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+7];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+8];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+9];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+10];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+11];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+12];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+13];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+14];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+15];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+16];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+17];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+18];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+19];
						myfile5 << " ";
						myfile5 << setprecision(15) << pedazoFinal[acuf+20];
						myfile5 << "\n";
	acuf=acuf+21;
	}
	}
	time(&finish2);
	cout << "Time required = " << difftime(finish2, start2) << " seconds"<<endl;
	myfile5 << setprecision(10) <<(double)difftime(finish2, start2);
	myfile5 << "\n";
	myfile5 << setprecision(10) <<(double)difftime(finish3, start2);

	myfile5.close();
		
	}
	else	
	{
		MPI_Send(transfer, (int)((fq2-fq1)*21*numCoords), MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);	
	
	}
	MPI_Finalize();
	//cout << "Hello World!" << endl;
	return 0;
}

// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln
