!=======================================================================================================
!
 In this file follows a description of how to use the program HO3DMT (High Order based 3D MT modeling for unstructured mesh).


  Author : Erik Uziel Gallardo Romero 
  
  Academic training :
		
	   - Graduation in Physics from the Autonomous University of Baja California-2018

	   - Master in Earth Sciences from the Ensenada Center for Scientific Research and Higher Education (CICESE)-2020


	     Version : 1.0		 	Date  : 06/06/2021 


!==========================================================================================
!==========================================================================================

Submitted to Journal of Computers and Geosciences as: High order edge-based finite elements for 3D magnetotelluric modeling with unstructured meshes - 26/05/2021  
!==========================================================================================
!==========================================================================================
	SUMMARY :

	Coming soon...