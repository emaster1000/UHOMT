/*
  Main Module of UHOMT for shared-memory architectures
  Version 2
  Last update: 09/09/2021
  Written by Erik Gallardo Romero
  email: egallardo@cicese.edu.mx
*/

#include "UHOMT3D.h"
#include <iostream>
#include<complex>
#include <stdio.h>
#include <vector>
#include <ios>
#include <ctime>
#include <cmath>
#include <math.h>
#include <algorithm>
#include <fstream>
#include<numeric>
#include <omp.h>
#include <stdlib.h>
#include <iomanip>

// Libraries required for PARDISO MKL

#define M_PI  3.14159265358979323846
using namespace std;
typedef struct {
	double re;
	double i;
}
doublecomplex;
extern "C" void pardisoinit(void*, int*, int*, int*, double*, int*);
extern "C" void pardiso(void*, int*, int*, int*, int*, int*,
	doublecomplex*, int*, int*, int*, int*, int*,
	int*, doublecomplex*, doublecomplex*, int*, double*);
extern "C" void pardiso_chkmatrix_z(int*, int*, doublecomplex*, int*, int*, int*);
extern "C" void pardiso_chkvec_z(int*, int*, doublecomplex*, int*);
extern "C" void pardiso_printstats_z(int*, int*, doublecomplex*, int*, int*, int*,
	doublecomplex*, int*);
struct IncGenerator {
	int current_;
	IncGenerator(int start) : current_(start) {}
	int operator() () { return current_++; }
};
double vecA[3], vecB[3], vecC[3];
struct nodeid
{
	int i1;
	int i2;
};
struct enumSides {
	vector<nodeid>nodeID;
	vector<int>contV;
};
struct enumFaces {
	vector<vector<int > >ENnum;
	vector<vector<int> >nodeID;
	vector<int>contF;
	vector<int>contFO;
	vector<int>contO;
	vector<int>contE;
	vector<int>idE;
	int totalV;
};
vector<int>vecID, vecID3;
bool myfunction(int i, int j) { return (vecID[i] < vecID[j]); };
#define M_PI  3.14159265358979323846
double n[3], v1x, v1y, v1z, v2x, v2y, v2z, v3x, v3y, v3z;
int res;
double tol;
double* x, * y, * z, det;
double inv[16];
int pj = 0;
double m[16], deti;
double Lx = 0.0, Ly = 0.0, Lz = 0.0, Lz1 = 0.0, Lz2 = 0, Lg1 = 0.0, Lg2 = 0.0, Lg3 = 0.0, Lg3a = 0.0, Lg3b = 0.0;//300
double PosR[10][3], N[4];
double GM[4][4];
double GMS[3][3];
double dN[4][3];
double dN2[3][2];
double PosT[3], rotU[20][3], W[20][3];
int LN[10];
double conduc = 0.0;
int EN[20], imin, imax;
int ar[3][2] = { {0,1},{1,2},{2,0} };
int ar3[3][3] = { {2,0,1},{0,1,2},{1,2,0} };
double zslice = 15.0, xslice = -15.0;
int nodostot = 0;
int elemtot;
int ordenN, ordenN2;
double* Pesos, * Pesos2, * ux, * uy, * uz, * ux2, * uy2;
int ladosSup = 0;
int sizeF, valF, min, max;
int condL[20];
int totB = 0;
double dL[3][2];
double ResA;
int numCoords;
double* evx, * evy, * evz;
int arr[6][2] = { {0,1},{1,2},{2,0},{0,3},{3,2},{3,1} };
int arr2[4][3] = { {0,1,2},{1,2,3},{0,2,3},{0,1,3} };
int arr6[4][3] = { {1,2,3},{1,3,4},{1,4,2},{4,3,2} };
int arr1[3][2] = { {0,1},{1,2},{2,0} };
double CF[4][3] = { {0.0,0.0,0.0},{1.0,0.0,0.0},{0.0,0.0,1.0},{0.0,1.0,0.0} };
double CFS[3][2] = { {0.0,0.0},{1.0,0.0},{0.0,1.0} };
double G3[4][4] = { {1.0,1.0,0.0,0.0},{1.0,0.0,1.0,0.0},{1.0,0.0,0.0,1.0},{1.0,0.0,0.0,0.0} };
double G3S[3][3] = { {1.0,1.0,0.0},{1.0,0.0,1.0},{1.0,0.0,0.0} };
double** G3inv;
double** G3Sinv;
vector<vector<int> >idenLines;
vector<vector<int> >idenSurfaces;
vector<vector<int > >elemN;
vector<vector<int> >elemIDF;
int cont;
int ladostot, mintemp;
complex<float>k0, k1;
complex <double>im;
complex<double>valC(1000.0, 0.0);
complex<float> H0(1.0, 0.0), A, B, C;
int numberVolumes, numberLines, numberSurfaces;
int* elemperVol, * elemperLine, * elemperSurf;
int** numbS, ** numbR, ** numbLine;
int elemSnum = 0;
int elemLnum = 0;
vector<vector<complex <double> > > Ex;
vector<vector<complex <double> > > Ey;
vector<vector<complex <double> > > Ez;
vector<vector<complex <double> > > Hx;
vector<vector<complex <double> > > Hy;
vector<vector<complex <double> > > Hz;
int q2;
int numbP[8][3];
int dirichLnum[4];
int numtotLines[4], numtotSurfaces[6], numBLines[4];
int value1, value2, value3;
int elemin = 0;
//struct enumSides enumSi[24];
struct nodeid idnum;
int ida, idb;
bool actualizar;
bool salir;
int ln, * idLine, * idSurface;
enumSides* enumSi;
int contvf;
int acE = 0, numdirichSurf;
enumFaces* enumFa;
int contS;
int idk;
int newcont, totSurfaceG;
vector<vector<int > >elemSur;
int* surfin;
vector<vector<int> > elemtotRS(6);
int poli2[4] = { 1,3,0,2 };
int idp;
int elemtotS;
int ladostotS;
int edgenumber = 0;

complex <double> CE2[3][2], CM2[3][2];
int indx1, indx2, indx3, in1, in2, in3;
int elemNumb;
double  G[4][4];
complex <double> K[20][20];
double sum = 0.0, GE[2][2], GE3[3][3];
int loc[3];// , loc2[3];
int acd = 0;
int contNN2;
double lx;
double cofA[3][3];
int q = 0, q3 = 0, s = 0;
int fr[2], frtemp, pw = 0;
double detT;
int f1, f2, f3;
complex<double>Sd;
int LN1, LN2, LN3, i3, i1, i2;
double SumT, result1, result2;
complex <double>Rresult;
int    numV;
doublecomplex refV;
int numS2 = 0;
int rt;
int numT;
int id = 0, id2 = 0, ac = 0, p2;
complex <double >E0;
int contval, contval2;
int poli3[8] = { 4,0,2,5,4,1,3,5 };
int veri = 0;
int LN4;
int contN4;
int s2;
double cofA4[4][4];
double  zn;
int contN3;
int ind1[3], contN;
complex<double>result;
double control1 = 0.0, control2 = 0.0, control3 = 0.0, control4 = 0.0;
complex<double>Sd2;
int chk;
int nac = 0;
double minN = 16.0, maxN = -16.0;
int numbC[4];
int valueI;
bool salir2 = false;
int IDP;
//int p;
int jr = 0;
bool chk2 = true, salir3;
double sumV;
double PosR2[4][3];
int idx;
complex<double>detZ, Zxx, Zxy, Zyx, Zyy, Tzx, Tzy, detZT;
double RhoXX, RhoXY, RhoYY, RhoYX, FaseXX, FaseYY, FaseXY, FaseYX;
double Zxxr, Zxyr, Zyxr, Zyyr, Zxxi, Zxyi, Zyxi, Zyyi, Tzxr, Tzxi, Tzyr, Tzyi;
int numFreq;
vector<double>Fq;
double wr, mu0;
int** fqL;
double ncross1, ncross2, ncross3, ncross4;
int fqA, fqB;
double* transfer, * transferb;
double* pedazoFinal, * pedazoFinalb;
int acut = 0;
int acutb = 0;
int mode1, mode2;
time_t start, finish;
double Freq;
vector<int>cond;
vector<complex<double > >dirichVN;
vector<complex<double > >dirichVN2;
vector<int>dirichI;
int sumAC, numSur;
vector<int>dirichI2;
double ResH;
vector<vector <complex<double > > >KM;
vector<vector<int > >ID;
vector<vector<int > >ID3;
vector<vector<int > >ID2;
vector<vector<int > >DIR;
int numVol = -1;

/* Computes the cross product of two 2D vectors */
double crossP2(int pol, double a[2], double b[2])
{
	double n;
	if (pol == 1)
	{
		n = a[0] * b[1] - a[1] * b[0];
	}
	else
	{
		n = a[1] * b[0] - a[0] * b[1];
	}
	return n;
}
/* 
 Checks whether the dot product of the vector (xR-x2,yR-y2,zC-z2) and the vector normal to the surface defined by the points (x1,y1,y2),
 (x2,y2,z3) and (x3,y3,z3) is positive or negative.
*/
int checkcross(double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3, double xR, double yR, double zR)
{
	res = 1;
	v1x = x1 - x2;
	v1y = y1 - y2;
	v1z = z1 - z2;
	v2x = x3 - x2;
	v2y = y3 - y2;
	v2z = z3 - z2;
	v3x = xR - x2;
	v3y = yR - y2;
	v3z = zR - z2;
	n[0] = (v1y * v2z - v1z * v2y);
	n[1] = (v1z * v2x - v2z * v1x);
	n[2] = (v1x * v2y - v1y * v2x);
	tol = -pow(10.0, -10.0);
	if ((n[0] * v3x + n[1] * v3y + n[2] * v3z) >= tol)
	{
		res = 1;
	}
	else
	{
		res = 0;
	}
	return res;
}
/* Computes the cross product of two 3D vectors*/
double* crossP(double a[3], double b[3])
{
	//static double n[3];
	double* n = new double[3];
	n[0] = a[1] * b[2] - a[2] * b[1];
	n[1] = a[2] * b[0] - a[0] * b[2];
	n[2] = a[0] * b[1] - a[1] * b[0];
	return n;
}
/* Computes the inverse of a 3 x 3 matrix */
double** inv3(double mat[3][3])
{
	double** K = new double* [3];
	for (int i = 0; i < 3; i++)
	{
		K[i] = new double[3];
	}
	K[0][0] = mat[1][1] * mat[2][2] - mat[1][2] * mat[2][1];
	K[0][1] = -(mat[0][1] * mat[2][2] - mat[0][2] * mat[2][1]);
	K[0][2] = mat[0][1] * mat[1][2] - mat[0][2] * mat[1][1];
	K[1][0] = -(mat[1][0] * mat[2][2] - mat[1][2] * mat[2][0]);
	K[1][1] = mat[0][0] * mat[2][2] - mat[0][2] * mat[2][0];
	K[1][2] = -(mat[0][0] * mat[1][2] - mat[0][2] * mat[1][0]);
	K[2][0] = mat[1][0] * mat[2][1] - mat[1][1] * mat[2][0];
	K[2][1] = -(mat[0][0] * mat[2][1] - mat[0][1] * mat[2][0]);
	K[2][2] = mat[0][0] * mat[1][1] - mat[0][1] * mat[1][0];
	det = 0.0;
	det = mat[0][0] * (mat[1][1] * mat[2][2] - mat[1][2] * mat[2][1]) + mat[0][1] * (mat[1][2] * mat[2][0] - mat[2][2] * mat[1][0]) + mat[0][2] * (mat[1][0] * mat[2][1] - mat[1][1] * mat[2][0]);
	//det = 1.0 / det;
	for (int j = 0; j < 3; j++)
	{
		for (int i = 0; i < 3; i++)
		{
			K[j][i] = K[j][i] / det;
		}
	}
	if (det == 0.0)
	{
		//return false;
	}
	return K;
}
/* Computes the inverse of a 2 x 2 matrix */
double** inv2(double mat[2][2])
{
	double** K = new double* [2];
	for (int i = 0; i < 2; i++)
	{
		K[i] = new double[2];
	}
	K[0][0] = mat[1][1];
	K[0][1] = -(mat[0][1]);
	K[1][0] = -(mat[1][0]);
	K[1][1] = mat[0][0];
	det = 0.0;
	det = mat[0][0] * mat[1][1] - mat[1][0] * mat[0][1];
	//det = 1.0 / det;
	for (int j = 0; j < 2; j++)
	{
		for (int i = 0; i < 2; i++)
		{
			K[j][i] = K[j][i] / det;
		}
	}
	if (det == 0.0)
	{
		//return false;
	}
	return K;
}
/* Computes the inverse of a 4 x 4 matrix */
double** inv4(double G[4][4])
{
	double** GR = new double* [4];
	for (int i = 0; i < 4; i++)
	{
		GR[i] = new double[4];
	}
	pj = 0;
	for (int q2 = 0; q2 < 4; q2++)
	{
		for (int q1 = 0; q1 < 4; q1++)
		{
			m[pj] = G[q2][q1];
			pj = pj + 1;
		}
	}
	inv[0] = m[5] * m[10] * m[15] -
		m[5] * m[11] * m[14] -
		m[9] * m[6] * m[15] +
		m[9] * m[7] * m[14] +
		m[13] * m[6] * m[11] -
		m[13] * m[7] * m[10];

	inv[4] = -m[4] * m[10] * m[15] +
		m[4] * m[11] * m[14] +
		m[8] * m[6] * m[15] -
		m[8] * m[7] * m[14] -
		m[12] * m[6] * m[11] +
		m[12] * m[7] * m[10];

	inv[8] = m[4] * m[9] * m[15] -
		m[4] * m[11] * m[13] -
		m[8] * m[5] * m[15] +
		m[8] * m[7] * m[13] +
		m[12] * m[5] * m[11] -
		m[12] * m[7] * m[9];

	inv[12] = -m[4] * m[9] * m[14] +
		m[4] * m[10] * m[13] +
		m[8] * m[5] * m[14] -
		m[8] * m[6] * m[13] -
		m[12] * m[5] * m[10] +
		m[12] * m[6] * m[9];

	inv[1] = -m[1] * m[10] * m[15] +
		m[1] * m[11] * m[14] +
		m[9] * m[2] * m[15] -
		m[9] * m[3] * m[14] -
		m[13] * m[2] * m[11] +
		m[13] * m[3] * m[10];

	inv[5] = m[0] * m[10] * m[15] -
		m[0] * m[11] * m[14] -
		m[8] * m[2] * m[15] +
		m[8] * m[3] * m[14] +
		m[12] * m[2] * m[11] -
		m[12] * m[3] * m[10];

	inv[9] = -m[0] * m[9] * m[15] +
		m[0] * m[11] * m[13] +
		m[8] * m[1] * m[15] -
		m[8] * m[3] * m[13] -
		m[12] * m[1] * m[11] +
		m[12] * m[3] * m[9];

	inv[13] = m[0] * m[9] * m[14] -
		m[0] * m[10] * m[13] -
		m[8] * m[1] * m[14] +
		m[8] * m[2] * m[13] +
		m[12] * m[1] * m[10] -
		m[12] * m[2] * m[9];

	inv[2] = m[1] * m[6] * m[15] -
		m[1] * m[7] * m[14] -
		m[5] * m[2] * m[15] +
		m[5] * m[3] * m[14] +
		m[13] * m[2] * m[7] -
		m[13] * m[3] * m[6];

	inv[6] = -m[0] * m[6] * m[15] +
		m[0] * m[7] * m[14] +
		m[4] * m[2] * m[15] -
		m[4] * m[3] * m[14] -
		m[12] * m[2] * m[7] +
		m[12] * m[3] * m[6];

	inv[10] = m[0] * m[5] * m[15] -
		m[0] * m[7] * m[13] -
		m[4] * m[1] * m[15] +
		m[4] * m[3] * m[13] +
		m[12] * m[1] * m[7] -
		m[12] * m[3] * m[5];

	inv[14] = -m[0] * m[5] * m[14] +
		m[0] * m[6] * m[13] +
		m[4] * m[1] * m[14] -
		m[4] * m[2] * m[13] -
		m[12] * m[1] * m[6] +
		m[12] * m[2] * m[5];

	inv[3] = -m[1] * m[6] * m[11] +
		m[1] * m[7] * m[10] +
		m[5] * m[2] * m[11] -
		m[5] * m[3] * m[10] -
		m[9] * m[2] * m[7] +
		m[9] * m[3] * m[6];

	inv[7] = m[0] * m[6] * m[11] -
		m[0] * m[7] * m[10] -
		m[4] * m[2] * m[11] +
		m[4] * m[3] * m[10] +
		m[8] * m[2] * m[7] -
		m[8] * m[3] * m[6];

	inv[11] = -m[0] * m[5] * m[11] +
		m[0] * m[7] * m[9] +
		m[4] * m[1] * m[11] -
		m[4] * m[3] * m[9] -
		m[8] * m[1] * m[7] +
		m[8] * m[3] * m[5];

	inv[15] = m[0] * m[5] * m[10] -
		m[0] * m[6] * m[9] -
		m[4] * m[1] * m[10] +
		m[4] * m[2] * m[9] +
		m[8] * m[1] * m[6] -
		m[8] * m[2] * m[5];

	deti = m[0] * inv[0] + m[1] * inv[4] + m[2] * inv[8] + m[3] * inv[12];

	if (deti == 0)
	{
		//return false;
	}
	//return false;

	deti = 1.0 / (double)deti;
	pj = 0;
	for (int q2 = 0; q2 < 4; q2++)
	{
		for (int q1 = 0; q1 < 4; q1++)
		{
			GR[q2][q1] = inv[pj] * deti;
			pj = pj + 1;
		}
	}
	return GR;
}
/* Orders a sequence of 3 values from lowest to highest */
int* order(int val1, int val2, int val3)
{
	//static int l[3];
	int* l = new int[3];
	if (val2 > val1)
	{
		if (val3 > val2)
		{
			l[0] = val1;
			l[1] = val2;
			l[2] = val3;
		}
		else
		{
			if (val1 > val3)
			{
				l[0] = val3;
				l[1] = val1;
				l[2] = val2;
			}
			else
			{
				l[0] = val1;
				l[1] = val3;
				l[2] = val2;
			}
		}
	}
	else
	{
		if (val3 > val1)
		{
			l[0] = val2;
			l[1] = val1;
			l[2] = val3;
		}
		else
		{
			if (val2 > val3)
			{
				l[0] = val3;
				l[1] = val2;
				l[2] = val1;
			}
			else
			{
				l[0] = val2;
				l[1] = val3;
				l[2] = val1;
			}
		}
	}
	for (int i = 0; i < 3; i++)
	{
		l[i] = l[i] - 1;
	}
	return l;
}
/* Sets the dimension of the domain in km */
void UHOMT3D::SetDimDomain(double L1,double L2,double L3,double L4)
{
	Lx = L1;
	Ly = L2;
	Lz1 = L3;
	Lz2 = L4;
	Lz = Lz1 + Lz2;
}
/* Sets the dimension of the domain in Gmsh coordinates */
void UHOMT3D::SetDimGmsh(double L1, double L2, double L3)
{
	Lg1 = L1;
	Lg2 = L2;
	//Lg3a = L3;
	//Lg3b = L4;
	Lg3 = L3;// Lg3a + Lg3b;
}
int typeB = 2; /* Order of base: linear (1) or second order (2) */
int faceB = 2, edgeB = 2; /* Number of associated base functions per face and edge */

/* Sets the base function type */
void UHOMT3D::SetBaseType(int dtypebase)
{
	typeB = dtypebase;
	if (typeB == 2)
	{
		typeB = 2;
		faceB = 2;
		edgeB = 2;
	}
	if(typeB == 1)
	{
		typeB = 1;
		faceB = 0;
		edgeB = 1;
	}
	if (typeB == 3)
	{
		edgeB = 2;
		faceB = 0;
	}
}

/* Reads mesh information, evaluation coordinates from input files.
   Reads 2D and 3D Quadrature points and weigths used for 2D and 3D numerical integration  */
void UHOMT3D::ReadFiles(const char* RecepFileName, const char* UHOFileName)
{	
	ifstream inFile, inPesos, inPesos2, evalCoords;
	/* 3D Quadrature info */
	inPesos.open("Quadrature3D.txt");
	inPesos >> ordenN;
	Pesos = (double*)malloc(sizeof(double) * ordenN);
	ux = (double*)malloc(sizeof(double) * ordenN);
	uy = (double*)malloc(sizeof(double) * ordenN);
	uz = (double*)malloc(sizeof(double) * ordenN);
	//cout << "ORDER: " << ordenN << endl;
	for (int i = 0; i < ordenN; i++)
	{
		inPesos >> ux[i];
		inPesos >> uy[i];
		inPesos >> uz[i];
		inPesos >> Pesos[i];
	}
	inPesos.close();
	
	/* 2D Quadrature info */
	inPesos2.open("Quadrature2D.txt");
	inPesos2 >> ordenN2;
	Pesos2 = (double*)malloc(sizeof(double) * ordenN2);
	ux2 = (double*)malloc(sizeof(double) * ordenN2);
	uy2 = (double*)malloc(sizeof(double) * ordenN2);
	for (int i = 0; i < ordenN2; i++)
	{
		inPesos2 >> ux2[i];
		inPesos2 >> uy2[i];
		inPesos2 >> Pesos2[i];
	}
	inPesos2.close();

	/* Evaluation coordinates */
	evalCoords.open(RecepFileName);
	evalCoords >> numCoords;
	evx = (double*)malloc(sizeof(double) * numCoords);
	evy = (double*)malloc(sizeof(double) * numCoords);
	evz = (double*)malloc(sizeof(double) * numCoords);
	
	for (int i = 0; i < numCoords; i++)
	{
		evalCoords >> evx[i];
		evalCoords >> evy[i];
		evalCoords >> evz[i];
	}
	evalCoords.close();

	/* Reads mesh information: number of elements,nodes,volumes,surfaces and lines*/
	inFile.open(UHOFileName);
	inFile >> nodostot;
	elemN.resize(nodostot);
	elemIDF.resize(nodostot);
	cont = 1;
	G3inv = inv4(G3);
	G3Sinv = inv3(G3S);
	mintemp = 0;
	im.imag(1);
	inFile >> numberVolumes;
	elemperVol = (int*)malloc(sizeof(int) * numberVolumes);
	elemtot = 0;

	for (int i = 0; i < numberVolumes; i++)
	{
		inFile >> elemperVol[i];
		elemtot = elemtot + elemperVol[i];
	}
	
	inFile >> numberSurfaces;

	elemperSurf = (int*)malloc(sizeof(int) * numberSurfaces);
	elemSnum = 0;
	for (int i = 0; i < numberSurfaces; i++)
	{
		inFile >> elemperSurf[i];
		elemSnum = elemSnum + elemperSurf[i];
	}
	inFile >> numberLines;

	elemperLine = (int*)malloc(sizeof(int) * numberLines);
	elemLnum = 0;
	for (int i = 0; i < numberLines; i++)
	{
		inFile >> elemperLine[i];
		elemLnum = elemLnum + elemperLine[i];
	}
	
	Ex.resize(numCoords);
	Ey.resize(numCoords);
	Ez.resize(numCoords);
	Hx.resize(numCoords);
	Hy.resize(numCoords);
	Hz.resize(numCoords);
	for (int i = 0; i < numCoords; i++)
	{
		complex<double> vecK = 0.0;
		for (int j = 0; j < 2; j++)
		{
			Ex[i].push_back(vecK);
			Ey[i].push_back(vecK);
			Ez[i].push_back(vecK);
			Hx[i].push_back(vecK);
			Hy[i].push_back(vecK);
			Hz[i].push_back(vecK);
		}
	}

	numbS = (int**)malloc(elemSnum * sizeof(int*));
	numbR = (int**)malloc(elemtot * sizeof(int*));
	numbLine = (int**)malloc(elemLnum * sizeof(int*));
	x = (double*)malloc(nodostot * sizeof(double));
	y = (double*)malloc(nodostot * sizeof(double));
	z = (double*)malloc(nodostot * sizeof(double));
	for (int i = 0; i < elemSnum; i++) {
		numbS[i] = (int*)malloc(3 * sizeof(int));
	}
	for (int i = 0; i < elemLnum; i++) {
		numbLine[i] = (int*)malloc(2 * sizeof(int));
	}
	for (int i = 0; i < (elemtot); i++)
	{
		numbR[i] = (int*)malloc(4 * sizeof(int));
	}
	idLine = (int*)malloc(numberLines * sizeof(int));
	idSurface = (int*)malloc(numberSurfaces * sizeof(int));
	for (int i = 0; i < numberLines; i++)
	{
		idLine[i] = 0;
	}
	for (int i = 0; i < numberSurfaces; i++)
	{
		idSurface[i] = 0;
	}
	int tempVal;
	numdirichSurf = 0;
	idenLines.resize(4);
	idenSurfaces.resize(6);
	/* Identifies lines and surfaces located at the boundaries of the domain */
	for (int i = 0; i < 4; i++)
	{
		inFile >> numBLines[i];
		inFile >> numtotLines[i];
		for (int j = 0; j < numtotLines[i]; j++)
		{
			inFile >> tempVal;
			tempVal = tempVal - 1;
			idLine[tempVal] = 1;
			idenLines[i].push_back(tempVal);
		}

		inFile >> numtotSurfaces[i];
		numdirichSurf = numdirichSurf + numtotSurfaces[i];
		for (int j = 0; j < numtotSurfaces[i]; j++)
		{
			inFile >> tempVal;
			tempVal = tempVal - 1;
			idSurface[tempVal] = 1;
			idenSurfaces[i].push_back(tempVal);
		}

	}
	/* Identifies surfaces located at the middle, bottom and top of the domain  */
	for (int i = 4; i < 6; i++)
	{
		inFile >> numtotSurfaces[i];
		numdirichSurf = numdirichSurf + numtotSurfaces[i];
		for (int j = 0; j < numtotSurfaces[i]; j++)
		{
			inFile >> tempVal;
			tempVal = tempVal - 1;
			idSurface[tempVal] = 1;
			idenSurfaces[i].push_back(tempVal);
		}

	}
	double xb;
	/* Reads x,y,z coordinates of nodes */
	for (int i = 0; i < nodostot; i++)
	{
		inFile >> xb;
		x[i] = xb / Lg1 * Lx;
		inFile >> xb;
		y[i] = xb / Lg2 * Ly;
		inFile >> xb;
		z[i] = (xb) / (double)(Lg3)*Lz;
	}
	/* Reads nodal connectivity per line,surface and element */
	for (int j = 0; j < elemLnum; j++)
	{
		inFile >> numbLine[j][0];
		inFile >> numbLine[j][1];
	}
	for (int i = 0; i < elemSnum; i++)
	{
		inFile >> numbS[i][0];
		inFile >> numbS[i][1];
		inFile >> numbS[i][2];
	}
	for (int i = 0; i < elemtot; i++)
	{
		inFile >> numbR[i][0];
		inFile >> numbR[i][1];
		inFile >> numbR[i][2];
		inFile >> numbR[i][3];
	}
}
/* Defines face and edge connectivity info from nodal connectivity info*/
void UHOMT3D::SetConnectivity()
{
	
	for (int i = 0; i < 4; i++)
	{
		dirichLnum[i] = 0;
		for (int j = 0; j < numBLines[i]; j++)
		{
			dirichLnum[i] = dirichLnum[i] + (int)(elemperLine[idenLines[i][j]] * edgeB);
		}
	}
	
	
	enumSi = new enumSides[numberLines];
	
	
	elemin = 0;
	int min, max;

	/* Defines edge connectivity at line boundaries */
	for (int j = 0; j < numberLines; j++)
	{		
		for (int i = 0; i < elemperLine[j]; i++)
		{
			ida= numbLine[elemin][0];
			idb= numbLine[elemin][1];
			min = ida - 1;
			max = idb - 1;
			mintemp = min;
			if (max < min)
			{
				min = max;
				max = mintemp;
			}
			sizeF = elemN[min].size();
			actualizar = false;
			if (sizeF != 0)
			{
				ln = 0;
				salir = false;
			
				while (salir == false)
				{
					if (elemN[min][ln] == (max))
					{
						actualizar = false;
						salir = true;
					
					}
					else
					{
						actualizar = true;
					}
					ln = ln + 2;
					if (ln >= sizeF)
					{
						salir = true;
					}
				}
			}
			else
			{
				actualizar = true;
			}
			if (actualizar == true)
			{
				idnum.i1 = min;
				idnum.i2 = max;
				elemN[min].push_back(max);
				elemN[min].push_back(cont);
				
				if (idLine[j]==1)
				{
					ladosSup = ladosSup + edgeB;
				}
				enumSi[j].nodeID.push_back(idnum);
				enumSi[j].contV.push_back(cont);

				cont = cont + edgeB;
			}
			elemin++;
		}

	}


	totSurfaceG = 6 + numberSurfaces - numdirichSurf;
	enumFa = new enumFaces[totSurfaceG];
	elemin = 0;
	surfin = (int*)malloc(totSurfaceG * sizeof(int));
	acE = 0;

	
	for (int i = 0; i < totSurfaceG; i++)
	{
		if (i < 6)
		{
			surfin[i] = 0;
			
			for (int j = 0; j < numtotSurfaces[i]; j++)
			{
				elemtotRS[i].push_back(elemperSurf[acE]);
				surfin[i] =surfin[i]+ elemperSurf[acE];
				acE++;
			}
			
		}
		else
		{
			surfin[i] = elemperSurf[acE];
			acE++;
		}
	}
	elemSur.resize(nodostot);
	
	for (int i = 0; i < 4; i++)
	{
		newcont = 1;
		for (int j = 0; j < numtotLines[i]; j++)
		{
			idk = idenLines[i][j];
			for (int k = 0; k < elemperLine[idk]; k++)
			{
				min = enumSi[idk].nodeID[k].i1;
				max = enumSi[idk].nodeID[k].i2;
				
				elemSur[min].push_back(i);
				elemSur[min].push_back(max);
				elemSur[min].push_back(newcont);
				if (j >= numBLines[i])
				{
					enumFa[i].contO.push_back(enumSi[idk].contV[k]);
					enumFa[i].contE.push_back(newcont);
				}
				
				newcont = newcont + edgeB;
			}
		}
	}
	int contac;
	elemin = 0;

	/* Defines edge and face connectivity at surface boundaries */
	for (int j = 0; j < totSurfaceG; j++)
	{

		if (j < 4)
		{
			contS = dirichLnum[j] + (int)(enumFa[j].contO.size() * edgeB) + 1;//dirichLnum[surfenum[j]] + 1;
		}
		for (int i = 0; i < surfin[j]; i++)
		{
			vector <int> vec3;
			value1 = numbS[elemin][0];
			value2 = numbS[elemin][1];
			value3 = numbS[elemin][2];
			for (int j1 = 0; j1 < 3; j1++)
			{
				LN[j1] = numbS[elemin][j1] - 1;
				PosR[j1][0] = x[LN[j1]];
				PosR[j1][1] = y[LN[j1]];
				PosR[j1][2] = z[LN[j1]];
			}
			for (int ib = 0; ib < 3; ib++)
			{
				vecA[ib] = PosR[1][ib] - PosR[0][ib];
				vecB[ib] = PosR[2][ib] - PosR[0][ib];
				
			}
			double* nn;
			nn = crossP(vecA, vecB);
			if ((j == 1) || (j == 3))
			{
				if (nn[1] > 0.0)
				{
					enumFa[j].idE.push_back(1);
				}
				else
				{
					enumFa[j].idE.push_back(0);
				}

			}
			if ((j == 0) || (j == 2))
			{
				if (nn[0] > 0.0)
				{
					enumFa[j].idE.push_back(1);
				}
				else
				{
					enumFa[j].idE.push_back(0);
				}

			}
			free(nn);
			vec3.push_back(value1);
			vec3.push_back(value2);
			vec3.push_back(value3);
			enumFa[j].nodeID.push_back(vec3);
			vector<int>().swap(vec3);
			vector<int>vec3N;
			for (int h = 0; h < 3; h++)
			{
				min = numbS[elemin][arr1[h][0]] - 1;
				max = numbS[elemin][arr1[h][1]] - 1;
				mintemp = min;
				if (max < min)
				{
					min = max;
					max = mintemp;
				}
				sizeF = elemN[min].size();
				actualizar = false;
				if (sizeF != 0)
				{
					ln = 0;
					salir = false;
					while (salir == false)
					{
						if (elemN[min][ln] == (max))
						{
							actualizar = false;
							salir = true;
							
						}
						else
						{
							actualizar = true;
						}
						ln = ln + 2;
						if (ln >= sizeF)
						{
							salir = true;
						}
					}
				}
				else
				{
					actualizar = true;
				}
				if (actualizar == true)
				{
					elemN[min].push_back(max);
					elemN[min].push_back(cont);
					enumFa[j].contO.push_back(cont);
					if (j < 6)
					{
						ladosSup = ladosSup + edgeB;
					}
					cont = cont + edgeB;
				}
				if (j < 4)
				{
					sizeF = elemSur[min].size();
					actualizar = false;
					if (sizeF != 0)
					{
						ln = 0;
						salir = false;
						while (salir == false)
						{
							if ((elemSur[min][ln] == j) && (elemSur[min][ln + 1] == max))
							{
								contac = elemSur[min][ln + 2];
								actualizar = false;
								salir = true;
								vec3N.push_back(contac);
							
							}
							else
							{
								actualizar = true;
							}
							ln = ln + 3;
							if (ln >= sizeF)
							{
								salir = true;
							}
						}

					}
					else
					{
						actualizar = true;
					}
					if (actualizar == true)
					{
						elemSur[min].push_back(j);
						elemSur[min].push_back(max);
						elemSur[min].push_back(contS);
						enumFa[j].contE.push_back(contS);
						vec3N.push_back(contS);
						contS = contS + edgeB;
					}
				}
			}
			enumFa[j].ENnum.push_back(vec3N);
			vector<int>().swap(vec3N);
			if (faceB != 0)
			{
				int* values;
				values = order(value1, value2, value3);
				sizeF = elemIDF[values[0]].size();
				actualizar = false;
				if (sizeF != 0)
				{
					ln = 0;
					salir = false;
					
					while (salir == false)
					{
						if ((elemIDF[values[0]][ln] == (values[1])) && (elemIDF[values[0]][ln + 1] == (values[2])))
						{
							actualizar = false;
							salir = true;
							
						}
						else
						{
							actualizar = true;
						}
						ln = ln + 6;
						if (ln >= sizeF)
						{
							salir = true;
						}
					}
				}
				else
				{
					actualizar = true;
				}
				if (actualizar == true)
				{
					elemIDF[values[0]].push_back(values[1]);
					elemIDF[values[0]].push_back(values[2]);
					elemIDF[values[0]].push_back(cont);
					if (j < 4)
					{
						enumFa[j].contF.push_back(contS);
						contS = contS + faceB;
					}
					enumFa[j].contFO.push_back(cont);
					if (j < 6)
					{
						ladosSup = ladosSup + faceB;
					}
					if (j >= 6)
					{
						elemIDF[values[0]].push_back(1);
						elemIDF[values[0]].push_back(2);
						elemIDF[values[0]].push_back(0);
					}
					else
					{
						elemIDF[values[0]].push_back(1);
						elemIDF[values[0]].push_back(2);
						elemIDF[values[0]].push_back(1);
					}
					cont = cont + faceB;
				}
				
				free(values);
			}
			elemin++;
			
		}
		if (j < 4)
		{
			enumFa[j].totalV = contS - 1;
		}
	}
	
	edgenumber = cont - 1;
	free(numbS);	
	/* Defines edge and face connectivity at all tetrahedral elements */
	for (int j = 0; j < (elemtot); j++)
	{
		for (int k = 0; k < 4; k++)
		{
			LN[k] = numbR[j][k] - 1;
			PosR[k][0] = x[LN[k]];
			PosR[k][1] = y[LN[k]];
			PosR[k][2] = z[LN[k]];
		}
		for (int i = 0; i < 6; i++)
		{
			imin = arr[i][0];
			imax = arr[i][1];

			min = numbR[j][imin] - 1;
			max = numbR[j][imax] - 1;
			mintemp = min;
			if (max < min)
			{
				min = max;
				max = mintemp;
			}
			sizeF = elemN[min].size();
			actualizar = false;
			if (sizeF != 0)
			{
				ln = 0;
				salir = false;
			
				while (salir == false)
				{
					if (elemN[min][ln] == (max))
					{
						actualizar = false;
						salir = true;
					
					}
					else
					{
						actualizar = true;
					}
					ln = ln + 2;
					if (ln >= sizeF)
					{
						salir = true;
					}
				}
			}
			else
			{
				actualizar = true;
			}
			if (actualizar == true)
			{
				elemN[min].push_back(max);
				elemN[min].push_back(cont);
				cont = cont + edgeB;
			}

		}
		if (faceB != 0)
		{
			for (int i = 0; i < 4; i++)
			{
				int* values;
				
				value1 = numbR[j][arr2[i][0]];
				value2 = numbR[j][arr2[i][1]];
				value3 = numbR[j][arr2[i][2]];

				values = order(value1, value2, value3);
				sizeF = elemIDF[values[0]].size();
				
				actualizar = false;
				if (sizeF != 0)
				{
					ln = 0;
					salir = false;
					
					while (salir == false)
					{
						if ((elemIDF[values[0]][ln] == (values[1])) && (elemIDF[values[0]][ln + 1] == (values[2])))
						{
							

							if (elemIDF[values[0]][ln + 5] == 1)
							{
								actualizar = false;
							}
							actualizar = false;
							salir = true;
						}
						else
						{
							actualizar = true;
						}
						ln = ln + 6;
						if (ln >= sizeF)
						{
							salir = true;
						}
					}
				}
				else
				{
					actualizar = true;
				}
				if (actualizar == true)
				{
					elemIDF[values[0]].push_back(values[1]);
					elemIDF[values[0]].push_back(values[2]);
					elemIDF[values[0]].push_back(cont);
					elemIDF[values[0]].push_back(1);
					elemIDF[values[0]].push_back(2);
					elemIDF[values[0]].push_back(0);
					
					cont = cont + faceB;
				}
				free(values);
			}
		}
		
	}	
	
	ladostot = cont - 1; /* total number of degrees of freedom */
}
/* Defines the frequency array and allocates memory to save the result  */
void UHOMT3D::SetFrequencyRange(vector<double>Freq, int totProcess,int numProcess, int& fq1,int&fq2,int modepar[2])
{
	time(&start);
	numFreq = Freq.size();
	Fq.resize(numFreq, 0.0);
	for (int i = 0; i < numFreq; i++)
	{
		Fq[i] = Freq[i];
	}
	fq1 = 0;
	fq2 = numFreq;
	fqA = fq1;
	fqB = fq2;
	acut = 0;
	acutb = 0;
	if (modepar[0] == 1)
	{
		transfer = (double*)malloc((int)((fq2 - fq1) * 21 * numCoords) * sizeof(double));
		pedazoFinal = (double*)malloc((int)((numFreq) * 21 * numCoords) * sizeof(double));
		mode1 = 1;
	}
	else
	{
		mode1 = 0;
	}
	if (modepar[1] == 1)
	{
		transferb = (double*)malloc((int)((fq2 - fq1) * 24 * numCoords) * sizeof(double));
		pedazoFinalb = (double*)malloc((int)((numFreq) * 24 * numCoords) * sizeof(double));
		mode2 = 1;
	}
	else
	{
		mode2 = 0;
	}
	
	
	
}
/* Solves the 2D MT problem at the boundaries of the domain for each polarization mode and defines the Dirichlet boundary values for the 3D problem */
void UHOMT3D::UpdateBoundaryValues(int fqN,vector<vector<double > > condB,complex<double> boundaryV,int numCores)
{	
	
	int min, max;	
	mu0 = 4.0 * M_PI * pow(10.0, -7.0);
	Freq = (double)Fq[fqN];
	wr = 2.0 * M_PI * Freq;
	cond.resize(edgenumber, 0);
	dirichVN.resize(edgenumber, 0.0);
	dirichVN2.resize(edgenumber, 0.0);
	dirichI.resize(edgenumber, 0);
	dirichI2.resize(edgenumber, 0);
	/* 
	   Solves the 2D MT problem at the boundaries of the domain for each polarization mode. 
	   For the x-polarization mode, only the left and right surfaces are considered. 
	   For the y-polarization mode, only the front and back surfaces are considered. 
	 */
	for (int pol = 0; pol < 2; pol++)
	{
		for (int t = 0; t < 2; t++)
		{
			idp = poli2[(int)(pol * 2) + t];
			sumAC = 0;
			numSur = -1;
			elemtotS = surfin[idp];
			ladostotS = enumFa[idp].totalV;
			vector<complex<double > >dirichVNS(dirichLnum[idp], 0.0);
			vector<vector <complex<double > > >KMS(ladostotS);
			vector<vector<int > >IDS(ladostotS);
			vector<vector<int > >ID3S(ladostotS);
			vector<vector<int > >ID2S(ladostotS);
			vector<vector<int > >DIRS(ladostotS);
			vector<complex<double > >DVS(ladostotS, 0.0);
			acd = 0;
			/* Defines Dirichlet conditions at the line boundaries */
			for (int j = 0; j < numBLines[idp]; j++)
			{
				for (int i = 0; i < elemperLine[idenLines[idp][j]]; i++)
				{
						min = enumSi[idenLines[idp][j]].nodeID[i].i1;
						max = enumSi[idenLines[idp][j]].nodeID[i].i2;
						lx = sqrt(pow(x[max] - x[min], 2.0) + pow(y[max] - y[min], 2.0) + pow(z[max] - z[min], 2.0));
						if (((z[max]+z[min])/2.0) < 0.0)
						{
							E0 = boundaryV;
						}
						else
						{
							E0 = 0.0;
						}
						if (pol == 0)
						{
							dirichVNS[acd] = (complex<double>)E0 * (x[max] - x[min]) / (double)lx;
						}
						else
						{
							dirichVNS[acd] = (complex<double>) E0 * (y[max] - y[min]) / (double)lx;
						}
						if (edgeB == 2)
						{
							dirichVNS[acd + 1] = dirichVNS[acd];
						}
					contNN2 = enumSi[idenLines[idp][j]].contV[i] - 1;				
					if (pol == 0)
					{
						for (int h = 0; h < edgeB; h++)
						{
							dirichVN[contNN2+h] = dirichVNS[acd+h];
						}
						dirichI[contNN2] = 1;
					}
					else
					{
						for (int h = 0; h < edgeB; h++)
						{
							dirichVN2[contNN2 + h] = dirichVNS[acd + h];
						}
						dirichI2[contNN2] = 1;
					}
					for (int h = 0; h < edgeB; h++)
					{
						cond[contNN2+h] = 1;
					}
					acd = acd + edgeB;
				}
			}
			/* Computes the components of the matrix K for every element according the Edge Finite Element Method and assembles them in a single matrix  */
			for (int i = 0; i < elemtotS; i++)
			{
				
				for (int j = 0; j < 3; j++)
				{
					LN[j] = enumFa[idp].nodeID[i][j] - 1;
				}
				if (enumFa[idp].idE[i] == 1)
				{
					loc[0] = 0;
					loc[1] = 2;
					loc[2] = 1;				
				}
				else
				{
					loc[0] = 0;
					loc[1] = 1;
					loc[2] = 2;
				}
				for (int j = 0; j < 3; j++)
				{
					if (pol == 1)
					{
						PosR[j][0] = y[LN[loc[j]]];
						PosR[j][1] = z[LN[loc[j]]];
					}
					else
					{
						PosR[j][0] = x[LN[loc[j]]];
						PosR[j][1] = z[LN[loc[j]]];
					}
				}
				totB = (int)(3 * edgeB + faceB);
				for (int m = 0; m < totB; m++)
				{
					for (int n = 0; n < totB; n++)
					{
						K[m][n] = 0.0;
					}
				}
				
				if (i == sumAC)
				{
					numSur = numSur + 1;
					sumAC = sumAC + elemtotRS[idp][numSur];	
				}
				conduc = (double)condB[idp][numSur];
	
				q = 0; q3 = 0; s = 0;
				for (int j = 0; j < 3; j++)
				{
					for (int h = 0; h < edgeB; h++)
					{
						EN[q3] = enumFa[idp].ENnum[i][j] - 1+h;
						q3++;
					}					
				}
				for (int h = 0; h < faceB; h++)
				{
					EN[q3] = enumFa[idp].contF[i] - 1 + h;
					q3++;
				}

				for (int j = 0; j < totB; j++)
				{
					if (EN[j] < dirichLnum[idp])
					{
						condL[j] = 1;
					}
					else
					{
						condL[j] = 0;
					}
				}
				if (faceB != 0)
				{
					int* values;
					value1 = LN[0] + 1;
					value2 = LN[1] + 1;
					value3 = LN[2] + 1;
					values = order(value1, value2, value3);
					for (int p = 0; p < faceB; p++)
					{
						i1 = ar3[p][0];
						i2 = ar3[p][1];
						i3 = ar3[p][2];
						LN1 = values[i1];
						LN2 = values[i2];
						LN3 = values[i3];
						for (int m = 0; m < 3; m++)
						{
							if (LN2 == LN[m])
							{
								numbP[p][1] = m;

							}
							if (LN3 == LN[m])
							{
								numbP[p][2] = m;
							}
							if (LN1 == LN[m])
							{
								numbP[p][0] = m;
							}
						}
					}
					free(values);
				}
				pw = 0;
				for (int m = 0; m < 3; m++)
				{
					for (int n = 0; n < 3; n++)
					{
						if (n == 0)
						{
							GMS[m][n] = 1.0;
						}
						else
						{
							GMS[m][n] = (double)CFS[m][n - 1];
						}
					}
				}
				double** invT;
				invT = inv3(GMS);

				for (int m = 0; m < 3; m++)
				{
					for (int n = 0; n < 3; n++)
					{
						cofA[m][n] = invT[n][m];
					}
				}
				free(invT);

				sum = 0.0;
				double** GEinv;
				for (int p = 0; p < 2; p++)
				{
					for (int m = 0; m < 2; m++)
					{
						sum = 0.0;
						for (int n = 0; n < 3; n++)
						{
							sum = sum + G3Sinv[p + 1][n] * PosR[n][m];
						}
						GE[p][m] = sum;
					}
				}

				GEinv = inv2(GE);
				detT = GE[0][0] * GE[1][1] - GE[0][1] * GE[1][0];
				for (int k = 0; k < ordenN2; k++)
				{

					for (int p = 0; p < 3; p++)
					{
						N[p] = (cofA[p][0] + cofA[p][1] * ux2[k] + cofA[p][2] * uy2[k]);
						for (int m = 0; m < 2; m++)
						{

							if (p < 2)
							{
								dN2[p][m] = GEinv[m][p]; //cofA[p][m + 1] / Vol;

							}
							else
							{
								dN2[p][m] = -(dN2[0][m] + dN2[1][m]);
							}

						}
					}
					pw = 0;
					for (int h = 0; h < 3; h++)
					{
						fr[0] = arr1[h][0];
						fr[1] = arr1[h][1];
						frtemp = fr[0];
						if (LN[fr[1]] < LN[fr[0]])
						{
							fr[0] = fr[1];
							fr[1] = frtemp;
						}
						for (int r = 0; r < edgeB; r++)
						{
							lx = sqrt(pow(x[LN[fr[1]]] - x[LN[fr[0]]], 2.0) + pow(y[LN[fr[1]]] - y[LN[fr[0]]], 2.0) + pow(z[LN[fr[1]]] - z[LN[fr[0]]], 2.0));
							for (int m = 0; m < 2; m++)
							{
								if (typeB == 2)
								{
									W[pw][m] = (double)(3.0 * N[fr[r]] - 1.0) * lx * (N[fr[0]] * dN2[loc[fr[1]]][m] - N[fr[1]] * dN2[loc[fr[0]]][m]);
								}
								if(typeB == 1)
								{
									W[pw][m] = (double) lx * (N[fr[0]] * dN2[loc[fr[1]]][m] - N[fr[1]] * dN2[loc[fr[0]]][m]);
								}
								if (typeB == 3)
								{
									if (r == 0)
									{
										W[pw][m] = (double)lx * (N[fr[0]] * dN2[loc[fr[1]]][m]);
									}
									else
									{
										W[pw][m] = -(double)lx * (N[fr[1]] * dN2[loc[fr[0]]][m]);//(double)sqrt(3.0) * (N[fr[0]] - N[fr[1]]) * lx * (N[fr[0]] * dN2[loc[fr[1]]][m] - N[fr[1]] * dN2[loc[fr[0]]][m]);
									}
								}
								
							}
							if (typeB == 2)
							{
								ncross1 = crossP2(pol, dN2[loc[fr[0]]], dN2[loc[fr[1]]]);
								ncross2 = crossP2(pol, dN2[loc[fr[r]]], dN2[loc[fr[0]]]);
								ncross3 = crossP2(pol, dN2[loc[fr[r]]], dN2[loc[fr[1]]]);
							}
							else
							{
								if (typeB == 1)
								{
									ncross1 = crossP2(pol, dN2[loc[fr[0]]], dN2[loc[fr[1]]]);
								}
								else
								{
									if (r == 0)
									{
										ncross1 = crossP2(pol, dN2[loc[fr[0]]], dN2[loc[fr[1]]]);
									}
									else
									{
										ncross1 = -crossP2(pol, dN2[loc[fr[1]]], dN2[loc[fr[0]]]);
									}
								}
							}
							for (int m = 0; m < 1; m++)
							{
								if (typeB == 2)
								{
									rotU[pw][m] = (double)lx * ((2.0 * ncross1 * (3.0 * N[fr[r]] - 1.0)) + (double)3.0 * (N[fr[0]] * ncross3 - N[fr[1]] * ncross2));
								}
								if(typeB == 1)
								{
									rotU[pw][m] = (double)lx * 2.0 * ncross1;
								}
								if (typeB == 3)
								{
									rotU[pw][m] = (double)lx  * ncross1;
								}							
							}
							pw++;
						}
					}
				

					for (int p = 0; p < faceB; p++)
					{
						
						f1 = numbP[p][0];
						f2 = numbP[p][1];
						f3 = numbP[p][2];

						lx = sqrt(pow(x[LN[f3]] - x[LN[f2]], 2.0) + pow(y[LN[f3]] - y[LN[f2]], 2.0) + pow(z[LN[f3]] - z[LN[f2]], 2.0));
						for (int m = 0; m < 2; m++)
						{
							W[pw][m] = (double)(3.0 * N[f1]) * lx * (N[f2] * dN2[loc[f3]][m] - N[f3] * dN2[loc[f2]][m]);// / Vol;	
						}
						ncross1 = crossP2(pol, dN2[loc[f2]], dN2[loc[f3]]);
						ncross2 = crossP2(pol, dN2[loc[f1]], dN2[loc[f2]]);
						ncross3 = crossP2(pol, dN2[loc[f1]], dN2[loc[f3]]);
						for (int m = 0; m < 1; m++)
						{
							rotU[pw][m] = (double)lx * ((2.0 * ncross1 * (3.0 * N[f1])) + (double)3.0 * (N[f2] * ncross3 - N[f3] * ncross2));
						}
						pw++;
					}
					for (int m = 0; m < totB; m++)
					{
						for (int n = 0; n < totB; n++)
						{
							if (m >= n)
							{
								result1 = 0.0; result2 = 0.0;
								result2 = result2 + rotU[m][0] * rotU[n][0];
								for (int o = 0; o < 2; o++)
								{
									result1 = result1 + W[m][o] * W[n][o];

								}
								Rresult = (complex<double>)Pesos2[k] * (result2 * pow(10.0, 2.0) + (complex<double>)im * wr * mu0 * pow(10.0, 8.0) *(complex<double>)conduc * (complex<double>)result1) * detT;
								K[m][n] = K[m][n] + Rresult;
								K[n][m] = K[m][n];

							}
						}
					}

				}
				free(GEinv);
				for (int m = 0; m < totB; m++)
				{
					if (condL[m] == 0)
					{
						for (int n = 0; n < totB; n++)
						{
							sizeF = IDS[EN[m]].size();
							valF = distance(IDS[EN[m]].begin(), find(IDS[EN[m]].begin(), IDS[EN[m]].end(), EN[n] + 1));
							if ((sizeF == 0) || (valF == sizeF))
							{

								KMS[EN[m]].push_back(K[m][n]);
								IDS[EN[m]].push_back(EN[n] + 1);
								ID3S[EN[m]].push_back(IDS[EN[m]].size() - 1);
								if (condL[n] != 0)
								{
									DIRS[EN[m]].push_back(EN[n] + 1);
									ID2S[EN[m]].push_back(IDS[EN[m]].size());
								}
							}
							else
							{
								KMS[EN[m]][valF] = KMS[EN[m]][valF] + K[m][n];
							}
						}
					}
				}
			}

			id = 0; id2 = 0; ac = 0;
			max = 0;
			int* varc;
			varc = (int*)malloc(ladostotS * sizeof(int));
			/* Reassembles the resulting matrix K and the source vector b according to the defined Dirichlet boundary conditions */
			for (int p = 0; p < ladostotS; p++)
			{
				DVS[p] = 0.0;

				if (p >= dirichLnum[idp])
				{
					Sd = 0.0;
					for (int i = 0; i < DIRS[p].size(); i++)
					{
						id = DIRS[p][i] - 1;
						id2 = ID2S[p][i] - 1;
						Sd = Sd + (complex<double>) KMS[p][id2] * (complex<double>)dirichVNS[id];

						KMS[p][id2].real(0.0);
						KMS[p][id2].imag(0.0);
					}
					DVS[p] = DVS[p] - Sd;
					varc[p] = ac;
				}
				else
				{
					ac = ac + 1;
					varc[p] = ac;
				}
			}
			doublecomplex* xRS, * bvS;
			int* iaS;
			numV = (int)(ladostotS - dirichLnum[idp]);
			xRS = (doublecomplex*)malloc(numV * sizeof(doublecomplex));
			bvS = (doublecomplex*)malloc(numV * sizeof(doublecomplex));
			iaS = (int*)malloc((numV + 1) * sizeof(int));
			vector<doublecomplex>ARS;
			vector<int>ja2S;
			numS2 = 0;
			q = 0;
			p2 = -1;
			/* Redefines the resulting linear system of equations in a format compatible by PARDISO */
			for (int p = 0; p < ladostotS; p++)
			{
				if (p >= dirichLnum[idp])
				{
					p2 = p2 + 1;
					vecID = IDS[p];
					vecID3 = ID3S[p];
					std::vector<int> vec(vecID3.size());
					IncGenerator g(0);
					std::generate(vec.begin(), vec.end(), g);
					sort(vec.begin(), vec.end(), myfunction);
					rt = 0;
					for (int i = 0; i < IDS[p].size(); i++)
					{
						id = vec[i];
						id2 = IDS[p][id] - 1;
						if (id2 >= p)
						{
							if (abs(KMS[p][id]) > pow(10.0, -15.0))
							{
								refV.re = KMS[p][id].real();
								refV.i = KMS[p][id].imag();
								ARS.push_back(refV);
								ja2S.push_back(id2 - varc[id2]);
								numS2 = numS2 + 1;
								q = q + 1;
							}
						}
						if ((id2) == p)
						{
							rt = rt + 1;
							iaS[p2] = (numS2 - 1);
						}
					}
					vector<int>().swap(vec);
					bvS[p2].re = DVS[p].real();
					bvS[p2].i = DVS[p].imag();
				}
			}
			iaS[numV] = (numS2);
			vector<complex<double> >().swap(DVS);
			vector<vector<complex<double> > >().swap(KMS);
			vector<int >().swap(vecID);
			vector<int >().swap(vecID3);
			vector<vector<int > >().swap(DIRS);
			vector<vector<int > >().swap(ID2S);
			vector<vector<int > >().swap(ID3S);
			vector<vector<int > >().swap(IDS);
			free(varc);
			numT = q;
			doublecomplex* aRS;
			int* jaS;
			aRS = (doublecomplex*)malloc(numT * sizeof(doublecomplex));
			jaS = (int*)malloc(numT * sizeof(int));
			for (int i = 0; i < numT; i++)
			{
				aRS[i].re = ARS[i].re;
				aRS[i].i = ARS[i].i;
				jaS[i] = ja2S[i];
			}
			vector<doublecomplex >().swap(ARS);

			/* Solves the resulting linear system of equations using PARDISO MKL with the number of processes indicated by the user */
			int      nnz = iaS[numV];
			int      mtype = 6;
			int      nrhs = 1;
			void* pt[64];
			int      iparm[64];
			int      maxfct, mnum, phase, error, msglvl, solver;
			double   dparm[64];
			int      num_procs;
			doublecomplex   ddum;
			int	      idum;
			char* pValue;
			size_t len;
			char* var;
			//int      i;
			for (int i = 0; i < 64; i++) {
				pt[i] = 0;
			}
			for (int i = 0; i < 64; i++) {
				iparm[i] = 0;
			}
			iparm[0] = 1;
			iparm[1] = 2;

			iparm[2] = 1;//(int)pValue;// num_procs;
			maxfct = 1;
			mnum = 1;
			msglvl = 1;
			error = 0;
			for (int i = 0; i < numV + 1; i++) {
				iaS[i] += 1;
			}
			for (int i = 0; i < nnz; i++) {
				jaS[i] += 1;
			}
			error = 0;
			solver = 0;
			pardisoinit(pt, &mtype, &solver, iparm, dparm, &error);
			if (error != 0)
			{
				if (error == -10)
					printf("No license file found \n");
				if (error == -11)
					printf("License is expired \n");
				if (error == -12)
					printf("Wrong username or hostname \n");
				//return 1;
			}
			else
				printf("[PARDISO]: License check was successful ... \n");
			
			phase = 11;

			pardiso(pt, &maxfct, &mnum, &mtype, &phase,
				&numV, aRS, iaS, jaS, &idum, &nrhs,
				iparm, &msglvl, &ddum, &ddum, &error, dparm);
			
			if (error != 0) {
				cout << ("\nERROR during symbolic factorization: %d", error) << endl;
				exit(1);
			}
			phase = 22;
			cout << ("\nReordering completed ... ") << endl;
			pardiso(pt, &maxfct, &mnum, &mtype, &phase,
				&numV, aRS, iaS, jaS, &idum, &nrhs,
				iparm, &msglvl, &ddum, &ddum, &error, dparm);
			
			if (error != 0) {
				cout << ("\nERROR during numerical factorization: %d", error) << endl;
				exit(2);
			}
			cout << ("\nFactorization completed ...\n ") << endl;
			phase = 33;
			iparm[7] = 2;
			pardiso(pt, &maxfct, &mnum, &mtype, &phase,
				&numV, aRS, iaS, jaS, &idum, &nrhs,
				iparm, &msglvl, bvS, xRS, &error, dparm);
			if (error != 0) {
				cout << ("\nERROR during solution: %d", error) << endl;
				exit(3);
			}
			cout << ("\nSolve completed ... ") << endl;
			for (int i = 0; i < numV + 1; i++) {
				iaS[i] -= 1;
			}
			for (int i = 0; i < nnz; i++) {
				jaS[i] -= 1;
			}

			phase = -1;

			pardiso(pt, &maxfct, &mnum, &mtype, &phase,
				&numV, &ddum, iaS, jaS, &idum, &nrhs,
				iparm, &msglvl, &ddum, &ddum, &error, dparm);
			free(aRS);
			free(bvS);
			free(jaS);
			free(iaS);

			/* Defines Dirichlet boundary conditions according to the calculated values. */
			for (int i = 0; i < enumFa[idp].contO.size(); i++)
			{
				contval = enumFa[idp].contO[i] - 1;
				contval2 = enumFa[idp].contE[i] - 1 - dirichLnum[idp];
				for (int r = 0; r < edgeB; r++)
				{
					if (pol == 0)
					{
						dirichVN[contval + r].real(xRS[contval2 + r].re);
						dirichVN[contval + r].imag(xRS[contval2 + r].i);
						dirichI[contval + r] = 1;
					}
					else
					{
						dirichVN2[contval + r].real(xRS[contval2 + r].re);
						dirichVN2[contval + r].imag(xRS[contval2 + r].i);
						dirichI2[contval + r] = 1;
					}
					cond[contval + r] = 1;
				}
			}
			if (faceB != 0)
			{
				for (int i = 0; i < enumFa[idp].contF.size(); i++)
				{
					contval = enumFa[idp].contFO[i] - 1;
					contval2 = enumFa[idp].contF[i] - 1 - dirichLnum[idp];
					for (int r = 0; r < faceB; r++)
					{
						if (pol == 0)
						{
							dirichVN[contval + r].real(xRS[contval2 + r].re);
							dirichVN[contval + r].imag(xRS[contval2 + r].i);
							dirichI[contval + r] = 1;
							
						}
						else
						{
							dirichVN2[contval + r].real(xRS[contval2 + r].re);
							dirichVN2[contval + r].imag(xRS[contval2 + r].i);
							dirichI2[contval + r] = 1;
						

						}
						cond[contval + r] = 1;

					
					}
				}
			}			
			free(xRS);
		}
	}
	
	/*
	   Defines Dirichlet boundary values at the boundary surfaces that have not yet been considered.
	   For the x-polarization mode, the upper, lower, front and back surfaces are considered.
	   For the y-polarization mode, the upper, lower, left and right surfaces are considered.
	 */
	for (int pol = 0; pol < 2; pol++)
	{
		for (int t = 0; t < 4; t++)
		{
			idp = poli3[(int)(pol * 4) + t];
			elemtotS = surfin[idp];
			for (int i = 0; i < elemtotS; i++)
			{
				for (int p = 0; p < 3; p++)
				{
					LN[p] = enumFa[idp].nodeID[i][p] - 1;
				}
				for (int h = 0; h < 3; h++)
				{
					min = LN[arr1[h][0]];
					max = LN[arr1[h][1]];
					mintemp = min;
					if (max < min)
					{
						min = max;
						max = mintemp;
					}
					sizeF = elemN[min].size();
					
					if (sizeF != 0)
					{
						ln = 0;
						salir = false;
						contN4 = -1;
						while (salir == false)
						{
							if (elemN[min][ln] == (max))
							{
								contN4 = (int)elemN[min][ln + 1] - 1;
								
								salir = true;
								
							}
							ln = ln + 2;
							if (ln >= sizeF)
							{
								salir = true;
							}
						}
						
					}
					
					if (pol == 0)
					{
						veri = dirichI[contN4];
					}
					else
					{
						veri = dirichI2[contN4];
					}
					if (veri == 0)
					{
						for (int r = 0; r < edgeB; r++)
						{
							lx = (double)sqrt(pow(x[max] - x[min], 2.0) + pow(y[max] - y[min], 2.0) + pow(z[max] - z[min], 2.0));
							zn = (double)z[min] + (double)(z[max] - z[min]) / 2.0;
							if (t == 0)
							{
								E0 = boundaryV;
							}
							else
							{
								E0 = 0.0;
							}
							if (pol == 0)
							{
								result = (complex<double>)E0 * (complex<double>)(x[max] - x[min]) / (complex<double>)lx;
							}
							else
							{
								result = (complex<double>)E0 * (complex<double>)(y[max] - y[min]) / (complex<double>)lx;
							}
							if (pol == 0)
							{
								dirichI[contN4 + r] = 1;
								dirichVN[contN4 + r] = result;
							}
							else
							{
								dirichI2[contN4 + r] = 1;
								dirichVN2[contN4 + r] = result;
							}
							cond[contN4 + r] = 1;
						}
					}
				}
				if (faceB != 0)
				{
					contN4 = enumFa[idp].contFO[i] - 1;
					int* values;
					value1 = LN[0] + 1;
					value2 = LN[1] + 1;
					value3 = LN[2] + 1;
					
					values = order(value1,value2,value3);
					
					LN3 = values[2];
					LN4 = values[0];
					for (int p = 0; p < faceB; p++)
					{
						LN1 = values[arr1[p][0]];
						LN2 = values[arr1[p][1]];
						lx = (double)sqrt(pow(x[LN2] - x[LN1], 2.0) + pow(y[LN2] - y[LN1], 2.0) + pow(z[LN2] - z[LN1], 2.0));
						if (t == 0)
						{
							E0 = boundaryV;
						}
						else
						{
							E0 = 0.0;
						}
						control3 = (double)(y[LN2] - y[LN1]);
						control4 = (double)(y[LN4] - y[LN3]);
						control1 = (double)(x[LN2] - x[LN1]);
						control2 = (double)(x[LN4] - x[LN3]);
						if (pol == 0)
						{
							dirichVN[contN4 + p] = (complex<double>)(E0 * (complex<double>)control1 / (complex<double>)lx - E0 * (complex<double>)control2 / (complex<double>)lx);
						}
						else
						{
							dirichVN2[contN4 + p] = (complex<double>)(E0 * (complex<double>)control3 / (complex<double>)lx - E0 * (complex<double>)control4 / (complex<double>)lx);
						}
						cond[contN4 + p] = 1;
					}
					free(values);
				}

			}

		}
	}
	
	numV = (int)(ladostot - ladosSup);/* Total number of degrees of freedom without considering the boudary surfaces*/
}
/* Calculates the components of the matrix K according to the Edge Finite Element Method and assembles them in a single matrix */
void UHOMT3D::ConstructKMatrix(vector <double> conducV)
{
	int min, max;
	KM.resize(ladostot);
	ID.resize(ladostot);
	ID3.resize(ladostot);
	ID2.resize(ladostot);
	DIR.resize(ladostot);
	sumAC = 0;
	numVol = -1;
	for (int i = 0; i < elemtot; i++)
	{
		
		for (int j = 0; j < 4; j++)
		{
			LN[j] = numbR[i][j] - 1;
			PosR[j][0] = x[LN[j]];
			PosR[j][1] = y[LN[j]];
			PosR[j][2] = z[LN[j]];
		}
		totB = (int)(6 * edgeB + 4 * faceB);
		for (int m = 0; m < totB; m++)
		{
			for (int n = 0; n < totB; n++)
			{
				K[m][n] = 0.0;
			}
		}
		if (i == sumAC)
		{
			numVol++;
			sumAC = sumAC + elemperVol[numVol];
		}
		conduc = (double)conducV[numVol];
		q = 0; q3 = 0; s = 0;
		for (int j = 0; j < 6; j++)
		{
			imin = arr[j][0];
			imax = arr[j][1];
			min = numbR[i][imin] - 1;
			max = numbR[i][imax] - 1;
			mintemp = min;
			if (max < min)
			{
				min = max;
				max = mintemp;
			}
			sizeF = elemN[min].size();
			actualizar = false;
			if (sizeF != 0)
			{
				ln = 0;
				salir = false;
				while (salir == false)
				{
					if (elemN[min][ln] == (max))
					{
						contN3 = elemN[min][ln + 1];
						for (int h = 0; h < edgeB; h++)
						{
							EN[q3+h] = contN3 - 1+h;
						}
						if ((contN3) < edgenumber)
						{
							for (int h = 0; h < edgeB; h++)
							{
								condL[q3 + h] = cond[contN3 - 1 + h];
							}
						}
						else
						{
							for (int h = 0; h < edgeB; h++)
							{
								condL[q3 + h] = 0;
							}
						}
						q3 = q3 + edgeB;
						salir = true;
					}
					ln = ln + 2;
					if (ln >= sizeF)
					{
						salir = true;
					}
				}
			}			
		}
		if (faceB != 0)
		{
			for (int j = 0; j < 4; j++)
			{
				value1 = numbR[i][arr2[j][0]];
				value2 = numbR[i][arr2[j][1]];
				value3 = numbR[i][arr2[j][2]];
				int* values;
				values = order(value1, value2, value3);
				sizeF = elemIDF[values[0]].size();
				actualizar = false;
				if (sizeF != 0)
				{
					ln = 0;
					salir = false;

					while (salir == false)
					{
						if ((elemIDF[values[0]][ln] == (values[1])) && (elemIDF[values[0]][ln + 1] == (values[2])))
						{
							contN = elemIDF[values[0]][ln + 2];
							EN[q3] = contN - 1;
							EN[q3 + 1] = contN;
							ind1[0] = elemIDF[values[0]][ln + 3];
							ind1[1] = elemIDF[values[0]][ln + 4];
							ind1[2] = 3;
							if (elemIDF[values[0]][ln + 5] == 1)
							{
								condL[q3] = 1;
								condL[q3 + 1] = 1;
							}
							else
							{
								condL[q3] = 0;
								condL[q3 + 1] = 0;
							}

							actualizar = true;
							salir = true;
						}
						ln = ln + 6;
						if (ln >= sizeF)
						{
							salir = true;
						}
					}
				}
				
				
				for (int p = 0; p < faceB; p++)
				{
					i1 = ar3[ind1[p] - 1][0];
					i2 = ar3[ind1[p] - 1][1];
					i3 = ar3[ind1[p] - 1][2];
					LN1 = values[i1] + 1;
					LN2 = values[i2] + 1;
					LN3 = values[i3] + 1;
					for (int m = 0; m < 4; m++)
					{
						if (LN2 == (numbR[i][m]))
						{
							numbP[q][1] = m;

						}
						if (LN3 == numbR[i][m])
						{
							numbP[q][2] = m;
						}
						if (LN1 == numbR[i][m])
						{
							numbP[q][0] = m;
						}
					}
					q = q + 1;
					q3 = q3 + 1;
				}
				free(values);
			}
		}
		pw = 0;
		for (int m = 0; m < 4; m++)
		{
			for (int n = 0; n < 4; n++)
			{
				if (n == 0)
				{
					GM[m][n] = 1.0;
				}
				else
				{
					GM[m][n] = (double)CF[m][n - 1];
				}
			}
		}
		
		double** invT;
		invT = inv4(GM);
		for (int m = 0; m < 4; m++)
		{
			for (int n = 0; n < 4; n++)
			{
				cofA4[m][n] = invT[n][m];
			}
		}
		free(invT);
		double** GEinv; sum = 0.0;
		for (int t = 0; t < 3; t++)
		{
			for (int m = 0; m < 3; m++)
			{
				sum = 0.0;
				for (int n = 0; n < 4; n++)
				{
					sum = sum + G3inv[t + 1][n] * PosR[n][m];
				}
				GE3[t][m] = sum;
			}
		}
		GEinv = inv3(GE3);
		detT = GE3[0][0] * (GE3[1][1] * GE3[2][2] - GE3[1][2] * GE3[2][1]) + GE3[0][1] * (GE3[1][2] * GE3[2][0] - GE3[2][2] * GE3[1][0]) + GE3[0][2] * (GE3[1][0] * GE3[2][1] - GE3[1][1] * GE3[2][0]);
		for (int k = 0; k < ordenN; k++)
		{
			for (int p = 0; p < 4; p++)
			{
				N[p] = (cofA4[p][0] + cofA4[p][1] * ux[k] + cofA4[p][2] * uy[k] + cofA4[p][3] * uz[k]);
				for (int m = 0; m < 3; m++)
				{
					if (p < 3)
					{
						dN[p][m] = GEinv[m][p]; //cofA[p][m + 1] / Vol;

					}
					else
					{
						dN[p][m] = -(dN[0][m] + dN[1][m] + dN[2][m]);
					}
				}
			}
			pw = 0;
			for (int p = 0; p < 6; p++)
			{
				fr[0] = arr[p][0];
				fr[1] = arr[p][1];
				frtemp = fr[0];
				if (LN[fr[1]] < LN[fr[0]])
				{
					fr[0] = fr[1];
					fr[1] = frtemp;
				}
				for (int r = 0; r < edgeB; r++)
				{
					
					double* n1, * n2, * n3;
					//double* n2,*n3;
					lx = sqrt(pow(x[LN[fr[1]]] - x[LN[fr[0]]], 2.0) + pow(y[LN[fr[1]]] - y[LN[fr[0]]], 2.0) + pow(z[LN[fr[1]]] - z[LN[fr[0]]], 2.0));
					for (int m = 0; m < 3; m++)
					{
						if (typeB == 2)
						{
							W[pw][m] = (double)(3.0 * N[fr[r]] - 1.0) * lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
						}
						if(typeB == 1)
						{
							W[pw][m] = (double)lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
						}
						if (typeB == 3)
						{
							if (r == 0)
							{
								W[pw][m] = (double)lx * (N[fr[0]] * dN[fr[1]][m]);// -N[fr[1]] * dN[fr[0]][m]);
							}
							else
							{
								W[pw][m] = -(double)lx * (N[fr[1]] * dN[fr[0]][m]);//(double)sqrt(3.0) * (N[fr[0]] - N[fr[1]]) * lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
							}

						}
					}
					
						n1 = crossP(dN[fr[0]], dN[fr[1]]);
						n2 = crossP(dN[fr[r]], dN[fr[0]]);
						n3 = crossP(dN[fr[r]], dN[fr[1]]);
					
					
					for (int m = 0; m < 3; m++)
					{
						if (typeB == 2)
						{
							rotU[pw][m] = (double)lx * ((2.0 * n1[m] * (3.0 * N[fr[r]] - 1.0)) + (double)3.0 * (N[fr[0]] * n3[m] - N[fr[1]] * n2[m]));
						}
						if(typeB == 1)
						{
							rotU[pw][m] = (double)lx * 2.0 * n1[m];
						}
						if (typeB == 3)
						{
							rotU[pw][m] = (double)lx * n1[m];
						}						
					}
					
						free(n1);
						free(n2);
						free(n3);
					
					pw++;
				}
			}
			
			idx = 0;
			
			if (faceB != 0)
			{
				for (int u = 0; u < 4; u++)
				{
				
					for (int p = 0; p < faceB; p++)
					{
						double* n1, * n2, * n3;
						
						f1 = numbP[idx][0];
						f2 = numbP[idx][1];
						f3 = numbP[idx][2];
						idx++;
										
						lx = sqrt(pow(x[LN[f3]] - x[LN[f2]], 2.0) + pow(y[LN[f3]] - y[LN[f2]], 2.0) + pow(z[LN[f3]] - z[LN[f2]], 2.0));
						
						for (int m = 0; m < 3; m++)
						{
							W[pw][m] = (double)(3.0 * N[f1]) * lx * (N[f2] * dN[f3][m] - N[f3] * dN[f2][m]);// / Vol;	
						
						}
						n1 = crossP(dN[f2], dN[f3]);
						n2 = crossP(dN[f1], dN[f2]);
						n3 = crossP(dN[f1], dN[f3]);
						for (int m = 0; m < 3; m++)
						{
							rotU[pw][m] = (double)lx * ((2.0 * n1[m] * (3.0 * N[f1])) + (double)3.0 * (N[f2] * n3[m] - N[f3] * n2[m]));

							
						}
						free(n1);
						free(n2);
						free(n3);
						pw++;
					}
				}
			}


			for (int m = 0; m < totB; m++)
			{
				for (int n = 0; n < totB; n++)
				{
					if (m >= n)
					{
						result1 = 0.0; result2 = 0.0;
						for (int o = 0; o < 3; o++)
						{
							result1 = result1 + W[m][o] * W[n][o];
							result2 = result2 + rotU[m][o] * rotU[n][o];
						}
						Rresult = (complex<double>)Pesos[k] * (result2 * pow(10.0, 2.0) + (complex<double>)im * wr * mu0 * pow(10.0, 8.0)*(complex<double>)conduc * (complex<double>)result1) * detT;
						K[m][n] = K[m][n] + Rresult;
						K[n][m] = K[m][n];
					}
				}
			}
		}
		free(GEinv);
		
		for (int m = 0; m < totB; m++)
		{
			if (condL[m] == 0)
			{
				for (int n = 0; n < totB; n++)
				{
					sizeF = ID[EN[m]].size();
					valF = distance(ID[EN[m]].begin(), find(ID[EN[m]].begin(), ID[EN[m]].end(), EN[n] + 1));
					if ((sizeF == 0) || (valF == sizeF))
					{

						KM[EN[m]].push_back(K[m][n]);
						ID[EN[m]].push_back(EN[n] + 1);
						ID3[EN[m]].push_back(ID[EN[m]].size() - 1);
						if (condL[n] != 0)
						{
							DIR[EN[m]].push_back(EN[n] + 1);
							ID2[EN[m]].push_back(ID[EN[m]].size());
						}
					}
					else
					{
						KM[EN[m]][valF] = KM[EN[m]][valF] + K[m][n];
					}
				}
			}
		}
	}
	
}
int* varc;
vector<complex<double > >DV;
vector<complex<double > >DV2;
vector<doublecomplex>AR;
vector<int>ja2;
/* Reassembles the resulting matrix K and source vector b to apply the defined Dirichlet boundary conditions */
void UHOMT3D::ApplyBoundaryConditions()
{
	int max, min;
	varc = (int*)malloc(ladostot * sizeof(int));
	DV.resize(ladostot, 0.0);
	DV2.resize(ladostot, 0.0);
	id = 0; id2 = 0; ac = 0;
	max = 0;
	for (int p = 0; p < ladostot; p++)
	{
		DV[p] = 0.0;
		DV2[p] = 0.0;
		chk = 0;
		if (p < edgenumber)
		{
			chk = cond[p];
		}
		if (chk == 0)
		{
			Sd = 0.0;
			Sd2 = 0.0;
			//vector <complex<double > >newV;
			for (int i = 0; i < DIR[p].size(); i++)
			{
				id = DIR[p][i] - 1;
				id2 = ID2[p][i] - 1;
				Sd = Sd + (complex<double>) KM[p][id2] * (complex<double>)dirichVN[id];
				Sd2 = Sd2 + (complex<double>) KM[p][id2] * (complex<double>)dirichVN2[id];
				KM[p][id2].real(0.0);
				KM[p][id2].imag(0.0);
			}
			DV[p] = DV[p] - Sd;
			DV2[p] = DV2[p] - Sd2;
			varc[p] = ac;
		}
		else
		{
			ac = ac + 1;
			varc[p] = ac;
		}
	}
}
doublecomplex* bv;
int* ia;
doublecomplex* aR;
int* ja;
doublecomplex* xR;
vector <complex <double > >resultA;
vector <complex <double > >resultB;
/* Solves the resulting linear system of equations with PARDISO Solver using the number of threads defined by the user */
void UHOMT3D::SolveLinearSystem(int numCores)
{	
	numS2 = 0;
	q = 0;
	p2 = -1;	
	bv = (doublecomplex*)malloc(numV * 2 * sizeof(doublecomplex));	
	ia = (int*)malloc((numV + 1) * sizeof(int));
	for (int p = 0; p < ladostot; p++)
	{
		chk = 0;
		if (p < edgenumber)
		{
			chk = cond[p];
		}
		if (chk == 0)
		{
			p2 = p2 + 1;
			vecID = ID[p];
			vecID3 = ID3[p];
			std::vector<int> vec(vecID3.size());
			IncGenerator g(0);
			std::generate(vec.begin(), vec.end(), g);
			sort(vec.begin(), vec.end(), myfunction);
			
			rt = 0;
			for (int i = 0; i < ID[p].size(); i++)
			{
				id = vec[i];
				id2 = ID[p][id] - 1;
				if (id2 >= p)
				{
					if (abs(KM[p][id]) > pow(10.0, -15.0))
					{
						refV.re = KM[p][id].real();
						refV.i = KM[p][id].imag();
						AR.push_back(refV);
						ja2.push_back(id2 - varc[id2]);
						numS2 = numS2 + 1;
						q = q + 1;
					}
				}
				if ((id2) == p)
				{
					rt = rt + 1;
					ia[p2] = (numS2 - 1);
				}
			}
			
			vector<int>().swap(vec);
			bv[p2].re = DV[p].real();
			bv[p2].i = DV[p].imag();
			bv[p2 + numV].re = DV2[p].real();
			bv[p2 + numV].i = DV2[p].imag();
		}
	}
	ia[numV] = (numS2);
	vector<int >().swap(vecID);
	vector<int >().swap(vecID3);
	vector<vector<complex<double> > >().swap(KM);
	vector<vector<int > >().swap(DIR);
	vector<vector<int > >().swap(ID2);
	vector<vector<int > >().swap(ID3);
	vector<vector<int > >().swap(ID);
	vector<complex<double> >().swap(DV);
	vector<complex<double> >().swap(DV2);
	
	numT = q;
	
	aR = (doublecomplex*)malloc(numT * sizeof(doublecomplex));
	ja = (int*)malloc(numT * sizeof(int));
	for (int i = 0; i < numT; i++)
	{
		aR[i].re = AR[i].re;
		aR[i].i = AR[i].i;
		ja[i] = ja2[i];
	}
	vector<doublecomplex >().swap(AR);
	xR = (doublecomplex*)malloc(numV * 2 * sizeof(doublecomplex));

	
	int      nnz = ia[numV];
	int      mtype = 6;
	int      nrhs = 2;
	void* pt[64];
	int      iparm[64];
	int      maxfct, mnum, phase, error, msglvl, solver;
	double   dparm[64];
	int      num_procs;
	doublecomplex   ddum;
	int	      idum;
	char* pValue;
	size_t len;
	char* var;
	int      i;
	for (i = 0; i < 64; i++) {
		pt[i] = 0;
	}
	for (i = 0; i < 64; i++) {
		iparm[i] = 0;
	}
	iparm[0] = 1;
	iparm[1] = 2;
	iparm[2] = numCores;
	maxfct = 1;
	mnum = 1;
	msglvl = 1;
	error = 0;
	for (i = 0; i < numV + 1; i++) {
		ia[i] += 1;
	}
	for (i = 0; i < nnz; i++) {
		ja[i] += 1;
	}
	error = 0;
	solver = 0;
	pardisoinit(pt, &mtype, &solver, iparm, dparm, &error);

	if (error != 0)
	{
		if (error == -10)
			printf("No license file found \n");
			if (error == -11)
				printf("License is expired \n");
				if (error == -12)
				    printf("Wrong username or hostname \n");			
	}
	else
	{
		cout << ("[PARDISO] License check was successful ... \n") << endl;
	}
	pardiso_chkvec_z(&numV, &nrhs, bv, &error);
	if (error != 0) {
		cout << ("\nERROR in right hand side: %d", error) << endl;
		exit(1);
	}
	pardiso_chkmatrix_z(&mtype, &numV, aR, ia, ja, &error);
	if (error != 0) {
		cout << ("\nERROR in consistency of matrix: %d", error) << endl;
		exit(1);
	}
	phase = 11;
	pardiso(pt, &maxfct, &mnum, &mtype, &phase,
		&numV, aR, ia, ja, &idum, &nrhs,
		iparm, &msglvl, &ddum, &ddum, &error, dparm);
	if (error != 0) {
		cout << ("\nERROR during symbolic factorization: %d", error) << endl;
		exit(1);
	}
	phase = 22;
	cout << ("\nReordering completed ... ") << endl;
	pardiso(pt, &maxfct, &mnum, &mtype, &phase,
		&numV, aR, ia, ja, &idum, &nrhs,
		iparm, &msglvl, &ddum, &ddum, &error, dparm);
	if (error != 0) {
		cout << ("\nERROR during numerical factorization: %d", error) << endl;
		exit(2);
	}
	cout << ("\nFactorization completed ...\n ") << endl;
	phase = 33;
	iparm[7] = 1;
	pardiso(pt, &maxfct, &mnum, &mtype, &phase,
		&numV, aR, ia, ja, &idum, &nrhs,
		iparm, &msglvl, bv, xR, &error, dparm);
	if (error != 0) {
		cout << ("\nERROR during solution: %d", error) << endl;
		exit(3);
	}
	cout << ("\nSolve completed ... ") << endl;

	for (i = 0; i < numV + 1; i++) {
		ia[i] -= 1;
	}
	for (i = 0; i < nnz; i++) {
		ja[i] -= 1;
	}

	phase = -1;

	pardiso(pt, &maxfct, &mnum, &mtype, &phase,
		&numV, &ddum, ia, ja, &idum, &nrhs,
		iparm, &msglvl, &ddum, &ddum, &error, dparm);
	resultA.resize(ladostot, 0.0);
	resultB.resize(ladostot, 0.0);
	nac = 0;
	for (int p = 0; p < ladostot; p++)
	{
		chk = 0;
		if (p < edgenumber)
		{
			chk = cond[p];
		}
		if (chk == 0)
		{
			resultA[p].imag((double)xR[nac].i);
			resultA[p].real((double)xR[nac].re);
			resultB[p].imag((double)xR[nac + numV].i);
			resultB[p].real((double)xR[nac + numV].re);
			nac++;
		}
		else
		{
			resultA[p].real(dirichVN[p].real());
			resultA[p].imag(dirichVN[p].imag());
			resultB[p].real(dirichVN2[p].real());
			resultB[p].imag(dirichVN2[p].imag());
		}
	}
	vector<complex<double> >().swap(dirichVN);
	vector<complex<double> >().swap(dirichVN2);
	vector<int >().swap(cond);
	vector<int >().swap(dirichI);
	vector<int >().swap(dirichI2);
	vector<int >().swap(ja2);
	free(xR);
	free(bv);
	free(aR);
	free(ja);
	free(ia);
	free(varc);
}
int pn1;
/* Computes the electric and magnetic fields and/or apparent resistivities, phases, impedances and Tipper values*/
void UHOMT3D::CalculateResponses()
{
	int min, max;
	minN = 16.0; maxN = -16.0;
	for (int k = 0; k < numCoords; k++)
	{
		vector <int> orden1;
		for (int p = 0; p < (elemtot); p++)
		{
			minN = 100.0;
			maxN = -100.0;
			for (int i = 0; i < 4; i++)
			{
				valueI = numbR[p][i] - 1;
				if (z[valueI] < minN)
				{
					minN = z[valueI];
				}
				if (z[valueI] > maxN)
				{
					maxN = z[valueI];
				}
			}
			if ((maxN >= evz[k]) && (minN <= evz[k]))
			{
				orden1.push_back(p + 1);
			}
		}
		vector<int>orden2;
		for (int p = 0; p < orden1.size(); p++)
		{
			p2 = orden1[p] - 1;
			minN = 100.0;
			maxN = -100.0;

			for (int i = 0; i < 4; i++)
			{
				valueI = numbR[p2][i] - 1;
				if (y[valueI] < minN)
				{
					minN = y[valueI];
				}
				if (y[valueI] > maxN)
				{
					maxN = y[valueI];
				}
			}
			if ((maxN >= evy[k]) && (minN <= evy[k]))
			{
				orden2.push_back(p2 + 1);
			}
		}
		for (int k1 = 0; k1 < 1; k1++)
		{
			
			salir2 = false;
			salir = false;
			pn1 = 0;
			while (!salir)
			{
				p2 = orden2[pn1] - 1;

				for (int k3 = 0; k3 < 4; k3++)
				{
					LN[k3] = numbR[p2][k3] - 1;
					PosR[k3][0] = x[LN[k3]];
					PosR[k3][1] = y[LN[k3]];
					PosR[k3][2] = z[LN[k3]];
				}
				for (int ib = 0; ib < 3; ib++)
				{
					vecA[ib] = PosR[2][ib] - PosR[0][ib];
					vecB[ib] = PosR[1][ib] - PosR[0][ib];
					vecC[ib] = PosR[3][ib] - PosR[0][ib];
				}
				double* nn;
				nn = crossP(vecA, vecB);
				sumV = 0.0;
				for (int ib = 0; ib < 3; ib++)
				{
					sumV = sumV + nn[ib] * vecC[ib];
				}
				free(nn);
				if (sumV > 0.0)
				{
					numbC[0] = numbR[p2][0];
					numbC[1] = numbR[p2][1];
					numbC[2] = numbR[p2][2];
					numbC[3] = numbR[p2][3];
				}
				else
				{
					numbC[0] = numbR[p2][0];
					numbC[1] = numbR[p2][2];
					numbC[2] = numbR[p2][1];
					numbC[3] = numbR[p2][3];
				}

				jr = 0;
				chk2 = true;
				salir2 = false;
				
				while (!salir2)
				{

					indx1 = arr6[jr][0] - 1;
					indx2 = arr6[jr][1] - 1;
					indx3 = arr6[jr][2] - 1;
					in1 = numbC[indx1] - 1;
					in2 = numbC[indx2] - 1;
					in3 = numbC[indx3] - 1; 

					ac = checkcross(x[in1], y[in1], z[in1], x[in2], y[in2], z[in2], x[in3], y[in3], z[in3], evx[k], evy[k], evz[k]);
					if (ac == 0)
					{
						chk2 = false;
						salir2 = true;
					}
					if ((jr == 3))
					{
						salir2 = true;
					}
					jr++;
				}
				if (pn1 == (orden2.size() - 1) && (chk2 == false))
				{
					cout << "Evaluation point not located" << endl;//(" << evPosx[k] << "," << evPosy << "," << evPosz << ") no encontrado" << endl;
					salir = true;
				}
				if ((chk2 == true) || ((pn1 == (orden2.size() - 1)) && (chk2 == true)))
				{
					
					IDP = p2 + 1;
					elemNumb = p2;
					for (int i = 0; i < 4; i++)
					{
						LN[i] = numbR[elemNumb][i] - 1;
					}
					PosT[0] = evx[k];
					PosT[1] = evy[k];
					PosT[2] = evz[k];
					for (int i = 0; i < 4; i++)
					{
						PosR2[i][0] = x[LN[i]];
						PosR2[i][1] = y[LN[i]];
						PosR2[i][2] = z[LN[i]];
					}
					
					q = 0; q3 = 0;
					for (int j = 0; j < 6; j++)
					{
						imin = arr[j][0];
						imax = arr[j][1];

						min = numbR[elemNumb][imin] - 1;
						max = numbR[elemNumb][imax] - 1;
						mintemp = min;
						if (max < min)
						{
							min = max;
							max = mintemp;
						}
						sizeF = elemN[min].size();
						actualizar = false;
						if (sizeF != 0)
						{
							ln = 0;
							salir3 = false;
							
							while (salir3 == false)
							{
								if (elemN[min][ln] == (max))
								{
									contN3 = elemN[min][ln + 1];
									for (int h = 0; h < edgeB; h++)
									{
										EN[q3] = contN3 - 1+h;
										q3++;
									}
									
									actualizar = false;
									salir3 = true;
									
								}
								else
								{
									actualizar = true;
								}
								ln = ln + 2;
								if (ln >= sizeF)
								{
									salir3 = true;
								}
							}
							
						}
						
					}
					q = 0; 
					if (faceB != 0)
					{
						for (int s = 0; s < 4; s++)
						{
						
							value1 = numbR[elemNumb][arr2[s][0]];
							value2 = numbR[elemNumb][arr2[s][1]];
							value3 = numbR[elemNumb][arr2[s][2]];
							int* values;
							values = order(value1, value2, value3);
							sizeF = elemIDF[values[0]].size();
							
							actualizar = false;
							if (sizeF != 0)
							{
								ln = 0;
								salir3 = false;

								while (salir3 == false)
								{
									if ((elemIDF[values[0]][ln] == (values[1])) && (elemIDF[values[0]][ln + 1] == (values[2])))
									{
									
										contN = elemIDF[values[0]][ln + 2];
										EN[q3] = contN - 1;
										EN[q3 + 1] = contN;
										ind1[0] = elemIDF[values[0]][ln + 3];
										ind1[1] = elemIDF[values[0]][ln + 4];
										ind1[2] = 3;
										actualizar = true;
										salir3 = true;
									}

									ln = ln + 6;
									if (ln >= sizeF)
									{
										salir3 = true;
									}
								}
							}
							for (int r = 0; r < faceB; r++)
							{
								i1 = ar3[ind1[r] - 1][0];
								i2 = ar3[ind1[r] - 1][1];
								i3 = ar3[ind1[r] - 1][2];
								LN1 = values[i1] + 1;
								LN2 = values[i2] + 1;
								LN3 = values[i3] + 1;
								for (int m = 0; m < 4; m++)
								{
									if (LN2 == (numbR[elemNumb][m]))
									{
										numbP[q][1] = m;
									}
									if (LN3 == numbR[elemNumb][m])
									{
										numbP[q][2] = m;
									}
									if (LN1 == numbR[elemNumb][m])
									{
										numbP[q][0] = m;
									}
								}
								q = q + 1;
								q3 = q3 + 1;
							}
							free(values);
						}
					}
					for (int m = 0; m < 4; m++)
					{
						for (int n = 0; n < 4; n++)
						{
							if (n == 0)
							{
								GM[m][n] = 1.0;
							}
							else
							{
								GM[m][n] = PosR2[m][n - 1];
							}
						}
					}
					double** invT;
					invT = inv4(GM);
					for (int m = 0; m < 4; m++)
					{
						for (int n = 0; n < 4; n++)
						{
							cofA4[m][n] = invT[n][m];
						}
					}
					free(invT);
					sum = 0.0;
					double** GEinv;
					for (int t = 0; t < 3; t++)
					{
						for (int m = 0; m < 3; m++)
						{
							sum = 0.0;
							for (int n = 0; n < 4; n++)
							{
								sum = sum + G3inv[t + 1][n] * PosR2[n][m];
							}
							GE3[t][m] = sum;
						}
					}
					GEinv = inv3(GE3);				
					for (int i = 0; i < 4; i++)
					{
						N[i] = (cofA4[i][0] + cofA4[i][1] * PosT[0] + cofA4[i][2] * PosT[1] + cofA4[i][3] * PosT[2]);
						for (int m = 0; m < 3; m++)
						{
							if (i < 3)
							{
								dN[i][m] = GEinv[m][i]; 
							}
							else
							{
								dN[i][m] = -(dN[0][m] + dN[1][m] + dN[2][m]);
							}
						}
					}
					free(GEinv);
				
					fr[0] = 0;
					fr[1] = 0;
					pw = 0;
					for (int s2 = 0; s2 < 6; s2++)
					{
						fr[0] = arr[s2][0];
						fr[1] = arr[s2][1];
						frtemp = fr[0];
						if (LN[fr[1]] < LN[fr[0]])
						{
							fr[0] = fr[1];
							fr[1] = frtemp;
						}
						
						for (int r = 0; r < edgeB; r++)
						{
							double* n1, * n2, * n3;

							lx = sqrt(pow(x[LN[fr[1]]] - x[LN[fr[0]]], 2.0) + pow(y[LN[fr[1]]] - y[LN[fr[0]]], 2.0) + pow(z[LN[fr[1]]] - z[LN[fr[0]]], 2.0));
							for (int m = 0; m < 3; m++)
							{
								
								if (typeB == 2)
								{
									W[pw][m] = (double)(3.0 * N[fr[r]] - 1.0) * lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
								}
								if(typeB == 1)
								{
									W[pw][m] = (double) lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
								}
								if(typeB == 3)
								{
									if (r == 0)
									{
										W[pw][m] = lx * (N[fr[0]] * dN[fr[1]][m]);// -N[fr[1]] * dN[fr[0]][m]);
									}
									else
									{
										W[pw][m] = -lx * (N[fr[1]] * dN[fr[0]][m]);//(double)sqrt(3.0) * (N[fr[0]] - N[fr[1]]) * lx * (N[fr[0]] * dN[fr[1]][m] - N[fr[1]] * dN[fr[0]][m]);
									}
								}
							}
							
								n1 = crossP(dN[fr[0]], dN[fr[1]]);
							
								n2 = crossP(dN[fr[r]], dN[fr[0]]);
								n3 = crossP(dN[fr[r]], dN[fr[1]]);
							for (int m = 0; m < 3; m++)
							{
								if (typeB == 2)
								{
									rotU[pw][m] = (double)lx * ((2.0 * n1[m] * (3.0 * N[fr[r]] - 1.0)) + (double)3.0 * (N[fr[0]] * n3[m] - N[fr[1]] * n2[m]));
								}
								if(typeB == 1)
								{
									rotU[pw][m] = (double)lx * 2.0 * n1[m];
								}
								if (typeB == 3)
								{
									rotU[pw][m] = (double)lx * n1[m];
								}
							}
							
								free(n1);
								free(n2);
								free(n3);
							
							
							pw++;
						}
					}

					idx = 0;
					if (faceB != 0)
					{
						for (int u = 0; u < 4; u++)
						{
							
							for (int i = 0; i < 2; i++)
							{
								double* n1, * n2, * n3;
								f1 = numbP[idx][0];
								f2 = numbP[idx][1];
								f3 = numbP[idx][2];
								idx++;
								lx = sqrt(pow(x[LN[f3]] - x[LN[f2]], 2.0) + pow(y[LN[f3]] - y[LN[f2]], 2.0) + pow(z[LN[f3]] - z[LN[f2]], 2.0));
								for (int m = 0; m < 3; m++)
								{
									W[pw][m] = (double)(3.0 * N[f1]) * lx * (N[f2] * dN[f3][m] - N[f3] * dN[f2][m]);
								}
								n1 = crossP(dN[f2], dN[f3]);
								n2 = crossP(dN[f1], dN[f2]);
								n3 = crossP(dN[f1], dN[f3]);
								for (int m = 0; m < 3; m++)
								{
									rotU[pw][m] = (double)lx * ((2.0 * n1[m] * (3.0 * N[f1])) + (double)3.0 * (N[f2] * n3[m] - N[f3] * n2[m]));
								}
								free(n1);
								free(n2);
								free(n3);
								pw++;
							}
						}
					}

					for (int s = 0; s < 3; s++)
					{
						for (int pol = 0; pol < 2; pol++)
						{
							CE2[s][pol] = 0.0;
							CM2[s][pol] = 0.0;
						}
					}

					for (int m = 0; m < totB; m++)
					{
						for (int n = 0; n < 3; n++)
						{
							CE2[n][0] = CE2[n][0] + (complex<double>)W[m][n] * resultA[EN[m]];
							CM2[n][0] = CM2[n][0] + (complex<double>)rotU[m][n] * im * resultA[EN[m]] / (complex<double>)(wr * mu0) / 1000.0;
							CE2[n][1] = CE2[n][1] + (complex<double>)W[m][n] * resultB[EN[m]];
							CM2[n][1] = CM2[n][1] + (complex<double>)rotU[m][n] * im * resultB[EN[m]] / (complex<double>)(wr * mu0) / 1000.0;

						}
						for (int pol = 0; pol < 2; pol++)
						{
							Ex[k][pol] = CE2[0][pol];
							Ey[k][pol] = CE2[1][pol];
							Ez[k][pol] = CE2[2][pol];
							Hx[k][pol] = CM2[0][pol];
							Hy[k][pol] = CM2[1][pol];
							Hz[k][pol] = CM2[2][pol];
						}
					}
					
					salir = true;
				}
				pn1++;
			}

			detZ = (complex<double>)(Hx[k][0] * Hy[k][1] - Hx[k][1] * Hy[k][0]);
			Zxx = (complex<double>)(Ex[k][0] * Hy[k][1] - Ex[k][1] * Hy[k][0]) / (complex<double>) detZ;
			Zxy = (complex<double>)(-Ex[k][0] * Hx[k][1] + Ex[k][1] * Hx[k][0]) / (complex<double>) detZ;
			Zyx = (complex<double>)(Ey[k][0] * Hy[k][1] - Ey[k][1] * Hy[k][0]) / (complex<double>) detZ;
			Zyy = (complex<double>)(-Ey[k][0] * Hx[k][1] + Ey[k][1] * Hx[k][0]) / (complex<double>) detZ;
			Tzx = (Hy[k][1] * Hz[k][0] - Hy[k][0] * Hz[k][1]) / detZ;
			Tzy = (-Hx[k][1] * Hz[k][0] + Hx[k][0] * Hz[k][1]) / detZ;
			Zxxr = Zxx.real();
			Zxxi = Zxx.imag();
			Zyyr = Zyy.real();
			Zyyi = Zyy.imag();
			Zxyr = Zxy.real();
			Zxyi = Zxy.imag();
			Zyxr = Zyx.real();
			Zyxi = Zyx.imag();
			Tzxr = Tzx.real();
			Tzxi = Tzx.imag();
			Tzyr = Tzy.real();
			Tzyi = Tzy.imag();


			RhoXY = (double)pow(abs(Zxy), 2.0) / (wr * mu0);
			RhoYX = (double)pow(abs(Zyx), 2.0) / (wr * mu0);
			RhoYY = (double)pow(abs(Zyy), 2.0) / (wr * mu0);
			RhoXX = (double)pow(abs(Zxx), 2.0) / (wr * mu0);
			FaseXY = atan(imag(Zxy) / real(Zxy)) * 180.0 / M_PI;
			FaseYX = atan(imag(Zyx) / real(Zyx)) * 180.0 / M_PI;
			FaseYY = atan(imag(Zyy) / real(Zyy)) * 180.0 / M_PI;
			FaseXX = atan(imag(Zxx) / real(Zxx)) * 180.0 / M_PI;
			if (mode1 == 1)
			{
				transfer[acut] = Freq;
				transfer[acut + 1] = RhoXX;
				transfer[acut + 2] = RhoYY;
				transfer[acut + 3] = RhoXY;
				transfer[acut + 4] = RhoYX;
				transfer[acut + 5] = FaseXX;
				transfer[acut + 6] = FaseYY;
				transfer[acut + 7] = FaseXY;
				transfer[acut + 8] = FaseYX;
				transfer[acut + 9] = Zxxr;
				transfer[acut + 10] = Zxxi;
				transfer[acut + 11] = Zyyr;
				transfer[acut + 12] = Zyyi;
				transfer[acut + 13] = Zxyr;
				transfer[acut + 14] = Zxyi;
				transfer[acut + 15] = Zyxr;
				transfer[acut + 16] = Zyxi;
				transfer[acut + 17] = Tzxr;
				transfer[acut + 18] = Tzxi;
				transfer[acut + 19] = Tzyr;
				transfer[acut + 20] = Tzyi;
				acut = acut + 21;
			}
			if (mode2 == 1)
			{
				transferb[acutb] = Ex[k][0].real();
				transferb[acutb + 1] = Ex[k][0].imag();
				transferb[acutb + 2] = Ey[k][0].real();
				transferb[acutb + 3] = Ey[k][0].imag();
				transferb[acutb + 4] = Ez[k][0].real();
				transferb[acutb + 5] = Ez[k][0].imag();
				transferb[acutb + 6] = Hx[k][0].real();
				transferb[acutb + 7] = Hx[k][0].imag();
				transferb[acutb + 8] = Hy[k][0].real();
				transferb[acutb + 9] = Hy[k][0].imag();
				transferb[acutb + 10] = Hz[k][0].real();
				transferb[acutb + 11] = Hz[k][0].imag();
				transferb[acutb + 12] = Ex[k][1].real();
				transferb[acutb + 13] = Ex[k][1].imag();
				transferb[acutb + 14] = Ey[k][1].real();
				transferb[acutb + 15] = Ey[k][1].imag();
				transferb[acutb + 16] = Ez[k][1].real();
				transferb[acutb + 17] = Ez[k][1].imag();
				transferb[acutb + 18] = Hx[k][1].real();
				transferb[acutb + 19] = Hx[k][1].imag();
				transferb[acutb + 20] = Hy[k][1].real();
				transferb[acutb + 21] = Hy[k][1].imag();
				transferb[acutb + 22] = Hz[k][1].real();
				transferb[acutb + 23] = Hz[k][1].imag();
				acutb = acutb + 24;
			}
		}
		vector<int >().swap(orden1);
		vector<int >().swap(orden2);
	}
	vector<complex<double> >().swap(resultA);
	vector<complex<double> >().swap(resultB);	
}
int acuf;
int acufb;
/* Master process receives and stores the data send by the other processes */
void UHOMT3D::PullData(int process_num,int size_of_cluster)
{
	acuf = 0;
	acufb = 0;
	//time(&finish3);
	if (mode1 == 1)
	{
		for (int i = 0; i < (int)((fqB - fqA) * 21 * numCoords); i++)
		{
			pedazoFinal[acuf] = transfer[i];
			acuf++;
		}
	}
	if (mode2 == 1)
	{
		for (int i = 0; i < (int)((fqB - fqA) * 24 * numCoords); i++)
		{
			pedazoFinalb[acufb] = transferb[i];
			acufb++;
		}
	}
}
int numVa,po;

double* UHOMT3D::GetImpedances()
{
	numVa =(int)(numFreq * 8 * numCoords);
	double* va = new double[numVa];
	acuf = 0;
	for (int fq = 0; fq < numFreq;fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(21 * numCoords * fq + 21 * j);
			for (int i = 0; i < 8; i++)
			{			
				va[acuf] = pedazoFinal[po+9+i];
				acuf++;
			}
		}
	}
	return va;
}
double* UHOMT3D::GetTipper()
{
	numVa = (int)(numFreq * 4 * numCoords);
	double* va = new double[numVa];
	acuf = 0;
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(21 * numCoords * fq + 21 * j);
			for (int i = 0; i < 4; i++)
			{
				va[acuf] = pedazoFinal[po + 17 + i];
				acuf++;
			}
		}
	}
	return va;
}
double* UHOMT3D::GetApparentResistivities()
{
	numVa = (int)(numFreq * 4 * numCoords);
	double* va = new double[numVa];
	acuf = 0;
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(21 * numCoords * fq + 21 * j);
			for (int i = 0; i < 4; i++)
			{
				va[acuf] = pedazoFinal[po + 1 + i];
				acuf++;
			}
		}
	}
	return va;
}
ofstream myfile5;
void UHOMT3D::CreateAppResFile(const char* FileName)
{	
	myfile5.open(FileName);
	time(&finish);
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(21 * numCoords * fq + 21 * j);
			for (int i = 0; i < 5; i++)
			{
				myfile5 << setprecision(15) << pedazoFinal[po + i];
				myfile5 << " ";
			}
			myfile5 << "\n";			
		}
	}
	myfile5 << setprecision(10) << (double)difftime(finish, start);
	myfile5 << "\n";
	myfile5.close();
}
double* UHOMT3D::GetPhases()
{
	numVa = (int)(numFreq * 4 * numCoords);
	double* va = new double[numVa];
	acuf = 0;
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(21 * numCoords * fq + 21 * j);
			for (int i = 0; i < 4; i++)
			{
				va[acuf] = pedazoFinal[po + 5 + i];
				acuf++;
			}
		}
	}
	return va;

}
void UHOMT3D::CreatePhaseFile(const char* FileName)
{
	myfile5.open(FileName);
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(21 * numCoords * fq + 21 * j);
			myfile5 << setprecision(15) << pedazoFinal[po];
			myfile5 << " ";
			for (int i = 5; i < 9; i++)
			{
				myfile5 << setprecision(15) << pedazoFinal[po + i];
				myfile5 << " ";
			}
			myfile5 << "\n";
		}
	}
	myfile5.close();
	
}
double* UHOMT3D::GetEFields()
{
	numVa = (int)(numFreq * 12 * numCoords);
	double* va = new double[numVa];
	acuf = 0;
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(24 * numCoords * fq + 24 * j);
			for (int i = 0; i < 6; i++)
			{
				va[acuf] = pedazoFinalb[po + i];
				acuf++;
			}
			for (int i = 12; i < 18; i++)
			{
				va[acuf] = pedazoFinalb[po + i];
				acuf++;
			}
		}
	}
	return va;
}
double* UHOMT3D::GetHFields()
{
	numVa = (int)(numFreq * 12 * numCoords);
	double* va = new double[numVa];
	acuf = 0;
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(24 * numCoords * fq + 24 * j);
			for (int i = 6; i < 12; i++)
			{
				va[acuf] = pedazoFinalb[po + i];
				acuf++;
			}
			for (int i = 18; i < 24; i++)
			{
				va[acuf] = pedazoFinalb[po + i];
				acuf++;
			}
		}
	}
	return va;
}
void UHOMT3D::CreateEFieldsFile(const char* FileName)
{
	myfile5.open(FileName);
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(24 * numCoords * fq + 24 * j);
			for (int i = 0; i < 6; i++)
			{
				myfile5 << setprecision(15) << pedazoFinalb[po + i];
				myfile5 << " ";
			}
			for (int i = 12; i < 18; i++)
			{
				myfile5 << setprecision(15) << pedazoFinalb[po + i];
				myfile5 << " ";
			}
			myfile5 << "\n";
		}
	}
	myfile5.close();
}
void UHOMT3D::CreateHFieldsFile(const char* FileName)
{
	myfile5.open(FileName);
	for (int fq = 0; fq < numFreq; fq++)
	{
		for (int j = 0; j < numCoords; j++)
		{
			po = (int)(24 * numCoords * fq + 24 * j);
			for (int i = 6; i < 12; i++)
			{
				myfile5 << setprecision(15) << pedazoFinalb[po + i];
				myfile5 << " ";
			}
			for (int i = 18; i < 24; i++)
			{
				myfile5 << setprecision(15) << pedazoFinalb[po + i];
				myfile5 << " ";
			}
			myfile5 << "\n";
		}
	}
	myfile5.close();
}