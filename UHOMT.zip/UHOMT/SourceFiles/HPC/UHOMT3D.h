#pragma once
#ifndef UHOMT3D_H
#define UHOMT3D_H

#include <iostream>
using namespace std;

#include<vector>
#include<complex>
class UHOMT3D
{
public:
	//unsigned int Program;
	void SetDimDomain(double L1,double L2,double L3,double L4);
	void SetDimGmsh(double L1, double L2, double L3);
	void SetBaseType(int dtypebase);
	void ReadFiles(const char* FileName,const char* FileName2);
	void SetConnectivity();
	void SetFrequencyRange(vector <double> Freq, int totProcess, int numProcess, int& fq1, int& fq2,int param[2]);
	void UpdateBoundaryValues(int fqN, vector<vector<double > > condB,complex<double> boundaryV,int numCores);
	void ConstructKMatrix(vector <double> conducV);
	void ApplyBoundaryConditions();
	void SolveLinearSystem(int numCores);
	void CalculateResponses();
	void PullData(int process_num,int size_of_cluster);
	double* GetImpedances();
	double* GetTipper();
	double* GetApparentResistivities();
	void CreateAppResFile(const char* FileName);
	double* GetPhases();
	void CreateEFieldsFile(const char* FileName);
	void CreateHFieldsFile(const char* FileName);
	void CreatePhaseFile(const char* FileName);
	double* GetEFields();
	double* GetHFields();	
};

#endif