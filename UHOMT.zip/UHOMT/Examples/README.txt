This folder contains input, output and code examples for the following test models:

o Half-space homogeneous earth
o COMMEMI 3D-1A
 
