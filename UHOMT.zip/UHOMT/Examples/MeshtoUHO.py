# -*- coding: utf-8 -*-
# Input parameters for COMMEMI 3D-1A model
inputFileName='GmshModels/Commemi3D1A.msh'
outputFileName='Commemi3D1A.UHO'
numberPoints=20
numberLines=32
numberSurfaces=17
numberVolumes=3
BoundaryLinesI=[1,2,4,5,6,7]
NonBoundaryLinesI=[3]
BoundarySurfacesI=[1,2]
BoundaryLinesII=[4,5,8,10,11,12]
NonBoundaryLinesII=[9]
BoundarySurfacesII=[3,4]
BoundaryLinesIII=[11,12,14,15,16,17]
NonBoundaryLinesIII=[13]
BoundarySurfacesIII=[5,6]
BoundaryLinesIV=[2,7,15,16,18,20]
NonBoundaryLinesIV=[19]
BoundarySurfacesIV=[7,8]
BoundaryLinesV=[6,8,17,18]
BoundarySurfacesV=[9]
BoundaryLinesVI=[1,10,14,20]
BoundarySurfacesVI=[10]

# Input parameters for half-space homogeneous model
# inputFileName='GmshModels/Example3D.msh'
# outputFileName='Example3D.UHO'
# numberPoints=12
# numberLines=20
# numberSurfaces=11
# numberVolumes=2
# BoundaryLinesI=[1,2,4,5,6,7]
# NonBoundaryLinesI=[3]
# BoundarySurfacesI=[1,2]
# BoundaryLinesII=[4,5,8,10,11,12]
# NonBoundaryLinesII=[9]
# BoundarySurfacesII=[3,4]
# BoundaryLinesIII=[11,12,14,15,16,17]
# NonBoundaryLinesIII=[13]
# BoundarySurfacesIII=[5,6]
# BoundaryLinesIV=[2,7,15,16,18,20]
# NonBoundaryLinesIV=[19]
# BoundarySurfacesIV=[7,8]
# BoundaryLinesV=[6,8,17,18]
# BoundarySurfacesV=[9]
# BoundaryLinesVI=[1,10,14,20]
# BoundarySurfacesVI=[10]

#Reads .msh files and outputs .UHO mesh file readable by UHOMT

with open(inputFileName) as f:
    content = f.readlines()
content = [x.strip() for x in content]
mat = []
sig=0
pos=[]
nodostot=0
num2=0
lineN=0
for line in content:
    s = line.split(' ')
    if(sig==1):
        nodostot=int(s[1])
        lineN=num2
        sig=0   
    if (s[0]=='$Nodes'):
        sig=1
    mat.append(s)
    num2=num2+1    
ac=lineN+3
numL=[]
numS=[]
for i in range(0,numberPoints):
    y=[0]*3
    y[0]=float(mat[ac][0])
    y[1]=float(mat[ac][1])
    y[2]=float(mat[ac][2])
    pos.append(y)
    ac=ac+3
ac=ac-2
for p in range(0,numberLines):
    sal1=int(mat[ac][3])
    ac=ac+sal1+1
    numL.append(sal1)
    for i in range(0,sal1):
        y=[0]*3
        y[0]=float(mat[ac][0])
        y[1]=float(mat[ac][1])
        y[2]=float(mat[ac][2])
        pos.append(y)
        ac=ac+1
for p in range(0,numberSurfaces+numberVolumes):
    sal1=int(mat[ac][3])
    ac=ac+sal1+1
    numS.append(sal1)
    for i in range(0,sal1):
        y=[0]*3
        y[0]=float(mat[ac][0])
        y[1]=float(mat[ac][1])
        y[2]=float(mat[ac][2])
        pos.append(y)
        ac=ac+1
ac=ac+3
ac=ac+(2*numberPoints)
numLE=[]
elemL=[]
for p in range(0,numberLines):
    sal=int(mat[ac][3])
    numLE.append(sal)
    ac=ac+1
    for i in range(0,sal):
        y=[0]*2
        y[0]=int(mat[ac][1])
        y[1]=int(mat[ac][2])
        elemL.append(y)
        ac=ac+1
supE=[]
elemSI=[]
supE=[]
volE=[]
elemSI=[]
elemVI=[]
for p in range(0,numberSurfaces):
    sup1=int(mat[ac][3])
    ac=ac+1    
    supE.append(sup1)
    for i in range(0,sup1):
        y=[0]*3
        y[0]=int(mat[ac][1])
        y[1]=int(mat[ac][2])
        y[2]=int(mat[ac][3])
        elemSI.append(y)
        ac=ac+1
for p in range(0,numberVolumes):
    vol1=int(mat[ac][3])
    ac=ac+1
    volE.append(vol1)
    for i in range(0,vol1):
        y=[0]*4
        y[0]=int(mat[ac][1])
        y[1]=int(mat[ac][2])
        y[2]=int(mat[ac][3])
        y[3]=int(mat[ac][4])
        elemVI.append(y)
        ac=ac+1
print("Done Reading")

f = open(outputFileName, 'w')#3DHomMPiramidalReal3
f.write('%i '%nodostot)
f.write('\n')
f.write('%i '%numberVolumes)
f.write('\n')
for i in range(0,numberVolumes):
    f.write('%i '%volE[i])
f.write('\n')
f.write('%i '%numberSurfaces)
f.write('\n')
for i in range(0,numberSurfaces):
    f.write('%i '%supE[i])
f.write('\n')
f.write('%i '%numberLines)
f.write('\n')
for i in range(0,numberLines):
    f.write('%i '%numLE[i])
f.write('\n')

f.write('%i '%(len(BoundaryLinesI)))
f.write('%i \n'%(len(BoundaryLinesI)+len(NonBoundaryLinesI)))
for i in range(0,len(BoundaryLinesI)):
    f.write('%i '%BoundaryLinesI[i])
for i in range(0,len(NonBoundaryLinesI)):
    f.write('%i '%NonBoundaryLinesI[i])
f.write('\n')
f.write('%i \n'%(len(BoundarySurfacesI)))
for i in range(0,len(BoundarySurfacesI)):
    f.write('%i '%BoundarySurfacesI[i])
f.write('\n')

f.write('%i '%(len(BoundaryLinesII)))
f.write('%i \n'%(len(BoundaryLinesII)+len(NonBoundaryLinesII)))
for i in range(0,len(BoundaryLinesII)):
    f.write('%i '%BoundaryLinesII[i])
for i in range(0,len(NonBoundaryLinesII)):
    f.write('%i '%NonBoundaryLinesII[i])
f.write('\n')
f.write('%i \n'%(len(BoundarySurfacesII)))
for i in range(0,len(BoundarySurfacesII)):
    f.write('%i '%BoundarySurfacesII[i])
f.write('\n')

f.write('%i '%(len(BoundaryLinesIII)))
f.write('%i \n'%(len(BoundaryLinesIII)+len(NonBoundaryLinesIII)))
for i in range(0,len(BoundaryLinesIII)):
    f.write('%i '%BoundaryLinesIII[i])
for i in range(0,len(NonBoundaryLinesIII)):
    f.write('%i '%NonBoundaryLinesIII[i])
f.write('\n')
f.write('%i \n'%(len(BoundarySurfacesIII)))
for i in range(0,len(BoundarySurfacesIII)):
    f.write('%i '%BoundarySurfacesIII[i])
f.write('\n')

f.write('%i '%(len(BoundaryLinesIV)))
f.write('%i \n'%(len(BoundaryLinesIV)+len(NonBoundaryLinesIV)))
for i in range(0,len(BoundaryLinesIV)):
    f.write('%i '%BoundaryLinesIV[i])
for i in range(0,len(NonBoundaryLinesIV)):
    f.write('%i '%NonBoundaryLinesIV[i])
f.write('\n')
f.write('%i \n'%(len(BoundarySurfacesIV)))
for i in range(0,len(BoundarySurfacesIV)):
    f.write('%i '%BoundarySurfacesIV[i])
f.write('\n')

f.write('%i \n'%(len(BoundarySurfacesV)))
for i in range(0,len(BoundarySurfacesV)):
    f.write('%i '%BoundarySurfacesV[i])
f.write('\n')

f.write('%i \n'%(len(BoundarySurfacesVI)))
for i in range(0,len(BoundarySurfacesVI)):
    f.write('%i '%BoundarySurfacesVI[i])
f.write('\n')

for i in range(0,nodostot):
    f.write('%.10f '%pos[i][0])
    f.write('%.10f '%pos[i][1])
    f.write('%.10f \n'%pos[i][2])
for i in range(0,len(elemL)):
    f.write('%i '%elemL[i][0])
    f.write('%i \n'%elemL[i][1])   
for i in range(0,len(elemSI)):
    f.write('%i '%elemSI[i][0])
    f.write('%i '%elemSI[i][1])
    f.write('%i \n'%elemSI[i][2])
for i in range(0,len(elemVI)):
    f.write('%i '%elemVI[i][0])
    f.write('%i '%elemVI[i][1])
    f.write('%i '%elemVI[i][2])
    f.write('%i \n'%elemVI[i][3])
f.close()
print("Done Writing")