/*-------------------------------------------------------
    Program that computes MT responses along the profile y=0 km at x=[0,3] km on the COMMEMI 3D-1A test model
 --------------------------------------------------------
  HPC version 
 --------------------------------------------------------
  Written by Erik Gallardo, Ensenada Center for Scientific
  Research and Higher Education, Ensenada, Mexico
  Email:egallardo@cicese.edu.mx
*/
#include "UHOMT3D.h" 
#include <iostream>
#include <vector>
#include <cmath>
#include <mpi.h> 
#include <mkl_pardiso.h>
#include <mkl_types.h>
#include <mkl.h>
using namespace std;
int main(int argc, char** argv)
{
    /*  Initialize MPI environment  */
    int process_num, size_of_cluster;
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size_of_cluster);
    MPI_Comm_rank(MPI_COMM_WORLD, &process_num);
    
    int numFreq = 1; /* Number of frequencies */
    int numberVolumes = 3; /* Number of volumes in mesh */
    vector<double>Freq(numFreq); 
    vector<vector<double > >condB(4);
    vector<double> condVol(numberVolumes,0.0);

    /*  Definition of frequency values  */
        Freq[0] = 0.1;

    /*  Set resistivities of air, earth and conductive body */
    double ResA = pow(10.0, 8.0); 
    double ResE = 100.0;
    double ResC = 0.5;

    /*  Definition of the conductivity values at the 
        boundary surfaces */
    for (int i = 0; i < 4; i++)
    {
        condB[i].push_back(1.0/ResA);
        condB[i].push_back(1.0/ResE);
    }
    /* Define conductivity value on every volume entity  */
    condVol[0] = (double)(1.0 / ResA);
    condVol[1] = (double)(1.0 / ResE);
    condVol[2] = (double)(1.0 / ResC);

    /* X,Y and Z lengths of the domain in km and Gmsh coordinates */
    double Lx = 200.0, Ly = 200.0, Lz1 = 100.0,Lz2=100.0;    
    double Gx = 2.0, Gy = 2.0,Gz=2.0; 

    UHOMT3D module;
    /*  Here we set the true dimensions of the model in km
        and in Gmsh coordinates.*/    
    module.SetDimDomain(Lx, Ly, Lz1,Lz2);
    module.SetDimGmsh(Gx, Gy, Gz);
    module.SetBaseType(2);/* Use base functions of second order */

    module.ReadFiles("RecepFileCommemi3D1A.txt", "COMMEMI3D1A.UHO");    
    module.SetConnectivity();
    int fq1 = 0, fq2 = 0;
    int param[2];
    param[0] = 1;/* We want to save computed MT responses */
    param[1] = 1;/* We want to save computed electric and/or magnetic fields */
    module.SetFrequencyRange(Freq,size_of_cluster,process_num,fq1,fq2,param);
    
    /* Main cycle */
    for (int fq = fq1; fq < fq2; fq++)
    {
        module.UpdateBoundaryValues(fq, condB,10.0,10);
        module.ConstructKMatrix(condVol);
        module.ApplyBoundaryConditions();
        module.SolveLinearSystem(10); /* Solve linear system of equations with 10 cores */
        module.CalculateResponses();
    }
    /* Master process retrieves data */
    module.PullData(process_num,size_of_cluster);

    if (process_num == 0)
    {
        /* Generates text files with the calculated 
        apparent resistivities and phases */   
       module.CreateAppResFile("AppResCOMMEMI3D1AO2.txt");
       module.CreatePhaseFile("PhaseCOMMEMI3D1AO2.txt");
    }
    MPI_Finalize();
    return 0;
}