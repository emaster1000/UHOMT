/*-------------------------------------------------------
    Example program to show the use of "UHOMT" to compute electric and magnetic fields on a 3D half-space homogeneous model
 --------------------------------------------------------
  Desktop version
 --------------------------------------------------------
  Written by Erik Gallardo, Ensenada Center for Scientific
  Research and Higher Education, Ensenada, Mexico
  Email:egallardo@cicese.edu.mx
*/
#include "UHOMT3D.h" 
#include <iostream>
#include <vector>
#include <cmath>
#include <ctime>
using namespace std;
int main(int argc, char** argv)
{
    
    int process_num=0, size_of_cluster=0;
    
    int numFreq = 1; /* Number of frequencies */
    int numberVolumes = 2; /* Number of volumes in mesh */
    vector<double>Freq(numFreq); /* Frequency array */   
    vector<vector<double > >condB(4);
    vector<double> condVol(numberVolumes,0.0);

    /*  Definition of frequency values  */    
    
    Freq[0] = 10.0;

    /*  Set resistivities of air and Earth layers */
    double ResA = (double)pow(10.0, 8.0); 
    double ResE = 100.0;

    /*  Definition of the conductivity values at the
        boundary surfaces */
    for (int i = 0; i < 4; i++)
    {
        condB[i].push_back(1.0/ResA);
        condB[i].push_back(1.0/ResE);
    }
    /* Define conductivity value on every volume entity  */
    condVol[0] = (double)(1.0 / ResA);
    condVol[1] = (double)(1.0 / ResE);

    /*  X,Y and Z lengths of the true domain in km */
    /* X,Y and Z lengths of the domain in km and Gmsh coordinates */
    double Lx = 30.0, Ly = 30.0, Lz1 = 15.0, Lz2 = 15.0;
    double Gx = 2.0, Gy = 2.0, Gz = 2.0;
   

    UHOMT3D module;
    /*  Here we set the true dimensions of the model in km
       and in Gmsh coordinates.*/
    module.SetDimDomain(Lx, Ly, Lz1,Lz2);
    module.SetDimGmsh(Gx, Gy, Gz);
    module.SetBaseType(2);/* Use base functions of second order */

    module.ReadFiles("RecepEFile.txt", "Example3DV2.UHO");
    module.SetConnectivity();

    int fq1 = 0, fq2 = 0;
    int param[2];
    param[0] = 1;/* We want to save computed MT responses */
    param[1] = 1;/* We want to save computed electric and/or magnetic fields */
    module.SetFrequencyRange(Freq, size_of_cluster, process_num, fq1, fq2, param);

    /* Main cycle */
    for (int fq = fq1; fq < fq2; fq++)
    {
        module.UpdateBoundaryValues(fq, condB, 10.0, 1);
        module.ConstructKMatrix(condVol);
        module.ApplyBoundaryConditions();
        module.SolveLinearSystem(1); /* Solve linear system of equations with 1 thread */
        module.CalculateResponses();
    }
    /* Master process retrieves data */
    module.PullData(process_num, size_of_cluster);

    /* Generates text files with the calculated
        electric and magnetic fields */
    module.CreateEFieldsFile("Efields3DOrder1.txt");
    module.CreateHFieldsFile("Hfields3DOrder1.txt");
    
    return 0;
}